import React from 'react';
import { BookOpen, ShieldCheck, Heart, Mail, ExternalLink, Award } from 'lucide-react';
import { PageView } from '../types';

interface FooterProps {
  setCurrentPage: (page: PageView) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-sm no-print">
      {/* Top Banner: Dedication & Tribute to Father */}
      <div className="border-b border-slate-800 bg-slate-950/80 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Heart className="w-5 h-5 text-amber-400 fill-amber-400/20" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-300 tracking-wide">
                Credit to My Father — Muhammad Toseef
              </h4>
              <p className="text-xs text-slate-400 max-w-2xl mt-0.5">
                In deep honor of his relentless hard work, enduring sacrifices, steadfast support, and daily encouragement that made Learn With Flow possible.
              </p>
            </div>
          </div>
          <button
            onClick={() => setCurrentPage('about-ceo')}
            className="text-xs font-semibold px-4 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shrink-0"
            id="footer-tribute-link"
          >
            Read Founder’s Tribute →
          </button>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-sm">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                Learn With Flow
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              A high-impact open educational initiative bringing Coursera-caliber technology training to global learners completely free. 182 structured tracks, verified educational playlists, interactive assessments, and verifiable digital certificates.
            </p>
            <div className="pt-2 flex items-center gap-2 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              <span>182 Curriculums Live & Verifiable</span>
            </div>
          </div>

          {/* Academic Programs */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Academic Tracks
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Web & Frontend Development (24)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Artificial Intelligence & ML (20)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Cybersecurity & Ethical Hacking (20)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Cloud Computing & DevOps (20)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Mobile Development (16)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('courses')} className="hover:text-white transition-colors">
                  Data Science & Big Data (18)
                </button>
              </li>
            </ul>
          </div>

          {/* Institutional Pages */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Institution
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentPage('about-us')} className="hover:text-white transition-colors">
                  About Learn With Flow
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('mission')} className="hover:text-white transition-colors">
                  Our Educational Mission
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('about-ceo')} className="hover:text-white transition-colors">
                  Founder & CEO Vision
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('verification')} className="hover:text-white transition-colors flex items-center gap-1 text-blue-400 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Certificate Verification
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('contact')} className="hover:text-white transition-colors">
                  Contact Support & Academic Team
                </button>
              </li>
            </ul>
          </div>

          {/* Trust & Security */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Trust & Policies
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentPage('privacy-policy')} className="hover:text-white transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('security')} className="hover:text-white transition-colors">
                  Security & Verification Integrity
                </button>
              </li>
              <li>
                <a 
                  href="https://www.youtube.com" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="hover:text-white transition-colors inline-flex items-center gap-1 text-slate-400"
                >
                  YouTube Educational Partner Terms
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li className="pt-2">
                <div className="p-2.5 rounded bg-slate-800/80 border border-slate-700/60 text-[11px] text-slate-300">
                  <span className="font-semibold text-amber-300">Strict Real Data Policy:</span> Every verified playlist is genuinely validated. Unverified tracks are transparently pending.
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-4">
          <p>© 2026 Learn With Flow. Built with dedication by CEO Muhammad Talha.</p>
          <div className="flex items-center gap-6">
            <span>Free Technology Education Platform</span>
            <span>•</span>
            <button onClick={() => setCurrentPage('verification')} className="hover:text-slate-200">
              Registry Verification
            </button>
            <span>•</span>
            <button onClick={() => setCurrentPage('security')} className="hover:text-slate-200">
              System Security
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
