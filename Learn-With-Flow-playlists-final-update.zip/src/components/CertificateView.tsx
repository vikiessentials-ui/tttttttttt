import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Award, Printer, ShieldCheck, CheckCircle2, ArrowLeft, ExternalLink, Share2 } from 'lucide-react';
import { CertificateRecord } from '../types';

interface CertificateViewProps {
  certificate: CertificateRecord;
  onBack: () => void;
  onVerifyInRegistry: (certId: string) => void;
}

export const CertificateView: React.FC<CertificateViewProps> = ({
  certificate,
  onBack,
  onVerifyInRegistry
}) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Generate real verified QR Code linking to verification page
    const fullVerifyUrl = `${window.location.origin}/?verify=${encodeURIComponent(certificate.id)}`;
    QRCode.toDataURL(fullVerifyUrl, {
      width: 140,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error('Failed to generate QR code', err));
  }, [certificate.id]);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    const fullVerifyUrl = `${window.location.origin}/?verify=${encodeURIComponent(certificate.id)}`;
    navigator.clipboard.writeText(fullVerifyUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="py-8 max-w-5xl mx-auto px-4 sm:px-6">
      {/* Action Header (Hidden in Print) */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 no-print">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Course Syllabus</span>
        </button>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleCopyLink}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-500" />
            <span>{copied ? 'Link Copied!' : 'Copy Verification Link'}</span>
          </button>

          <button
            onClick={() => onVerifyInRegistry(certificate.id)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors shadow-2xs"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Verify in Official Registry</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save as PDF</span>
          </button>
        </div>
      </div>

      {/* CERTIFICATE CANVAS: Strict Requirements:
          - Full white background
          - Royal-blue central design (#0056D2)
          - Subtle gold accents (#D4AF37 / gold border)
          - Premium border
          - Professional typography
          - Print-friendly layout
      */}
      <div className="bg-white border-8 border-double border-amber-500/40 rounded-2xl shadow-2xl p-8 sm:p-14 relative overflow-hidden text-slate-900 certificate-card">
        
        {/* Subtle royal-blue background watermark and decorative corners */}
        <div className="absolute top-0 left-0 w-36 h-36 bg-blue-700/5 rounded-br-full pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-44 h-44 bg-amber-500/5 rounded-tl-full pointer-events-none" />

        {/* Inner Gold Inset Frame */}
        <div className="border border-amber-400/50 rounded-xl p-6 sm:p-10 relative">
          
          {/* Header & Crest */}
          <div className="text-center space-y-3">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-700 text-white shadow-lg shadow-blue-700/20 border-2 border-amber-400">
              <Award className="w-8 h-8 text-amber-300" />
            </div>

            <div>
              <div className="inline-block px-3 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-[11px] font-bold tracking-widest uppercase mb-1">
                Official Certification of Achievement
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold text-blue-900 tracking-tight">
                Learn With Flow
              </h1>
              <p className="text-xs text-amber-700 font-semibold tracking-wider uppercase mt-0.5">
                Academic Board & Global Engineering Standards
              </p>
            </div>
          </div>

          {/* Certificate Main Text */}
          <div className="text-center my-8 space-y-4">
            <p className="text-xs sm:text-sm text-slate-500 font-medium tracking-wide uppercase">
              This is officially awarded to verify that
            </p>

            {/* Student Full Name */}
            <div className="py-2">
              <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-serif-title border-b-2 border-amber-400/60 inline-block px-8 pb-1 tracking-tight">
                {certificate.studentName}
              </h2>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
              has satisfactorily completed all rigorous curriculum requirements, practical lesson exercises, 8-question lesson quizzes, 15-question modular assessments, and successfully passed the 25-question comprehensive final examination with distinction for:
            </p>

            {/* Course Title */}
            <div className="py-2">
              <div className="inline-block px-6 py-2 rounded-xl bg-blue-50/80 border border-blue-200 shadow-2xs">
                <h3 className="text-lg sm:text-2xl font-bold text-blue-900">
                  {certificate.courseTitle}
                </h3>
                <span className="text-[11px] font-semibold text-blue-700">
                  Academic Discipline: {certificate.category} • Grade Awarded: {certificate.grade} ({certificate.scorePercentage}%)
                </span>
              </div>
            </div>
          </div>

          {/* Footer Validation Block: CEO Signature & QR Code */}
          <div className="mt-12 pt-8 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 items-center gap-6 text-center sm:text-left">
            
            {/* Left: Date & Certificate ID */}
            <div className="space-y-1">
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Date of Issuance</div>
              <div className="text-xs sm:text-sm font-bold text-slate-800">{certificate.completedDate}</div>
              <div className="text-[11px] text-slate-400 uppercase font-semibold pt-1">Certificate Record ID</div>
              <div className="text-xs font-mono font-bold text-blue-700 select-all">{certificate.id}</div>
            </div>

            {/* Center: Real Verifiable QR Code */}
            <div className="flex flex-col items-center justify-center text-center">
              {qrCodeDataUrl ? (
                <img
                  src={qrCodeDataUrl}
                  alt="Verified Certificate QR Code"
                  className="w-24 h-24 rounded border border-slate-200 shadow-2xs"
                />
              ) : (
                <div className="w-24 h-24 rounded bg-slate-100 border border-slate-200 flex items-center justify-center text-[10px] text-slate-400">
                  QR Code
                </div>
              )}
              <span className="text-[10px] text-slate-500 font-medium mt-1">
                Scan to Verify Authenticity
              </span>
            </div>

            {/* Right: CEO Muhammad Talha Signature */}
            <div className="text-center sm:text-right space-y-1">
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Authorized Signature</div>
              {/* Curvy Signature Styling */}
              <div className="font-signature text-3xl sm:text-4xl text-blue-900 select-none py-1">
                Muhammad Talha
              </div>
              <div className="border-t border-slate-300 pt-1">
                <div className="text-xs font-bold text-slate-800">Muhammad Talha</div>
                <div className="text-[10px] text-slate-500 font-medium">Founder & Chief Executive Officer</div>
                <div className="text-[10px] text-amber-700 font-semibold">Learn With Flow Academic Board</div>
              </div>
            </div>

          </div>

          {/* Bottom Security Note */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-400 gap-2">
            <div className="flex items-center gap-1 text-emerald-700 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Cryptographically Validated in Official System Registry</span>
            </div>
            <div>
              Learn With Flow • Accessible World-Class Technical Education
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
