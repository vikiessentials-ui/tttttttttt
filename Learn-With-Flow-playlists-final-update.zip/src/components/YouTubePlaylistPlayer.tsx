import React, { useState } from 'react';
import { Play, ExternalLink, ShieldCheck, AlertCircle, Youtube, CheckCircle2, RefreshCw } from 'lucide-react';
import { PlaylistInfo } from '../types';

interface YouTubePlaylistPlayerProps {
  courseTitle: string;
  category: string;
  playlist: PlaylistInfo;
  onOpenYouTubeFallback?: () => void;
}

export const YouTubePlaylistPlayer: React.FC<YouTubePlaylistPlayerProps> = ({
  courseTitle,
  category,
  playlist
}) => {
  const [embedLoadFailed, setEmbedLoadFailed] = useState(false);

  // If the playlist is pending verification (or ID is empty)
  if (!playlist.isVerified || !playlist.id) {
    return (
      <div className="bg-slate-50 border-2 border-dashed border-amber-200 rounded-xl p-8 text-center my-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-3 -translate-y-3 w-28 h-28 bg-amber-500/5 rounded-full pointer-events-none"></div>
        
        <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-4 border border-amber-200">
          <AlertCircle className="w-7 h-7" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
          <span>Playlist Pending Verification</span>
        </div>

        <h3 className="text-base font-bold text-slate-900 mt-1">
          Educational YouTube Track Under Academic Review
        </h3>
        
        <p className="text-xs text-slate-600 max-w-lg mx-auto mt-2 leading-relaxed">
          Learn With Flow strictly prohibits fabricated or placeholder playlist IDs. In accordance with our real data verification protocol, playlists are only displayed once individually validated for topic relevance, public accessibility, and educational quality.
        </p>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs">
          <div className="px-3.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 font-medium">
            Subject: <span className="font-bold text-slate-900">{courseTitle}</span>
          </div>
          <div className="px-3.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 font-medium">
            Category: <span className="font-bold text-blue-700">{category}</span>
          </div>
          <div className="px-3.5 py-1.5 bg-amber-100/60 border border-amber-300 rounded-lg text-amber-900 font-medium">
            Status: <span className="font-bold">Pending Owner/Instructor Verification</span>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 mt-4">
          All curriculum lesson notes, modular quizzes, assessments, and final exams remain fully active below.
        </p>
      </div>
    );
  }

  // When a verified playlist exists:
  const embedUrl = `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(playlist.id)}&rel=0&modestbranding=1`;
  const directUrl = playlist.url || `https://www.youtube.com/playlist?list=${playlist.id}`;

  return (
    <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-md my-4">
      {/* Top verified bar */}
      <div className="bg-slate-950 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Verified Educational Playlist
          </span>
          <span className="text-slate-300 font-medium hidden sm:inline">
            {playlist.title}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px] hidden md:inline">
            Channel: <strong className="text-slate-200">{playlist.channel}</strong>
          </span>
          
          <a
            href={directUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-2xs transition-colors"
            id="btn-open-youtube-playlist"
          >
            <Youtube className="w-3.5 h-3.5" />
            <span>Open Playlist on YouTube</span>
            <ExternalLink className="w-3 h-3 ml-0.5" />
          </a>
        </div>
      </div>

      {/* Embed Frame */}
      <div className="relative aspect-video w-full bg-slate-950">
        {!embedLoadFailed ? (
          <iframe
            src={embedUrl}
            title={`${courseTitle} - Verified Educational YouTube Playlist`}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            onError={() => setEmbedLoadFailed(true)}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-white bg-slate-900">
            <Youtube className="w-12 h-12 text-red-500 mb-3" />
            <h4 className="text-sm font-bold text-slate-100">
              Direct YouTube Player Available
            </h4>
            <p className="text-xs text-slate-400 max-w-md mt-1 mb-4">
              If embedded playback is restricted by your browser privacy settings or third-party cookies, launch this verified playlist directly in YouTube.
            </p>
            <a
              href={directUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition-colors"
            >
              <Youtube className="w-4 h-4" />
              <span>Open Playlist on YouTube</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="px-4 py-2 bg-slate-950 text-slate-400 text-[11px] flex items-center justify-between border-t border-slate-800">
        <span>Verified ID: <code className="text-slate-300 font-mono">{playlist.id}</code></span>
        <span className="text-emerald-400 font-medium">100% Free Educational Content</span>
      </div>
    </div>
  );
};
