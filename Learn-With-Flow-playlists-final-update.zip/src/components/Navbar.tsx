import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  ShieldCheck, 
  Globe, 
  Sparkles, 
  Lock, 
  Menu, 
  X,
  Award,
  User,
  HeartHandshake
} from 'lucide-react';
import { PageView, LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface NavbarProps {
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  currentLang: LanguageCode;
  setCurrentLang: (lang: LanguageCode) => void;
  openAdminModal: () => void;
  openAIAssistant: () => void;
  isAdminAuthenticated: boolean;
  onSelectCourse?: (courseId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  currentLang,
  setCurrentLang,
  openAdminModal,
  openAIAssistant,
  isAdminAuthenticated
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;

  const navLinks: { id: PageView; label: string; icon?: React.ReactNode }[] = [
    { id: 'home', label: t.navHome },
    { id: 'courses', label: t.navCourses },
    { id: 'about-us', label: t.navAboutUs },
    { id: 'mission', label: t.navMission },
    { id: 'about-ceo', label: t.navAboutCEO, icon: <User className="w-3.5 h-3.5 mr-1 text-amber-600" /> },
    { id: 'verification', label: t.navVerify, icon: <ShieldCheck className="w-3.5 h-3.5 mr-1 text-blue-600" /> }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs backdrop-blur-xs no-print">
      {/* Top Banner Notice */}
      <div className="bg-slate-900 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-amber-500/20 text-amber-300 border border-amber-500/30">
              100% Free
            </span>
            <span className="hidden sm:inline text-slate-300">
              182 Comprehensive Tracks with Verified YouTube Playlists & Free Certification
            </span>
            <span className="sm:hidden text-slate-300">
              182 Free Tech Tracks & Verified Certificates
            </span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setCurrentPage('about-ceo')}
              className="hover:text-amber-300 transition-colors flex items-center gap-1 text-[11px]"
            >
              <HeartHandshake className="w-3 h-3 text-amber-400" />
              <span>Founder: Muhammad Talha</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => setCurrentPage('home')}
              className="flex items-center gap-2.5 text-left group focus:outline-hidden"
              id="nav-brand-logo"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-700 text-white flex items-center justify-center shadow-md shadow-blue-700/20 group-hover:bg-blue-800 transition-colors">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xl tracking-tight text-slate-900">
                    Learn With Flow
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 border border-amber-300">
                    PRO
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium hidden md:block">
                  Coursera-Standard Open Learning
                </p>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1">
              {navLinks.map((link) => {
                const isActive = currentPage === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => setCurrentPage(link.id)}
                    className={`px-3 py-2 rounded-md text-sm font-semibold transition-colors flex items-center ${
                      isActive
                        ? 'text-blue-700 bg-blue-50/80 font-bold'
                        : 'text-slate-600 hover:text-blue-700 hover:bg-slate-50'
                    }`}
                    id={`nav-link-${link.id}`}
                  >
                    {link.icon}
                    {link.label}
                    {link.id === 'courses' && (
                      <span className="ml-1.5 text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
                        182
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Language Selector */}
            <div className="relative flex items-center">
              <label htmlFor="language-select" className="sr-only">Select Language</label>
              <Globe className="w-4 h-4 text-slate-400 absolute left-2.5 pointer-events-none" />
              <select
                id="language-select"
                value={currentLang}
                onChange={(e) => setCurrentLang(e.target.value as LanguageCode)}
                className="pl-8 pr-3 py-1.5 text-xs font-semibold bg-slate-50 text-slate-700 border border-slate-200 rounded-md hover:border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 cursor-pointer"
              >
                <option value="en">English</option>
                <option value="ur">اردو (Urdu)</option>
                <option value="hi">हिन्दी (Hindi)</option>
                <option value="ar">العربية (Arabic)</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
              </select>
            </div>

            {/* AI Assistant Button */}
            <button
              onClick={openAIAssistant}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-bold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100/80 hover:border-blue-300 shadow-2xs transition-all active:scale-98"
              id="btn-ai-assistant-header"
              title="Open AI Learning Assistant"
            >
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span className="hidden sm:inline">{t.navAssistant}</span>
              <span className="sm:hidden">AI Bot</span>
            </button>

            {/* Admin / Owner Button */}
            <button
              onClick={openAdminModal}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-semibold rounded-lg border transition-all ${
                isAdminAuthenticated
                  ? 'bg-amber-500 text-white border-amber-600 hover:bg-amber-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50 hover:border-slate-400'
              }`}
              id="btn-admin-login-header"
              title="Owner / Admin Portal"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isAdminAuthenticated ? 'Owner Dashboard' : t.navAdmin}</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              aria-label="Toggle navigation menu"
              id="btn-mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-6 space-y-2 shadow-lg">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                setCurrentPage(link.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2.5 rounded-md text-sm font-semibold flex items-center justify-between ${
                currentPage === link.id
                  ? 'bg-blue-50 text-blue-700 font-bold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="flex items-center">
                {link.icon}
                {link.label}
              </span>
              {link.id === 'courses' && (
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                  182 Tracks
                </span>
              )}
            </button>
          ))}
          
          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                openAIAssistant();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-md bg-blue-600 text-white text-sm font-bold"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch AI Learning Assistant</span>
            </button>
            <button
              onClick={() => {
                openAdminModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-md border border-slate-300 text-slate-700 text-sm font-semibold"
            >
              <Lock className="w-4 h-4" />
              <span>{isAdminAuthenticated ? 'Go to Owner Dashboard' : 'Owner Login'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
