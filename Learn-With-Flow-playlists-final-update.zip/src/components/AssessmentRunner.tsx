import React, { useState } from 'react';
import { CheckCircle, XCircle, Award, AlertTriangle, ArrowRight, RotateCcw, HelpCircle, Check, X } from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuizQuestion, Course } from '../types';

interface AssessmentRunnerProps {
  type: 'lesson-quiz' | 'module-assessment' | 'final-exam';
  title: string;
  subtitle: string;
  questions: QuizQuestion[];
  course: Course;
  onPass: (scorePercentage: number, studentName?: string) => void;
  onClose: () => void;
}

export const AssessmentRunner: React.FC<AssessmentRunnerProps> = ({
  type,
  title,
  subtitle,
  questions,
  course,
  onPass,
  onClose
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [studentNameInput, setStudentNameInput] = useState('');
  const [isGeneratingCert, setIsGeneratingCert] = useState(false);

  const passingThreshold = type === 'final-exam' ? 80 : 70;
  const currentQ = questions[currentIndex];
  const isLast = currentIndex === questions.length - 1;

  const handleSelect = (optionIdx: number) => {
    if (submitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionIdx
    }));
  };

  const calculateScore = () => {
    let correctCount = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });
    return Math.round((correctCount / questions.length) * 100);
  };

  const handleCompleteSubmit = () => {
    setSubmitted(true);
    const score = calculateScore();
    if (score >= passingThreshold) {
      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        // ignore
      }
    }
  };

  const scorePercentage = submitted ? calculateScore() : 0;
  const passed = scorePercentage >= passingThreshold;

  const handleClaimCertificate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentNameInput.trim()) return;

    setIsGeneratingCert(true);
    onPass(scorePercentage, studentNameInput.trim());
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden my-6 no-print">
      {/* Assessment Header */}
      <div className="bg-slate-900 text-white p-6 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30 mb-2">
            {type === 'lesson-quiz' && '8-Question Lesson Quiz'}
            {type === 'module-assessment' && '15-Question Module Assessment'}
            {type === 'final-exam' && '25-Question Final Comprehensive Exam'}
          </div>
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Requirement</span>
            <span className="text-sm font-bold text-amber-300">{passingThreshold}% to Pass</span>
          </div>
          <button
            onClick={onClose}
            className="text-xs px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            Exit Assessment
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-100 h-1.5">
        <div 
          className="bg-blue-600 h-1.5 transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {!submitted ? (
        <div className="p-6 md:p-8">
          {/* Question Meta */}
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-3">
            <span>Question {currentIndex + 1} of {questions.length}</span>
            <span>Course: {course.title}</span>
          </div>

          {/* Question Text */}
          <h3 className="text-base md:text-lg font-bold text-slate-900 leading-snug mb-6">
            {currentQ.question}
          </h3>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {currentQ.options.map((opt, oIdx) => {
              const isSelected = selectedAnswers[currentIndex] === oIdx;
              return (
                <button
                  key={oIdx}
                  onClick={() => handleSelect(oIdx)}
                  className={`w-full text-left p-4 rounded-xl border text-xs md:text-sm font-medium transition-all flex items-center justify-between ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 ring-2 ring-blue-600/20 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                      isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {String.fromCharCode(65 + oIdx)}
                    </span>
                    <span>{opt}</span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-blue-600 shrink-0 ml-2" />}
                </button>
              );
            })}
          </div>

          {/* Question Stepper Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Previous
            </button>

            <div className="flex items-center gap-2">
              {!isLast ? (
                <button
                  onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))}
                  disabled={selectedAnswers[currentIndex] === undefined}
                  className="px-5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span>Next Question</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  onClick={handleCompleteSubmit}
                  disabled={Object.keys(selectedAnswers).length < questions.length}
                  className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span>Submit Assessment</span>
                  <CheckCircle className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Results View */
        <div className="p-6 md:p-8">
          <div className={`p-6 rounded-xl text-center border mb-8 ${
            passed 
              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' 
              : 'bg-rose-50/70 border-rose-200 text-rose-950'
          }`}>
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 ${
              passed ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
            }`}>
              {passed ? <Award className="w-8 h-8" /> : <XCircle className="w-8 h-8" />}
            </div>

            <h3 className="text-xl font-bold">
              {passed ? 'Assessment Passed Successfully!' : 'Passing Standard Not Met'}
            </h3>
            
            <p className="text-sm font-medium mt-1">
              Your Score: <strong className="text-lg">{scorePercentage}%</strong> (Required: {passingThreshold}%)
            </p>

            <p className="text-xs text-slate-600 max-w-md mx-auto mt-2">
              {passed 
                ? (type === 'final-exam' 
                    ? 'Congratulations! You have satisfied all rigorous testing criteria. Please provide your full name below to issue your verified digital certificate.' 
                    : 'Great job! Your progress and scores have been recorded in your student profile.')
                : 'Review the technical explanations below to strengthen your understanding, then retry the assessment.'}
            </p>
          </div>

          {/* If final exam passed: Student Name input for real certificate */}
          {passed && type === 'final-exam' && (
            <div className="bg-slate-50 border border-blue-200 rounded-xl p-6 mb-8 max-w-lg mx-auto shadow-xs">
              <h4 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-blue-600" />
                <span>Issue Your Official Verified Certificate</span>
              </h4>
              <p className="text-xs text-slate-500 mb-4">
                This name will be cryptographically registered in the official Learn With Flow database and printed onto your completion diploma.
              </p>

              <form onSubmit={handleClaimCertificate} className="space-y-3">
                <div>
                  <label htmlFor="student-name-cert-input" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Student Full Name
                  </label>
                  <input
                    id="student-name-cert-input"
                    type="text"
                    required
                    value={studentNameInput}
                    onChange={(e) => setStudentNameInput(e.target.value)}
                    placeholder="e.g. Muhammad Farooq, Jane Doe"
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!studentNameInput.trim() || isGeneratingCert}
                  className="w-full py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors shadow-sm disabled:opacity-50"
                >
                  {isGeneratingCert ? 'Registering Certificate...' : 'Generate & View Official Certificate'}
                </button>
              </form>
            </div>
          )}

          {/* Action buttons if not final exam or passed regular quiz */}
          {(!passed || type !== 'final-exam') && (
            <div className="flex items-center justify-center gap-4 mb-8">
              {!passed ? (
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setCurrentIndex(0);
                    setSelectedAnswers({});
                  }}
                  className="px-5 py-2.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retry Assessment</span>
                </button>
              ) : (
                <button
                  onClick={() => onPass(scorePercentage)}
                  className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                >
                  <span>Continue Curriculum</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* Question-by-Question Review */}
          <div className="mt-8 pt-6 border-t border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-4">Detailed Answer Review</h4>
            <div className="space-y-4">
              {questions.map((q, idx) => {
                const userAns = selectedAnswers[idx];
                const isCorrect = userAns === q.correctIndex;
                return (
                  <div key={idx} className={`p-4 rounded-xl border text-xs leading-relaxed ${
                    isCorrect ? 'bg-emerald-50/40 border-emerald-200' : 'bg-rose-50/40 border-rose-200'
                  }`}>
                    <div className="flex items-center justify-between font-bold mb-1">
                      <span className="text-slate-800">Question {idx + 1}: {q.question}</span>
                      <span className={isCorrect ? 'text-emerald-700 font-bold' : 'text-rose-700 font-bold'}>
                        {isCorrect ? '✓ Correct' : '✗ Incorrect'}
                      </span>
                    </div>

                    <div className="text-slate-600 mt-1">
                      <span>Your Answer: <strong>{q.options[userAns] ?? 'Unanswered'}</strong></span>
                    </div>

                    {!isCorrect && (
                      <div className="text-emerald-800 font-semibold mt-0.5">
                        <span>Correct Answer: {q.options[q.correctIndex]}</span>
                      </div>
                    )}

                    <div className="mt-2 pt-2 border-t border-slate-200/60 text-slate-500 italic">
                      Rationale: {q.explanation}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
