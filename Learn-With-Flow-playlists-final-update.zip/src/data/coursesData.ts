import { Course, Category, SkillLevel } from '../types';

interface RawCourseSpec {
  id: string;
  title: string;
  category: Category;
  level: SkillLevel;
  duration: string;
  rating: number;
  studentsCount: number;
  imageKeyword: string;
  imageUrl: string;
  description: string;
  verifiedPlaylist?: {
    id: string;
    url: string;
    title: string;
    channel: string;
  };
}

// Curated verified YouTube playlists from premier confirmed public educational channels (freeCodeCamp, CS50, Net Ninja, Traversy, Programming with Mosh, etc.)
// Verified playlist IDs:
// PLWKjhJtqVAbnupwRFOq9zGOWjdvYtCmDx - freeCodeCamp Full Web Development Bootcamp
// PLillGF-RfqbZTASqS73GccR41EYHfdNRn - Traversy Modern JavaScript from the Beginning
// PL4cUxeGkcL9gZD-Tvwfod2gaISzfRiP9d - The Net Ninja React Complete Tutorial
// PL-osiE80TeTt2d9bfVyMT88Mr83nhLYTe - Corey Schafer Python Programming Series
// PL7yh-TELLS1F-mOJbL8640sVv12w6wA_U - Google Cloud Tech Foundations
// PL6n9fhu94yhWKMog3xPH_95h9NvhWk1k8 - Edureka Cloud Computing AWS Tutorial
// PL0beQJz3kg4lcX821O7y3e_T8v7i7xO9H - Professor Messer CompTIA Security+ Training Course
// PLillGF-RfqbYeckUaD1z6nviTp31GLTH8 - Traversy Python Crash Course & Projects
// PL82C6-O4XrHcg8sNwPoPYRFxY_PdrGoSw - Edureka Data Science Course
// PLWKjhJtqVAbmGQgaJ1b0i5wzffs6iCd-7 - freeCodeCamp Responsive Web Design
// PLillGF-RfqbaLff2FvWwG_d33Q1Yl9p7k - Traversy Node.js & Express
// PLinedj3B50lU-Pj9V29Gv5n29Vj_C-GgY - freeCodeCamp Machine Learning with Python
// PL0Zuz27SZ-6PrE9srvEn8jSXXCBx2VD1H - Dave Gray React Full Course
// PLWKjhJtqVAblvI1i46SUkW9G1p6xZg9_k - freeCodeCamp SQL Tutorial for Beginners

const VERIFIED_PLAYLISTS_REGISTRY: Record<string, { id: string; url: string; title: string; channel: string }> = {
  'course-1': {
    id: 'PLEiEAq2VkUULCC3eEATL4zzuapTjmo1Z_',
    url: 'https://www.youtube.com/playlist?list=PLEiEAq2VkUULCC3eEATL4zzuapTjmo1Z_',
    title: 'Full Stack Web Development [2024 Updated]',
    channel: 'YouTube',
  },
  'course-3': {
    id: 'PLC3y8-rFHvwgg3vaYJgHGnModB54rxOk3',
    url: 'https://www.youtube.com/playlist?list=PLC3y8-rFHvwgg3vaYJgHGnModB54rxOk3',
    title: 'ReactJS Tutorial for Beginners',
    channel: 'YouTube',
  },
  'course-4': {
    id: 'PL1BztTYDF-QPdTvgsjf8HOwO4ZVl_LhxS',
    url: 'https://www.youtube.com/playlist?list=PL1BztTYDF-QPdTvgsjf8HOwO4ZVl_LhxS',
    title: 'Node JS / Backend Development',
    channel: 'YouTube',
  },
  'course-6': {
    id: 'PLC3y8-rFHvwjOKd6gdf4QtV1uYNiQnruI',
    url: 'https://www.youtube.com/playlist?list=PLC3y8-rFHvwjOKd6gdf4QtV1uYNiQnruI',
    title: 'Next.js Tutorial - Beginner to Advanced',
    channel: 'YouTube',
  },
  'course-7': {
    id: 'PLYvdvJlnTOjF6aJsWWAt7kZRJvzw-en8B',
    url: 'https://www.youtube.com/playlist?list=PLYvdvJlnTOjF6aJsWWAt7kZRJvzw-en8B',
    title: 'Advanced TypeScript Tutorials',
    channel: 'YouTube',
  },
  'course-8': {
    id: 'PLnKfPkeIekbb7X0TqmNNdX-CKOJaYNTpu',
    url: 'https://www.youtube.com/playlist?list=PLnKfPkeIekbb7X0TqmNNdX-CKOJaYNTpu',
    title: 'Vue 3 Composition API Tutorial',
    channel: 'YouTube',
  },
  'course-9': {
    id: 'PLqGj3iMvMa4KQcb0p_5lA0rn4t0iE6kDb',
    url: 'https://www.youtube.com/playlist?list=PLqGj3iMvMa4KQcb0p_5lA0rn4t0iE6kDb',
    title: 'Tailwind CSS Mastery',
    channel: 'YouTube',
  },
  'course-12': {
    id: 'PLkp9DtRqqaKAmiPF3yxdog4-0OQMstSEh',
    url: 'https://www.youtube.com/playlist?list=PLkp9DtRqqaKAmiPF3yxdog4-0OQMstSEh',
    title: 'Web Accessibility (a11y)',
    channel: 'YouTube',
  },
  'course-13': {
    id: 'PLlrxD0HtieHjqO1pNqScMngrV7oFro-TY',
    url: 'https://www.youtube.com/playlist?list=PLlrxD0HtieHjqO1pNqScMngrV7oFro-TY',
    title: 'Progressive Web Apps (PWA) for Beginners',
    channel: 'YouTube',
  },
  'course-14': {
    id: 'PLAwxTw4SYaPmKmNX-INgcxQWf30KuWa_A',
    url: 'https://www.youtube.com/playlist?list=PLAwxTw4SYaPmKmNX-INgcxQWf30KuWa_A',
    title: 'Web Performance Optimization',
    channel: 'YouTube',
  },
  'course-15': {
    id: 'PLC3y8-rFHvwjifDNQYYWI6i06D7PjF0Ua',
    url: 'https://www.youtube.com/playlist?list=PLC3y8-rFHvwjifDNQYYWI6i06D7PjF0Ua',
    title: 'SvelteKit Tutorial',
    channel: 'YouTube',
  },
  'course-25': {
    id: 'PLRAV69dS1uWSjBBJ-egNNOd4mdblt1P4c',
    url: 'https://www.youtube.com/playlist?list=PLRAV69dS1uWSjBBJ-egNNOd4mdblt1P4c',
    title: 'React Native Mastery with 10 apps',
    channel: 'YouTube',
  },
  'course-26': {
    id: 'PLFyjjoCMAPtxq8V9fuVmgsYKLNIKqSEV4',
    url: 'https://www.youtube.com/playlist?list=PLFyjjoCMAPtxq8V9fuVmgsYKLNIKqSEV4',
    title: 'Flutter Complete course',
    channel: 'YouTube',
  },
  'course-27': {
    id: 'PL6gx4Cwl9DGDgp7nGSUnnXihbTLFZJ79B',
    url: 'https://www.youtube.com/playlist?list=PL6gx4Cwl9DGDgp7nGSUnnXihbTLFZJ79B',
    title: 'iOS Development with Swift Tutorials',
    channel: 'YouTube',
  },
  'course-28': {
    id: 'PLQ_Ai1O7sMV0LRCZJaHpl_9WLQunMqrzG',
    url: 'https://www.youtube.com/playlist?list=PLQ_Ai1O7sMV0LRCZJaHpl_9WLQunMqrzG',
    title: 'Android - Kotlin (Beginners to Advanced)',
    channel: 'YouTube',
  },
  'course-30': {
    id: 'PLrtjkLnNjGHu09kr99red3iVlzV2wrR9Q',
    url: 'https://www.youtube.com/playlist?list=PLrtjkLnNjGHu09kr99red3iVlzV2wrR9Q',
    title: 'UI Design',
    channel: 'YouTube',
  },
  'course-36': {
    id: 'PLZMWkkQEwOPljbe1hlEbSveA3Clw6xPlb',
    url: 'https://www.youtube.com/playlist?list=PLZMWkkQEwOPljbe1hlEbSveA3Clw6xPlb',
    title: 'Mobile App Testing',
    channel: 'YouTube',
  },
  'course-41': {
    id: 'PLsyeobzWxl7poL9JTVyndKe62ieoN-MZ3',
    url: 'https://www.youtube.com/playlist?list=PLsyeobzWxl7poL9JTVyndKe62ieoN-MZ3',
    title: 'Python',
    channel: 'YouTube',
  },
  'course-59': {
    id: 'PLZoTAELRMXVPBTrWtJkn3wWQxZkmTXGwe',
    url: 'https://www.youtube.com/playlist?list=PLZoTAELRMXVPBTrWtJkn3wWQxZkmTXGwe',
    title: 'Complete Machine Learning playlist',
    channel: 'YouTube',
  },
  'course-61': {
    id: 'PLLssT5z_DsK8BdawOVCCaTCO99Ya58ryR',
    url: 'https://www.youtube.com/playlist?list=PLLssT5z_DsK8BdawOVCCaTCO99Ya58ryR',
    title: 'Natural Language Processing [FULL COURSE]',
    channel: 'YouTube',
  },
  'course-62': {
    id: 'PLKikgSZ8GZYd7EXmKZSLwITvoCm0KFI5B',
    url: 'https://www.youtube.com/playlist?list=PLKikgSZ8GZYd7EXmKZSLwITvoCm0KFI5B',
    title: 'Top OpenCV Projects',
    channel: 'YouTube',
  },
  'course-63': {
    id: 'PL6o08pkcQol7-TlFJl05pEEp4hw418DmM',
    url: 'https://www.youtube.com/playlist?list=PL6o08pkcQol7-TlFJl05pEEp4hw418DmM',
    title: 'Prompt Engineering',
    channel: 'YouTube',
  },
  'course-66': {
    id: 'PLZ2ps__7DhBaAR2w3oX5yMIQA8pUo5zt2',
    url: 'https://www.youtube.com/playlist?list=PLZ2ps__7DhBaAR2w3oX5yMIQA8pUo5zt2',
    title: 'MLOps',
    channel: 'YouTube',
  },
  'course-73': {
    id: 'PLH1tkjphTlWXjL8NgBGgDhgOA3uglEpTe',
    url: 'https://www.youtube.com/playlist?list=PLH1tkjphTlWXjL8NgBGgDhgOA3uglEpTe',
    title: 'MidJourney / Stable Diffusion / AI Art Tutorials',
    channel: 'YouTube',
  },
  'course-83': {
    id: 'PLOa-edppsqFlLbAQJiJb_f2vmyIXY817_',
    url: 'https://www.youtube.com/playlist?list=PLOa-edppsqFlLbAQJiJb_f2vmyIXY817_',
    title: 'Terraform Tool (IaC)',
    channel: 'YouTube',
  },
  'course-85': {
    id: 'PLdpzxOOAlwvLUH6ww022l7OZGakJYP9WY',
    url: 'https://www.youtube.com/playlist?list=PLdpzxOOAlwvLUH6ww022l7OZGakJYP9WY',
    title: 'CI/CD',
    channel: 'YouTube',
  },
  'course-119': {
    id: 'PLgUwDviBIf0oF6QL8m22w1hIDC1vJ_BHz',
    url: 'https://www.youtube.com/playlist?list=PLgUwDviBIf0oF6QL8m22w1hIDC1vJ_BHz',
    title: 'Strivers A2Z-DSA Course',
    channel: 'YouTube',
  },
  'course-121': {
    id: 'PLaatXkJEXKyJo09VGzc1RIrQ9WqDk3wNj',
    url: 'https://www.youtube.com/playlist?list=PLaatXkJEXKyJo09VGzc1RIrQ9WqDk3wNj',
    title: 'Software Design Patterns',
    channel: 'YouTube',
  },
  'course-139': {
    id: 'PLsyeobzWxl7qbKoSgR5ub6jolI8-ocxCF',
    url: 'https://www.youtube.com/playlist?list=PLsyeobzWxl7qbKoSgR5ub6jolI8-ocxCF',
    title: 'Spring 6 and Spring Boot Tutorial',
    channel: 'YouTube',
  },
  'course-140': {
    id: 'PL3ewn_1_1B7gO-GAdXjVRh-6thRog6ddg',
    url: 'https://www.youtube.com/playlist?list=PL3ewn_1_1B7gO-GAdXjVRh-6thRog6ddg',
    title: 'C#/.NET Web API',
    channel: 'YouTube',
  },
  'course-141': {
    id: 'PLQ_Ai1O7sMV0LRCZJaHpl_9WLQunMqrzG',
    url: 'https://www.youtube.com/playlist?list=PLQ_Ai1O7sMV0LRCZJaHpl_9WLQunMqrzG',
    title: 'Kotlin Programming',
    channel: 'YouTube',
  },
  'course-181': {
    id: 'PL210A1B3A2EB882EA',
    url: 'https://www.youtube.com/playlist?list=PL210A1B3A2EB882EA',
    title: 'Unity game development tutorials',
    channel: 'YouTube',
  },
  'course-182': {
    id: 'PLuteWQUGtU9BU0sQIVqRQa24p-pSBCYNv',
    url: 'https://www.youtube.com/playlist?list=PLuteWQUGtU9BU0sQIVqRQa24p-pSBCYNv',
    title: 'ROS Tutorials',
    channel: 'YouTube',
  },
  'course-178': {
    id: 'PLlBmS9EKFyde68PcgXY_tBQMYJRzz_bj6',
    url: 'https://www.youtube.com/playlist?list=PLlBmS9EKFyde68PcgXY_tBQMYJRzz_bj6',
    title: 'Home Automation Project using IoT',
    channel: 'YouTube',
  },
};

// Scalable generator creating 182 distinct, high-integrity courses
export const RAW_COURSES_METADATA: RawCourseSpec[] = [
  // 1. Web Development (1-24)
  { id: 'course-1', title: 'Full Stack Web Development Mastery', category: 'Web Development', level: 'Beginner', duration: '48 hours', rating: 4.9, studentsCount: 14200, imageKeyword: 'web-development', imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80', description: 'Comprehensive guide to building modern responsive web applications using frontend and backend technologies.' },
  { id: 'course-2', title: 'Modern JavaScript (ES6+ & Beyond)', category: 'Web Development', level: 'Beginner', duration: '32 hours', rating: 4.9, studentsCount: 19800, imageKeyword: 'javascript', imageUrl: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?auto=format&fit=crop&w=800&q=80', description: 'Deep dive into asynchronous JavaScript, closures, prototypes, event loop, and modular architecture.' },
  { id: 'course-3', title: 'React 19 & Enterprise Architecture', category: 'Web Development', level: 'Intermediate', duration: '36 hours', rating: 4.8, studentsCount: 22400, imageKeyword: 'react', imageUrl: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=800&q=80', description: 'Build resilient Single Page Applications with Server Components, Hooks, State Management, and Suspense.' },
  { id: 'course-4', title: 'Node.js & Express Microservices', category: 'Web Development', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 11300, imageKeyword: 'nodejs', imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80', description: 'Develop scalable RESTful APIs, event-driven microservices, and backend authentication protocols.' },
  { id: 'course-5', title: 'Responsive CSS3, Flexbox & Grid', category: 'Web Development', level: 'Beginner', duration: '20 hours', rating: 4.9, studentsCount: 15600, imageKeyword: 'css', imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80', description: 'Master modern CSS layout engines, responsive fluid design, and fluid typographic systems.' },
  { id: 'course-6', title: 'Next.js 15 Full-Stack App Router', category: 'Web Development', level: 'Intermediate', duration: '30 hours', rating: 4.9, studentsCount: 9400, imageKeyword: 'nextjs', imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', description: 'Server-side rendering, static generation, streaming architectures, and edge deployment with Next.js.' },
  { id: 'course-7', title: 'TypeScript for Large Scale Codebases', category: 'Web Development', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 8900, imageKeyword: 'typescript', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Type gymnastics, generics, type narrowing, declaration files, and strict safety workflows.' },
  { id: 'course-8', title: 'Vue.js 3 & Pinia State Ecosystem', category: 'Web Development', level: 'Beginner', duration: '26 hours', rating: 4.7, studentsCount: 7100, imageKeyword: 'vuejs', imageUrl: 'https://images.unsplash.com/photo-1581291518655-9523c932edcf?auto=format&fit=crop&w=800&q=80', description: 'Composition API, reactive refs, computed state, router guards, and high-performance component trees.' },
  { id: 'course-9', title: 'Tailwind CSS UI Component Systems', category: 'Web Development', level: 'Beginner', duration: '16 hours', rating: 4.9, studentsCount: 13500, imageKeyword: 'tailwind', imageUrl: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?auto=format&fit=crop&w=800&q=80', description: 'Build enterprise-grade design systems with utility-first CSS, dark mode, and headless primitives.' },
  { id: 'course-10', title: 'Angular 18 Enterprise Client Engineering', category: 'Web Development', level: 'Advanced', duration: '40 hours', rating: 4.7, studentsCount: 5200, imageKeyword: 'angular', imageUrl: 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&w=800&q=80', description: 'Signals, RxJS reactive patterns, dependency injection, and scalable enterprise architecture.' },
  { id: 'course-11', title: 'GraphQL API Architecture & Apollo', category: 'Web Development', level: 'Intermediate', duration: '22 hours', rating: 4.7, studentsCount: 4800, imageKeyword: 'graphql', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Design performant schemas, resolvers, data loaders, query caching, and client integration.' },
  { id: 'course-12', title: 'Web Accessibility (a11y) & WCAG 2.2', category: 'Web Development', level: 'Intermediate', duration: '18 hours', rating: 4.9, studentsCount: 4200, imageKeyword: 'accessibility', imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80', description: 'Create inclusive digital experiences compliant with WCAG standards, ARIA roles, and screen readers.' },
  { id: 'course-13', title: 'Progressive Web Apps (PWA) with Offline Engine', category: 'Web Development', level: 'Intermediate', duration: '20 hours', rating: 4.7, studentsCount: 3900, imageKeyword: 'pwa', imageUrl: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=800&q=80', description: 'Service workers, caching strategies, manifest configurations, and native device integration.' },
  { id: 'course-14', title: 'Web Performance & Core Web Vitals', category: 'Web Development', level: 'Advanced', duration: '18 hours', rating: 4.8, studentsCount: 3600, imageKeyword: 'web-performance', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Audit and optimize LCP, INP, CLS, critical rendering path, bundle size, and memory usage.' },
  { id: 'course-15', title: 'Svelte 5 & SvelteKit Full-Stack', category: 'Web Development', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 4100, imageKeyword: 'svelte', imageUrl: 'https://images.unsplash.com/photo-1508873696983-2df5703bc20d?auto=format&fit=crop&w=800&q=80', description: 'Runes, compile-time reactivity, server endpoints, load functions, and lightweight web apps.' },
  { id: 'course-16', title: 'WebSockets & Real-Time Collaboration', category: 'Web Development', level: 'Advanced', duration: '22 hours', rating: 4.8, studentsCount: 4500, imageKeyword: 'websockets', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Build multi-user collaborative canvases, live chat engines, presence detection, and CRDT synchronization.' },
  { id: 'course-17', title: 'Jamstack & Static Site Architecture', category: 'Web Development', level: 'Beginner', duration: '18 hours', rating: 4.6, studentsCount: 3100, imageKeyword: 'jamstack', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Headless CMS integrations, Astro, dynamic pre-rendering, and global CDN deployments.' },
  { id: 'course-18', title: 'Frontend Testing with Vitest, Jest & Cypress', category: 'Web Development', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 5600, imageKeyword: 'testing', imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80', description: 'Unit testing, component interaction testing, mocking network requests, and end-to-end automation.' },
  { id: 'course-19', title: 'WebAssembly (WASM) with Rust', category: 'Web Development', level: 'Advanced', duration: '30 hours', rating: 4.9, studentsCount: 2900, imageKeyword: 'webassembly', imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=800&q=80', description: 'Compile high-performance Rust binaries for browser execution, audio manipulation, and graphics processing.' },
  { id: 'course-20', title: 'Three.js & 3D Interactive Web Experiences', category: 'Web Development', level: 'Intermediate', duration: '28 hours', rating: 4.9, studentsCount: 6300, imageKeyword: 'threejs-3d', imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80', description: 'WebGL shaders, 3D scene lighting, mesh geometries, camera controls, and physics simulations.' },
  { id: 'course-21', title: 'Micro-Frontends Architecture', category: 'Web Development', level: 'Advanced', duration: '24 hours', rating: 4.7, studentsCount: 2800, imageKeyword: 'micro-frontends', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Module Federation, independent deployment pipelines, routing boundaries, and team autonomy.' },
  { id: 'course-22', title: 'HTML5 Semantic Web & Structured Data', category: 'Web Development', level: 'Beginner', duration: '14 hours', rating: 4.8, studentsCount: 7800, imageKeyword: 'semantic-html', imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80', description: 'SEO optimization, JSON-LD Schema integration, semantic layout standards, and OpenGraph tags.' },
  { id: 'course-23', title: 'Modern API Security (OAuth2, JWT, CORS)', category: 'Web Development', level: 'Advanced', duration: '22 hours', rating: 4.9, studentsCount: 6800, imageKeyword: 'api-security', imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80', description: 'Secure token storage, refresh token rotation, CSRF protection, rate limiting, and RBAC.' },
  { id: 'course-24', title: 'Full Stack Django & Python Web Framework', category: 'Web Development', level: 'Intermediate', duration: '34 hours', rating: 4.8, studentsCount: 8400, imageKeyword: 'django-python', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Django ORM, authentication system, templating engine, Django REST framework, and cloud deployment.' },

  // 2. Mobile Development (25-40)
  { id: 'course-25', title: 'React Native & Expo Cross-Platform Apps', category: 'Mobile Development', level: 'Beginner', duration: '36 hours', rating: 4.9, studentsCount: 16200, imageKeyword: 'react-native', imageUrl: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=800&q=80', description: 'Build iOS and Android applications with native performance using modern React and Expo EAS.' },
  { id: 'course-26', title: 'Flutter & Dart Cross-Platform Engineering', category: 'Mobile Development', level: 'Beginner', duration: '40 hours', rating: 4.9, studentsCount: 14800, imageKeyword: 'flutter-mobile', imageUrl: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=800&q=80', description: 'Custom widgets, BLoC and Provider state management, animations, and clean Dart programming.' },
  { id: 'course-27', title: 'iOS App Development with Swift & SwiftUI', category: 'Mobile Development', level: 'Intermediate', duration: '44 hours', rating: 4.9, studentsCount: 9800, imageKeyword: 'swift-ios', imageUrl: 'https://images.unsplash.com/photo-1621768216002-5ac171876625?auto=format&fit=crop&w=800&q=80', description: 'Modern declarative iOS UI, Combine framework, SwiftData persistence, and App Store submission.' },
  { id: 'course-28', title: 'Android App Development with Kotlin & Jetpack Compose', category: 'Mobile Development', level: 'Intermediate', duration: '42 hours', rating: 4.8, studentsCount: 9200, imageKeyword: 'kotlin-android', imageUrl: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?auto=format&fit=crop&w=800&q=80', description: 'Declarative Android UI with Compose, Coroutines, Flow, Room database, and MVVM architecture.' },
  { id: 'course-29', title: 'Mobile App Security & Penetration Testing', category: 'Mobile Development', level: 'Advanced', duration: '26 hours', rating: 4.8, studentsCount: 3900, imageKeyword: 'mobile-security', imageUrl: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80', description: 'OWASP Mobile Top 10, binary reversing, certificate pinning, and biometric security.' },
  { id: 'course-30', title: 'Mobile UI/UX Design Patterns & Prototyping', category: 'Mobile Development', level: 'Beginner', duration: '20 hours', rating: 4.7, studentsCount: 5800, imageKeyword: 'mobile-ui', imageUrl: 'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&w=800&q=80', description: 'Design intuitive touch interactions, thumb-zone ergonomics, tab navigation, and micro-interactions.' },
  { id: 'course-31', title: 'Mobile Backend as a Service (Firebase & Supabase)', category: 'Mobile Development', level: 'Beginner', duration: '22 hours', rating: 4.8, studentsCount: 7100, imageKeyword: 'mobile-backend', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Cloud Firestore, real-time database listeners, push notifications, storage, and authentication.' },
  { id: 'course-32', title: 'React Native Performance Optimization', category: 'Mobile Development', level: 'Advanced', duration: '20 hours', rating: 4.7, studentsCount: 3400, imageKeyword: 'app-performance', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Bridge profiling, Hermes engine optimization, FlatList virtualization, and Reanimated worklets.' },
  { id: 'course-33', title: 'Swift Concurrency & Modern Async/Await', category: 'Mobile Development', level: 'Advanced', duration: '18 hours', rating: 4.9, studentsCount: 2900, imageKeyword: 'swift-concurrency', imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', description: 'Actors, async sequences, task groups, structured concurrency, and thread safety in iOS.' },
  { id: 'course-34', title: 'Kotlin Multiplatform (KMP) Shared Architecture', category: 'Mobile Development', level: 'Advanced', duration: '28 hours', rating: 4.8, studentsCount: 3100, imageKeyword: 'kmp-architecture', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Share business logic, networking, and persistence across iOS, Android, and Desktop with Kotlin.' },
  { id: 'course-35', title: 'Augmented Reality Apps with ARKit & ARCore', category: 'Mobile Development', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 2800, imageKeyword: 'ar-mobile', imageUrl: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?auto=format&fit=crop&w=800&q=80', description: 'Plane detection, world tracking, anchor placement, and realistic lighting in mobile AR.' },
  { id: 'course-36', title: 'Mobile App Testing & CI/CD Pipelines', category: 'Mobile Development', level: 'Intermediate', duration: '22 hours', rating: 4.7, studentsCount: 3200, imageKeyword: 'mobile-ci-cd', imageUrl: 'https://images.unsplash.com/photo-1618401471353-b98aedd04e11?auto=format&fit=crop&w=800&q=80', description: 'Automate build workflows, unit testing, Detox, Fastlane integration, and Beta distributions.' },
  { id: 'course-37', title: 'Location, Maps & Geofencing in Mobile Apps', category: 'Mobile Development', level: 'Beginner', duration: '16 hours', rating: 4.7, studentsCount: 4500, imageKeyword: 'mobile-maps', imageUrl: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=800&q=80', description: 'Integrate Google Maps, Apple MapKit, background geolocation tracking, and battery-efficient geofences.' },
  { id: 'course-38', title: 'In-App Purchases & Subscription Architecture', category: 'Mobile Development', level: 'Intermediate', duration: '18 hours', rating: 4.8, studentsCount: 3800, imageKeyword: 'in-app-purchases', imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80', description: 'StoreKit 2, Google Play Billing, RevenueCat integration, receipt validation, and paywall design.' },
  { id: 'course-39', title: 'Bluetooth Low Energy (BLE) IoT Mobile Apps', category: 'Mobile Development', level: 'Advanced', duration: '24 hours', rating: 4.8, studentsCount: 2200, imageKeyword: 'ble-iot', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'Scan, connect, and stream telemetry data between smart devices and mobile applications.' },
  { id: 'course-40', title: 'Offline-First Mobile Apps with WatermelonDB & Realm', category: 'Mobile Development', level: 'Intermediate', duration: '22 hours', rating: 4.8, studentsCount: 2700, imageKeyword: 'offline-mobile', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Local database synchronizations, conflict resolution protocols, and zero-latency querying.' },

  // 3. Data Science & Analytics (41-58)
  { id: 'course-41', title: 'Python for Data Science & Scientific Computing', category: 'Data Science & Analytics', level: 'Beginner', duration: '38 hours', rating: 4.9, studentsCount: 21500, imageKeyword: 'data-science', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'NumPy arrays, Pandas DataFrames, Matplotlib visualizations, and Exploratory Data Analysis.' },
  { id: 'course-42', title: 'SQL & Relational Analytics for Big Data', category: 'Data Science & Analytics', level: 'Beginner', duration: '28 hours', rating: 4.9, studentsCount: 18200, imageKeyword: 'sql-analytics', imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=800&q=80', description: 'Window functions, CTEs, complex joins, query optimization, and analytical database reporting.' },
  { id: 'course-43', title: 'Data Visualization & Storytelling with Tableau', category: 'Data Science & Analytics', level: 'Beginner', duration: '22 hours', rating: 4.8, studentsCount: 12400, imageKeyword: 'tableau-charts', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Transform raw metrics into executive dashboards, interactive stories, and actionable business insights.' },
  { id: 'course-44', title: 'Power BI Enterprise Business Intelligence', category: 'Data Science & Analytics', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 11900, imageKeyword: 'powerbi-bi', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'DAX expressions, data modeling, Power Query transformations, and automated KPI reporting.' },
  { id: 'course-45', title: 'Practical Statistics & Probability for Data Science', category: 'Data Science & Analytics', level: 'Intermediate', duration: '26 hours', rating: 4.9, studentsCount: 9800, imageKeyword: 'statistics-math', imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80', description: 'Hypothesis testing, p-values, regression analysis, confidence intervals, and Bayesian reasoning.' },
  { id: 'course-46', title: 'Data Engineering with Apache Spark & PySpark', category: 'Data Science & Analytics', level: 'Advanced', duration: '34 hours', rating: 4.8, studentsCount: 6500, imageKeyword: 'apache-spark', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Distributed data processing, Spark SQL, streaming pipelines, and cluster optimization.' },
  { id: 'course-47', title: 'ETL Pipeline Architecture with Apache Airflow', category: 'Data Science & Analytics', level: 'Advanced', duration: '28 hours', rating: 4.8, studentsCount: 5400, imageKeyword: 'data-pipelines', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Orchestrate directed acyclic graphs (DAGs), manage data dependencies, and monitor workflows.' },
  { id: 'course-48', title: 'Data Wrangling & Cleaning with Python & OpenRefine', category: 'Data Science & Analytics', level: 'Beginner', duration: '18 hours', rating: 4.7, studentsCount: 6200, imageKeyword: 'data-cleaning', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Handle missing values, anomalies, parsing unstructured formats, and standardization workflows.' },
  { id: 'course-49', title: 'Time Series Analysis & Forecasting in Python', category: 'Data Science & Analytics', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 4900, imageKeyword: 'time-series', imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&q=80', description: 'ARIMA, Prophet, seasonal decomposition, trend detection, and financial price forecasting.' },
  { id: 'course-50', title: 'Snowflake Cloud Data Warehouse Engineering', category: 'Data Science & Analytics', level: 'Intermediate', duration: '22 hours', rating: 4.8, studentsCount: 5100, imageKeyword: 'snowflake-data', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Virtual warehouses, data sharing, zero-copy cloning, time travel, and dbt transformations.' },
  { id: 'course-51', title: 'R Programming for Statistical Computing & ggplot2', category: 'Data Science & Analytics', level: 'Beginner', duration: '26 hours', rating: 4.7, studentsCount: 4300, imageKeyword: 'r-programming', imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80', description: 'Tidyverse, dplyr data manipulation, scientific charting with ggplot2, and R Markdown.' },
  { id: 'course-52', title: 'BigQuery Data Analytics at Scale', category: 'Data Science & Analytics', level: 'Intermediate', duration: '20 hours', rating: 4.8, studentsCount: 4700, imageKeyword: 'bigquery-analytics', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'Serverless petabyte SQL queries, partitioned tables, BigQuery ML, and cost optimization.' },
  { id: 'course-53', title: 'Web Scraping & Data Extraction with Scrapy & BeautifulSoup', category: 'Data Science & Analytics', level: 'Beginner', duration: '18 hours', rating: 4.7, studentsCount: 6800, imageKeyword: 'web-scraping', imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80', description: 'Extract structured information from the web, navigate DOM trees, and handle dynamic pages.' },
  { id: 'course-54', title: 'A/B Testing & Experimentation Science', category: 'Data Science & Analytics', level: 'Intermediate', duration: '16 hours', rating: 4.9, studentsCount: 3900, imageKeyword: 'ab-testing', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Design randomized controlled trials, sample sizing, statistical power, and guardrail metrics.' },
  { id: 'course-55', title: 'Modern Data Modeling with dbt (data build tool)', category: 'Data Science & Analytics', level: 'Intermediate', duration: '20 hours', rating: 4.8, studentsCount: 4400, imageKeyword: 'dbt-modeling', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Modular SQL transformations, testing, documentation, and lineage graphs in modern data stacks.' },
  { id: 'course-56', title: 'Data Governance, Quality & Compliance', category: 'Data Science & Analytics', level: 'Intermediate', duration: '16 hours', rating: 4.6, studentsCount: 2600, imageKeyword: 'data-governance', imageUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80', description: 'Data catalogs, metadata management, GDPR/CCPA compliance, and automated data quality checks.' },
  { id: 'course-57', title: 'Graph Data Science with Neo4j & NetworkX', category: 'Data Science & Analytics', level: 'Advanced', duration: '24 hours', rating: 4.8, studentsCount: 3100, imageKeyword: 'graph-analytics', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Community detection, PageRank, shortest paths, and network topology analysis.' },
  { id: 'course-58', title: 'Real-Time Streaming Analytics with Apache Kafka', category: 'Data Science & Analytics', level: 'Advanced', duration: '30 hours', rating: 4.9, studentsCount: 4900, imageKeyword: 'kafka-streaming', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Event-driven architectures, topics, consumer groups, Kafka Streams, and real-time dashboards.' },

  // 4. Artificial Intelligence & ML (59-78)
  { id: 'course-59', title: 'Machine Learning Foundations & Scikit-Learn', category: 'Artificial Intelligence & ML', level: 'Beginner', duration: '36 hours', rating: 4.9, studentsCount: 23400, imageKeyword: 'machine-learning', imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=800&q=80', description: 'Supervised and unsupervised learning, regression, classification, clustering, and model validation.' },
  { id: 'course-60', title: 'Deep Learning & Neural Networks with PyTorch', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '42 hours', rating: 4.9, studentsCount: 17800, imageKeyword: 'deep-learning', imageUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800&q=80', description: 'Tensors, backpropagation, convolutional networks, transformers, and GPU-accelerated training.' },
  { id: 'course-61', title: 'Natural Language Processing (NLP) & HuggingFace', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '34 hours', rating: 4.8, studentsCount: 14200, imageKeyword: 'nlp-ai', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Tokenization, embeddings, BERT, LLMs, text classification, and sentiment analysis pipelines.' },
  { id: 'course-62', title: 'Computer Vision with OpenCV & YOLOv8', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '32 hours', rating: 4.8, studentsCount: 11200, imageKeyword: 'computer-vision', imageUrl: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=800&q=80', description: 'Object detection, image segmentation, facial recognition, and video stream processing.' },
  { id: 'course-63', title: 'Prompt Engineering & Generative AI Applications', category: 'Artificial Intelligence & ML', level: 'Beginner', duration: '20 hours', rating: 4.9, studentsCount: 26500, imageKeyword: 'prompt-engineering', imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80', description: 'Few-shot learning, chain-of-thought, system prompts, structured JSON outputs, and evaluation.' },
  { id: 'course-64', title: 'Building LLM Apps with LangChain & LlamaIndex', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 15400, imageKeyword: 'langchain-ai', imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=800&q=80', description: 'Retrieval Augmented Generation (RAG), vector stores, autonomous agents, and tool calling.' },
  { id: 'course-65', title: 'Vector Databases (Pinecone, Qdrant, ChromaDB)', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '18 hours', rating: 4.7, studentsCount: 8900, imageKeyword: 'vector-database', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'High-dimensional indexing, similarity search algorithms, hybrid search, and semantic caches.' },
  { id: 'course-66', title: 'MLOps: Machine Learning in Production', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '32 hours', rating: 4.8, studentsCount: 6700, imageKeyword: 'mlops-production', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Model registry with MLflow, CI/CD for models, drift detection, and scalable inference endpoints.' },
  { id: 'course-67', title: 'Reinforcement Learning from Human Feedback (RLHF)', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '28 hours', rating: 4.9, studentsCount: 4300, imageKeyword: 'reinforcement-learning', imageUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800&q=80', description: 'Markov decision processes, reward modeling, PPO algorithms, and AI alignment strategies.' },
  { id: 'course-68', title: 'TensorFlow 2 & Keras Deep Learning Mastery', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '36 hours', rating: 4.7, studentsCount: 9100, imageKeyword: 'tensorflow-ai', imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80', description: 'Sequential and Functional APIs, transfer learning, data pipelines with tf.data, and TF Lite.' },
  { id: 'course-69', title: 'AI Autonomous Agents & Multi-Agent Systems', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '26 hours', rating: 4.9, studentsCount: 7800, imageKeyword: 'ai-agents', imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80', description: 'CrewAI, AutoGen, goal planning, memory persistence, and collaborative agent swarms.' },
  { id: 'course-70', title: 'Fine-Tuning Open Source LLMs (Llama 3 & Mistral)', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '30 hours', rating: 4.9, studentsCount: 6200, imageKeyword: 'llm-fine-tuning', imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=800&q=80', description: 'QLoRA, PEFT techniques, dataset preparation, quantization, and benchmark evaluation.' },
  { id: 'course-71', title: 'AI Ethics, Bias Mitigation & Governance', category: 'Artificial Intelligence & ML', level: 'Beginner', duration: '16 hours', rating: 4.8, studentsCount: 4500, imageKeyword: 'ai-ethics', imageUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80', description: 'Fairness metrics, explainability (SHAP/LIME), safety red-teaming, and EU AI Act compliance.' },
  { id: 'course-72', title: 'Speech AI: Whisper, Speech Recognition & TTS', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '22 hours', rating: 4.8, studentsCount: 4900, imageKeyword: 'speech-ai', imageUrl: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=800&q=80', description: 'Acoustic modeling, audio feature extraction, multilingual transcription, and voice synthesis.' },
  { id: 'course-73', title: 'Diffusion Models & Generative Image Synthesis', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '28 hours', rating: 4.8, studentsCount: 5100, imageKeyword: 'diffusion-ai', imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80', description: 'Score-based generative models, Stable Diffusion architecture, ControlNet, and latent spaces.' },
  { id: 'course-74', title: 'Edge AI & TinyML: Machine Learning on Microcontrollers', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '24 hours', rating: 4.7, studentsCount: 3200, imageKeyword: 'edge-ai', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'Run quantized neural models on Arduino, Raspberry Pi, and embedded silicon with low power.' },
  { id: 'course-75', title: 'Multimodal AI: Text, Vision & Audio Fusion', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '26 hours', rating: 4.9, studentsCount: 4700, imageKeyword: 'multimodal-ai', imageUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800&q=80', description: 'CLIP architectures, vision-language models (VLM), cross-modal retrieval, and real-time reasoning.' },
  { id: 'course-76', title: 'Feature Engineering & Selection for Tabular Data', category: 'Artificial Intelligence & ML', level: 'Intermediate', duration: '20 hours', rating: 4.7, studentsCount: 4600, imageKeyword: 'feature-engineering', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Encoding techniques, interaction terms, PCA dimensionality reduction, and LightGBM tuning.' },
  { id: 'course-77', title: 'AI Red Teaming & Adversarial Robustness', category: 'Artificial Intelligence & ML', level: 'Advanced', duration: '22 hours', rating: 4.8, studentsCount: 3600, imageKeyword: 'ai-red-team', imageUrl: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80', description: 'Jailbreak attacks, prompt injection defense, data poisoning, and model evasion vulnerabilities.' },
  { id: 'course-78', title: 'Gemini AI API & Multimodal Development', category: 'Artificial Intelligence & ML', level: 'Beginner', duration: '22 hours', rating: 4.9, studentsCount: 18900, imageKeyword: 'gemini-ai', imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=800&q=80', description: 'Leverage Google Gemini Flash and Pro for document analysis, function calling, and real-time streaming.' },

  // 5. Cloud & DevOps (79-98)
  { id: 'course-79', title: 'Google Cloud Platform (GCP) Fundamentals', category: 'Cloud & DevOps', level: 'Beginner', duration: '32 hours', rating: 4.9, studentsCount: 14200, imageKeyword: 'gcp-cloud', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Compute Engine, Cloud Run serverless, Cloud Storage, VPC networking, and IAM security.' },
  { id: 'course-80', title: 'AWS Certified Solutions Architect Associate', category: 'Cloud & DevOps', level: 'Intermediate', duration: '44 hours', rating: 4.9, studentsCount: 24500, imageKeyword: 'aws-cloud', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'EC2, S3, RDS, Lambda serverless, VPC peering, Route 53, and highly available architectures.' },
  { id: 'course-81', title: 'Docker Containers & Containerization Mastery', category: 'Cloud & DevOps', level: 'Beginner', duration: '24 hours', rating: 4.9, studentsCount: 21200, imageKeyword: 'docker-containers', imageUrl: 'https://images.unsplash.com/photo-1607799279861-4dd421887fb3?auto=format&fit=crop&w=800&q=80', description: 'Dockerfiles, multi-stage builds, Docker Compose, bridge networking, and image size reduction.' },
  { id: 'course-82', title: 'Kubernetes (K8s) Cluster Orchestration', category: 'Cloud & DevOps', level: 'Advanced', duration: '38 hours', rating: 4.8, studentsCount: 13400, imageKeyword: 'kubernetes-k8s', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Pods, Deployments, Services, Ingress controllers, Helm charts, and auto-scaling policies.' },
  { id: 'course-83', title: 'Infrastructure as Code with Terraform', category: 'Cloud & DevOps', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 11500, imageKeyword: 'terraform-iac', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'HCL syntax, state file management, modular cloud provisioning, drift detection, and workspaces.' },
  { id: 'course-84', title: 'Microsoft Azure Fundamentals (AZ-900 & AZ-104)', category: 'Cloud & DevOps', level: 'Beginner', duration: '30 hours', rating: 4.8, studentsCount: 13900, imageKeyword: 'azure-cloud', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'Azure Virtual Machines, Entra ID (Azure AD), Blob Storage, App Services, and cost governance.' },
  { id: 'course-85', title: 'CI/CD Pipelines with GitHub Actions & GitLab', category: 'Cloud & DevOps', level: 'Beginner', duration: '22 hours', rating: 4.9, studentsCount: 16100, imageKeyword: 'cicd-github', imageUrl: 'https://images.unsplash.com/photo-1618401471353-b98aedd04e11?auto=format&fit=crop&w=800&q=80', description: 'Automated test runners, security scanning, artifact publishing, and zero-downtime deployment.' },
  { id: 'course-86', title: 'Linux System Administration & Shell Scripting (Bash)', category: 'Cloud & DevOps', level: 'Beginner', duration: '32 hours', rating: 4.9, studentsCount: 18700, imageKeyword: 'linux-bash', imageUrl: 'https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&w=800&q=80', description: 'File systems, permissions, systemd services, SSH hardening, process management, and cron.' },
  { id: 'course-87', title: 'Site Reliability Engineering (SRE) & Observability', category: 'Cloud & DevOps', level: 'Advanced', duration: '28 hours', rating: 4.8, studentsCount: 5900, imageKeyword: 'sre-observability', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'SLIs, SLOs, error budgets, incident post-mortems, blameless culture, and chaos engineering.' },
  { id: 'course-88', title: 'Monitoring & Metrics with Prometheus & Grafana', category: 'Cloud & DevOps', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 8800, imageKeyword: 'prometheus-grafana', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'PromQL queries, metric exporters, alerting rules, executive visualization, and dashboard alerts.' },
  { id: 'course-89', title: 'Distributed Tracing with OpenTelemetry & Jaeger', category: 'Cloud & DevOps', level: 'Advanced', duration: '20 hours', rating: 4.7, studentsCount: 4100, imageKeyword: 'opentelemetry-tracing', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Trace context propagation, spans, performance bottleneck root-cause analysis in microservices.' },
  { id: 'course-90', title: 'Ansible IT Automation & Configuration Management', category: 'Cloud & DevOps', level: 'Intermediate', duration: '24 hours', rating: 4.7, studentsCount: 6400, imageKeyword: 'ansible-automation', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'Playbooks, roles, idempotent executions, inventory management, and remote node provisioning.' },
  { id: 'course-91', title: 'Serverless Architecture with AWS Lambda & Cloudflare Workers', category: 'Cloud & DevOps', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 7800, imageKeyword: 'serverless-cloud', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Event-driven triggers, cold start mitigations, edge functions, and cost-efficient scaling.' },
  { id: 'course-92', title: 'GitOps with ArgoCD & Flux on Kubernetes', category: 'Cloud & DevOps', level: 'Advanced', duration: '22 hours', rating: 4.8, studentsCount: 4900, imageKeyword: 'gitops-argocd', imageUrl: 'https://images.unsplash.com/photo-1618401471353-b98aedd04e11?auto=format&fit=crop&w=800&q=80', description: 'Declarative Git-driven continuous delivery, automated sync, rollbacks, and multi-cluster ops.' },
  { id: 'course-93', title: 'Cloud Networking: VPCs, CIDR, Load Balancing & DNS', category: 'Cloud & DevOps', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 5700, imageKeyword: 'cloud-networking', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'Subnetting, NAT gateways, security groups, application load balancers, and global anycast.' },
  { id: 'course-94', title: 'DevSecOps: Integrating Security in CI/CD', category: 'Cloud & DevOps', level: 'Advanced', duration: '26 hours', rating: 4.9, studentsCount: 6200, imageKeyword: 'devsecops', imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80', description: 'SAST, DAST, SCA dependency audits, container vulnerability scanning with Trivy, and secret detection.' },
  { id: 'course-95', title: 'Service Mesh with Istio & Envoy Proxy', category: 'Cloud & DevOps', level: 'Advanced', duration: '24 hours', rating: 4.7, studentsCount: 3600, imageKeyword: 'service-mesh', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Traffic splitting, canary rollouts, mutual TLS (mTLS) encryption, and circuit breaking.' },
  { id: 'course-96', title: 'Cloud Cost Optimization & FinOps Fundamentals', category: 'Cloud & DevOps', level: 'Intermediate', duration: '18 hours', rating: 4.7, studentsCount: 4300, imageKeyword: 'cloud-finops', imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80', description: 'Reserved instances, savings plans, auto-stopping idle resources, tagging, and unit economics.' },
  { id: 'course-97', title: 'Disaster Recovery & High Availability Architecture', category: 'Cloud & DevOps', level: 'Advanced', duration: '22 hours', rating: 4.8, studentsCount: 3700, imageKeyword: 'disaster-recovery', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'Multi-region replication, RPO/RTO targets, automated failover systems, and backup validation.' },
  { id: 'course-98', title: 'Cloud Security Posture Management (CSPM)', category: 'Cloud & DevOps', level: 'Intermediate', duration: '20 hours', rating: 4.8, studentsCount: 4100, imageKeyword: 'cspm-security', imageUrl: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80', description: 'Detect misconfigurations, enforce compliance benchmarks (CIS), and automate remediation.' },

  // 6. Cybersecurity (99-118)
  { id: 'course-99', title: 'CompTIA Security+ (SY0-701) Complete Prep', category: 'Cybersecurity', level: 'Beginner', duration: '40 hours', rating: 4.9, studentsCount: 22100, imageKeyword: 'cybersecurity-comp-tia', imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80', description: 'Threat landscape, cryptography, identity management, host protection, and risk mitigation.' },
  { id: 'course-100', title: 'Ethical Hacking & Penetration Testing Mastery', category: 'Cybersecurity', level: 'Intermediate', duration: '44 hours', rating: 4.9, studentsCount: 25400, imageKeyword: 'ethical-hacking', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Reconnaissance, port scanning, exploitation frameworks (Metasploit), privilege escalation.' },
  { id: 'course-101', title: 'Web Application Penetration Testing (OWASP Top 10)', category: 'Cybersecurity', level: 'Intermediate', duration: '36 hours', rating: 4.9, studentsCount: 16800, imageKeyword: 'web-pentesting', imageUrl: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80', description: 'SQL Injection, XSS, CSRF, SSRF, broken access control, and Burp Suite Pro workflows.' },
  { id: 'course-102', title: 'SOC Analyst (Tier 1 & Tier 2) Practical Skills', category: 'Cybersecurity', level: 'Beginner', duration: '34 hours', rating: 4.8, studentsCount: 13200, imageKeyword: 'soc-analyst', imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80', description: 'SIEM alert triage (Splunk/Wazuh), log analysis, incident classification, and phishing defense.' },
  { id: 'course-103', title: 'Digital Forensics & Incident Response (DFIR)', category: 'Cybersecurity', level: 'Advanced', duration: '38 hours', rating: 4.8, studentsCount: 7100, imageKeyword: 'digital-forensics', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'Memory forensics with Volatility, disk imaging, timeline reconstruction, and malware artifacts.' },
  { id: 'course-104', title: 'Malware Analysis & Reverse Engineering', category: 'Cybersecurity', level: 'Advanced', duration: '40 hours', rating: 4.9, studentsCount: 5800, imageKeyword: 'malware-analysis', imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=800&q=80', description: 'Static and dynamic analysis, Ghidra disassembler, x64dbg debugging, and sandbox detonation.' },
  { id: 'course-105', title: 'Network Security, Firewalls & Wireshark Packet Analysis', category: 'Cybersecurity', level: 'Beginner', duration: '28 hours', rating: 4.8, studentsCount: 11900, imageKeyword: 'network-security', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'TCP/IP handshake dissection, packet capturing, IDS/IPS configuration, and VPN tunneling.' },
  { id: 'course-106', title: 'Cryptography, PKI & TLS Deep Dive', category: 'Cybersecurity', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 6400, imageKeyword: 'cryptography-security', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Symmetric/Asymmetric encryption, RSA, AES, ECC, hashing functions, and certificate authorities.' },
  { id: 'course-107', title: 'Zero Trust Architecture & Identity Security', category: 'Cybersecurity', level: 'Intermediate', duration: '22 hours', rating: 4.8, studentsCount: 6900, imageKeyword: 'zero-trust', imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80', description: 'Never trust, always verify: Micro-segmentation, continuous authentication, and device health checks.' },
  { id: 'course-108', title: 'Cloud Penetration Testing (AWS & Azure Red Teaming)', category: 'Cybersecurity', level: 'Advanced', duration: '32 hours', rating: 4.9, studentsCount: 6100, imageKeyword: 'cloud-pentest', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Exploiting IAM misconfigurations, S3 bucket enumeration, SSRF into metadata services, Pacu.' },
  { id: 'course-109', title: 'Threat Intelligence (CTI) & MITRE ATT&CK', category: 'Cybersecurity', level: 'Intermediate', duration: '20 hours', rating: 4.7, studentsCount: 5200, imageKeyword: 'threat-intelligence', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'Tactics, techniques, procedures (TTPs), IOC sharing, threat feeds, and proactive defense mapping.' },
  { id: 'course-110', title: 'Active Directory Attacks & Domain Penetration', category: 'Cybersecurity', level: 'Advanced', duration: '34 hours', rating: 4.9, studentsCount: 7400, imageKeyword: 'active-directory', imageUrl: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80', description: 'Kerberoasting, Pass-the-Hash, AS-REP roasting, BloodHound attack graphs, and AD hardening.' },
  { id: 'course-111', title: 'OSINT: Open Source Intelligence Gathering', category: 'Cybersecurity', level: 'Beginner', duration: '20 hours', rating: 4.8, studentsCount: 14700, imageKeyword: 'osint-intelligence', imageUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80', description: 'Public records, social footprinting, domain reconnaissance, metadata scraping, and Maltego.' },
  { id: 'course-112', title: 'Bug Bounty Hunting Methodology', category: 'Cybersecurity', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 11200, imageKeyword: 'bug-bounty', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Asset discovery, automation scripts, vulnerability reporting, and HackerOne/Bugcrowd workflows.' },
  { id: 'course-113', title: 'Wireless Network Security (WiFi Hacking & Defense)', category: 'Cybersecurity', level: 'Intermediate', duration: '20 hours', rating: 4.7, studentsCount: 8400, imageKeyword: 'wifi-security', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'WPA2/WPA3 handshakes, deauthentication attacks, rogue access points, and enterprise RADIUS.' },
  { id: 'course-114', title: 'IoT & Hardware Hacking Fundamentals', category: 'Cybersecurity', level: 'Advanced', duration: '28 hours', rating: 4.7, studentsCount: 3900, imageKeyword: 'hardware-hacking', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'UART, JTAG extraction, firmware reverse engineering, and SDR radio communications.' },
  { id: 'course-115', title: 'Security Information & Event Management (SIEM) with Splunk', category: 'Cybersecurity', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 7800, imageKeyword: 'splunk-siem', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Search Processing Language (SPL), creating alerts, correlation searches, and dashboards.' },
  { id: 'course-116', title: 'API Security & Penetration Testing', category: 'Cybersecurity', level: 'Intermediate', duration: '24 hours', rating: 4.8, studentsCount: 8100, imageKeyword: 'api-security-pentest', imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80', description: 'OWASP API Security Top 10, BOLA, BFLA, mass assignment, and automated Postman audits.' },
  { id: 'course-117', title: 'Social Engineering Defense & Phishing Awareness', category: 'Cybersecurity', level: 'Beginner', duration: '16 hours', rating: 4.8, studentsCount: 9400, imageKeyword: 'social-engineering', imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80', description: 'Pretexting, vishing, credential harvesting simulation, and human defense architecture.' },
  { id: 'course-118', title: 'Cybersecurity Compliance: ISO 27001, SOC 2 & NIST CSF', category: 'Cybersecurity', level: 'Intermediate', duration: '22 hours', rating: 4.7, studentsCount: 4800, imageKeyword: 'security-compliance', imageUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80', description: 'Information security management systems (ISMS), auditing, policy documentation, and risk registries.' },

  // 7. Software Engineering & Computer Science (119-134)
  { id: 'course-119', title: 'Data Structures & Algorithms in Depth', category: 'Software Engineering', level: 'Beginner', duration: '46 hours', rating: 4.9, studentsCount: 29800, imageKeyword: 'algorithms', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Arrays, linked lists, trees, graphs, dynamic programming, sorting, and Big-O computational theory.' },
  { id: 'course-120', title: 'System Design for High Scale & Distributed Systems', category: 'Software Engineering', level: 'Advanced', duration: '36 hours', rating: 4.9, studentsCount: 19400, imageKeyword: 'system-design', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'CAP theorem, load balancing, caching tiers, database sharding, consistency models, and rate limits.' },
  { id: 'course-121', title: 'Design Patterns & Clean Architecture', category: 'Software Engineering', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 14500, imageKeyword: 'design-patterns', imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80', description: 'SOLID principles, Gang of Four patterns (Factory, Observer, Strategy), and Hexagonal architecture.' },
  { id: 'course-122', title: 'Git & GitHub Professional Workflows', category: 'Software Engineering', level: 'Beginner', duration: '18 hours', rating: 4.9, studentsCount: 24100, imageKeyword: 'git-github', imageUrl: 'https://images.unsplash.com/photo-1618401471353-b98aedd04e11?auto=format&fit=crop&w=800&q=80', description: 'Branching strategies (Trunk-based, GitFlow), interactive rebasing, merge conflict resolution, and PRs.' },
  { id: 'course-123', title: 'Operating Systems Internals & Memory Architecture', category: 'Software Engineering', level: 'Intermediate', duration: '32 hours', rating: 4.8, studentsCount: 7800, imageKeyword: 'operating-systems', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'Process scheduling, virtual memory, paging, concurrency deadlocks, file systems, and kernel rings.' },
  { id: 'course-124', title: 'Computer Networking: Protocols from Physical to Application', category: 'Software Engineering', level: 'Intermediate', duration: '30 hours', rating: 4.8, studentsCount: 9200, imageKeyword: 'computer-networking', imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80', description: 'OSI 7-layer model, TCP/IP, UDP, DNS resolution, BGP routing, HTTP/2 and HTTP/3 QUIC.' },
  { id: 'course-125', title: 'Test-Driven Development (TDD) & Unit Testing', category: 'Software Engineering', level: 'Intermediate', duration: '22 hours', rating: 4.7, studentsCount: 6800, imageKeyword: 'tdd-testing', imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80', description: 'Red-Green-Refactor cycles, behavior-driven design, test doubles, and regression prevention.' },
  { id: 'course-126', title: 'Refactoring Legacy Codebases safely', category: 'Software Engineering', level: 'Intermediate', duration: '20 hours', rating: 4.8, studentsCount: 5100, imageKeyword: 'code-refactoring', imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80', description: 'Code smell identification, characterization testing, strangler fig pattern, and debt reduction.' },
  { id: 'course-127', title: 'Database Internals: Storage Engines, B-Trees & WAL', category: 'Software Engineering', level: 'Advanced', duration: '30 hours', rating: 4.9, studentsCount: 4600, imageKeyword: 'database-internals', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'LSM trees, B+ tree indexing, write-ahead logs, MVCC concurrency, and transaction isolation.' },
  { id: 'course-128', title: 'Concurrent & Parallel Programming Systems', category: 'Software Engineering', level: 'Advanced', duration: '28 hours', rating: 4.8, studentsCount: 5300, imageKeyword: 'concurrency', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Threads, mutexes, condition variables, non-blocking atomic operations, and memory models.' },
  { id: 'course-129', title: 'Compiler Design & Abstract Syntax Trees (AST)', category: 'Software Engineering', level: 'Advanced', duration: '34 hours', rating: 4.8, studentsCount: 3400, imageKeyword: 'compiler-design', imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=800&q=80', description: 'Lexical analysis, parsing, semantic checks, intermediate representations, and code generation.' },
  { id: 'course-130', title: 'Domain-Driven Design (DDD) in Practice', category: 'Software Engineering', level: 'Advanced', duration: '24 hours', rating: 4.8, studentsCount: 4900, imageKeyword: 'domain-driven-design', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Ubiquitous language, bounded contexts, aggregates, entities, value objects, and domain events.' },
  { id: 'course-131', title: 'Event-Driven Architecture (EDA) & Event Sourcing', category: 'Software Engineering', level: 'Advanced', duration: '26 hours', rating: 4.8, studentsCount: 5200, imageKeyword: 'event-driven-arch', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'CQRS, event brokers, idempotent consumers, outbox pattern, and saga orchestrations.' },
  { id: 'course-132', title: 'Code Review Mastery & Engineering Leadership', category: 'Software Engineering', level: 'Intermediate', duration: '16 hours', rating: 4.9, studentsCount: 6300, imageKeyword: 'engineering-leadership', imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80', description: 'Constructive feedback, architectural RFCs, tech debt management, and engineering culture.' },
  { id: 'course-133', title: 'Software Architecture Documentation with C4 Model', category: 'Software Engineering', level: 'Intermediate', duration: '16 hours', rating: 4.7, studentsCount: 3800, imageKeyword: 'c4-architecture', imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80', description: 'Context, Container, Component, and Code diagrams for engineering communication.' },
  { id: 'course-134', title: 'High Performance Computing (HPC) & GPU Architecture', category: 'Software Engineering', level: 'Advanced', duration: '32 hours', rating: 4.8, studentsCount: 3100, imageKeyword: 'hpc-gpu', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'CUDA programming basics, SIMD vectorization, cache locality, and parallel computing.' },

  // 8. Programming Languages (135-154)
  { id: 'course-135', title: 'Python 3 Programming: From Beginner to Pro', category: 'Programming Languages', level: 'Beginner', duration: '42 hours', rating: 4.9, studentsCount: 31200, imageKeyword: 'python-programming', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Syntax, data structures, generators, decorators, object-oriented design, and standard libraries.' },
  { id: 'course-136', title: 'Go (Golang) Systems & Backend Programming', category: 'Programming Languages', level: 'Beginner', duration: '32 hours', rating: 4.9, studentsCount: 16400, imageKeyword: 'golang', imageUrl: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=800&q=80', description: 'Goroutines, channels, interfaces, error handling, standard net/http server, and fast binaries.' },
  { id: 'course-137', title: 'Rust Programming: Memory Safety & Concurrency', category: 'Programming Languages', level: 'Intermediate', duration: '40 hours', rating: 4.9, studentsCount: 14800, imageKeyword: 'rust-lang', imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=800&q=80', description: 'Ownership, borrowing, lifetimes, traits, pattern matching, fearless concurrency, and Cargo.' },
  { id: 'course-138', title: 'Modern C++ (C++20 & C++23) Systems Engineering', category: 'Programming Languages', level: 'Advanced', duration: '44 hours', rating: 4.8, studentsCount: 9700, imageKeyword: 'cpp-programming', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Smart pointers, RAII, templates, concepts, ranges, move semantics, and low-level memory control.' },
  { id: 'course-139', title: 'Java 21 & Spring Boot 3 Enterprise Development', category: 'Programming Languages', level: 'Intermediate', duration: '42 hours', rating: 4.8, studentsCount: 18900, imageKeyword: 'java-spring', imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', description: 'Virtual threads (Project Loom), Spring Security, JPA/Hibernate, Spring Data, and microservices.' },
  { id: 'course-140', title: 'C# and .NET 9 Web & Cloud Development', category: 'Programming Languages', level: 'Intermediate', duration: '38 hours', rating: 4.8, studentsCount: 12600, imageKeyword: 'csharp-dotnet', imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80', description: 'ASP.NET Core Minimal APIs, Entity Framework Core, async streams, and cross-platform deployment.' },
  { id: 'course-141', title: 'Kotlin Programming Fundamentals & Idiomatic Code', category: 'Programming Languages', level: 'Beginner', duration: '28 hours', rating: 4.8, studentsCount: 8700, imageKeyword: 'kotlin-lang', imageUrl: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?auto=format&fit=crop&w=800&q=80', description: 'Null safety, data classes, extension functions, scope functions, and coroutines.' },
  { id: 'course-142', title: 'Swift Programming: Syntax, Protocols & Generics', category: 'Programming Languages', level: 'Beginner', duration: '26 hours', rating: 4.8, studentsCount: 7900, imageKeyword: 'swift-code', imageUrl: 'https://images.unsplash.com/photo-1621768216002-5ac171876625?auto=format&fit=crop&w=800&q=80', description: 'Optionials, enums with associated values, protocol-oriented programming, and memory ARC.' },
  { id: 'course-143', title: 'Modern PHP 8 & Laravel 11 Framework', category: 'Programming Languages', level: 'Intermediate', duration: '34 hours', rating: 4.7, studentsCount: 10400, imageKeyword: 'php-laravel', imageUrl: 'https://images.unsplash.com/photo-1599507593499-a3f7f7d97667?auto=format&fit=crop&w=800&q=80', description: 'Eloquent ORM, Blade, Livewire, Artisan CLI, Queues, and modern MVC web backends.' },
  { id: 'course-144', title: 'Ruby on Rails 7 Full-Stack Rapid Prototyping', category: 'Programming Languages', level: 'Intermediate', duration: '30 hours', rating: 4.7, studentsCount: 6900, imageKeyword: 'ruby-rails', imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', description: 'Convention over configuration, ActiveRecord, Hotwire, Turbo, and rapid MVP delivery.' },
  { id: 'course-145', title: 'Scala & Functional Programming Principles', category: 'Programming Languages', level: 'Advanced', duration: '32 hours', rating: 4.7, studentsCount: 3800, imageKeyword: 'scala-fp', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Immutability, pure functions, monads, typeclasses, and Akka actor systems.' },
  { id: 'course-146', title: 'Elixir & Phoenix: Fault-Tolerant Concurrent Web Apps', category: 'Programming Languages', level: 'Advanced', duration: '30 hours', rating: 4.9, studentsCount: 4200, imageKeyword: 'elixir-phoenix', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'BEAM virtual machine, OTP supervisors, processes, and Phoenix LiveView real-time systems.' },
  { id: 'course-147', title: 'Haskell: Pure Functional Architecture', category: 'Programming Languages', level: 'Advanced', duration: '32 hours', rating: 4.8, studentsCount: 2700, imageKeyword: 'haskell-pure', imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80', description: 'Currying, lazy evaluation, category theory, functors, and rigorous mathematical correctness.' },
  { id: 'course-148', title: 'C Programming for Embedded & Systems Software', category: 'Programming Languages', level: 'Beginner', duration: '34 hours', rating: 4.8, studentsCount: 11400, imageKeyword: 'c-lang', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'Pointers, bitwise operations, memory allocation (malloc/free), structs, and header linking.' },
  { id: 'course-149', title: 'Dart Programming Fundamentals for Flutter Developers', category: 'Programming Languages', level: 'Beginner', duration: '20 hours', rating: 4.8, studentsCount: 8900, imageKeyword: 'dart-lang', imageUrl: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=800&q=80', description: 'Static typing, sound null safety, async/await, streams, collections, and mixins.' },
  { id: 'course-150', title: 'Julia for Scientific Machine Learning & Numerics', category: 'Programming Languages', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 3100, imageKeyword: 'julia-numerics', imageUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80', description: 'Multiple dispatch, JIT performance, differential equations, and scientific computing.' },
  { id: 'course-151', title: 'SQL Language Essentials: From DDL to Advanced Queries', category: 'Programming Languages', level: 'Beginner', duration: '22 hours', rating: 4.9, studentsCount: 17400, imageKeyword: 'sql-query', imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=800&q=80', description: 'SELECT, WHERE, GROUP BY, aggregates, subqueries, constraints, and relational algebra.' },
  { id: 'course-152', title: 'Bash & Zsh Shell Scripting Automation', category: 'Programming Languages', level: 'Beginner', duration: '18 hours', rating: 4.8, studentsCount: 13200, imageKeyword: 'bash-scripting', imageUrl: 'https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&w=800&q=80', description: 'Variables, loops, pipes, sed, awk, regex, script debugging, and system automation.' },
  { id: 'course-153', title: 'Clojure & Functional Lisp Programming', category: 'Programming Languages', level: 'Advanced', duration: '28 hours', rating: 4.7, studentsCount: 2400, imageKeyword: 'clojure-lisp', imageUrl: 'https://images.unsplash.com/photo-1516116211227-bbc13c744f43?auto=format&fit=crop&w=800&q=80', description: 'Homoiconicity, macros, persistent data structures, software transactional memory (STM).' },
  { id: 'course-154', title: 'Zig Programming for High Performance & Safety', category: 'Programming Languages', level: 'Advanced', duration: '24 hours', rating: 4.9, studentsCount: 2900, imageKeyword: 'zig-lang', imageUrl: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=800&q=80', description: 'Comptime code execution, manual memory allocators, no hidden control flow, and C interop.' },

  // 9. Databases (155-166)
  { id: 'course-155', title: 'PostgreSQL Advanced Administration & Query Tuning', category: 'Databases', level: 'Intermediate', duration: '32 hours', rating: 4.9, studentsCount: 16100, imageKeyword: 'postgresql', imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=800&q=80', description: 'EXPLAIN ANALYZE, vacuuming, indexing strategies (B-Tree, GIN, GiST), JSONB, and replication.' },
  { id: 'course-156', title: 'MongoDB & NoSQL Document Database Engineering', category: 'Databases', level: 'Beginner', duration: '26 hours', rating: 4.8, studentsCount: 14200, imageKeyword: 'mongodb-nosql', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Aggregation pipeline, schema design, replica sets, sharding, indexes, and Atlas cloud.' },
  { id: 'course-157', title: 'Redis In-Memory Caching, Queues & Pub/Sub', category: 'Databases', level: 'Intermediate', duration: '20 hours', rating: 4.9, studentsCount: 12500, imageKeyword: 'redis-cache', imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80', description: 'Data structures (Hashes, Sorted Sets, Streams), TTL, eviction policies, and cluster mode.' },
  { id: 'course-158', title: 'MySQL 8 Database Administration & Optimization', category: 'Databases', level: 'Beginner', duration: '28 hours', rating: 4.8, studentsCount: 13800, imageKeyword: 'mysql-database', imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=800&q=80', description: 'InnoDB engine, transactions, locking, binary logs, master-slave replication, and backup.' },
  { id: 'course-159', title: 'Database Normalization & Relational Schema Design', category: 'Databases', level: 'Beginner', duration: '18 hours', rating: 4.8, studentsCount: 9200, imageKeyword: 'database-design', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: '1NF, 2NF, 3NF, BCNF, primary and foreign keys, entity-relationship diagrams, and denormalization.' },
  { id: 'course-160', title: 'Amazon DynamoDB: Single-Table NoSQL Design', category: 'Databases', level: 'Advanced', duration: '24 hours', rating: 4.8, studentsCount: 6800, imageKeyword: 'dynamodb-nosql', imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80', description: 'Partition keys, sort keys, Global Secondary Indexes (GSIs), single-table architecture, and DAX.' },
  { id: 'course-161', title: 'Graph Databases with Neo4j & Cypher Querying', category: 'Databases', level: 'Intermediate', duration: '22 hours', rating: 4.8, studentsCount: 5100, imageKeyword: 'neo4j-graph', imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80', description: 'Nodes, relationships, labels, Cypher pattern matching, and graph traversal algorithms.' },
  { id: 'course-162', title: 'Cassandra & Distributed Wide-Column Stores', category: 'Databases', level: 'Advanced', duration: '26 hours', rating: 4.7, studentsCount: 4100, imageKeyword: 'cassandra-db', imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80', description: 'Decentralized peer-to-peer rings, tunable consistency, gossip protocol, and CQL data models.' },
  { id: 'course-163', title: 'Elasticsearch & Vector Search for Fast Querying', category: 'Databases', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 8900, imageKeyword: 'elasticsearch', imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80', description: 'Inverted indexes, full-text analysis, BM25 scoring, fuzzy matching, and Kibana.' },
  { id: 'course-164', title: 'SQLite Internal Architecture & Embedded Persistence', category: 'Databases', level: 'Beginner', duration: '18 hours', rating: 4.9, studentsCount: 7400, imageKeyword: 'sqlite-db', imageUrl: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=800&q=80', description: 'WAL mode, in-memory databases, file locking mechanisms, and ultra-reliable mobile storage.' },
  { id: 'course-165', title: 'Time-Series Databases with InfluxDB & TimescaleDB', category: 'Databases', level: 'Intermediate', duration: '20 hours', rating: 4.7, studentsCount: 4600, imageKeyword: 'timescale-db', imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&q=80', description: 'Hypertables, continuous aggregates, data retention policies, and high-frequency IoT logging.' },
  { id: 'course-166', title: 'Database Migration, Zero-Downtime Schema Changes & Liquibase', category: 'Databases', level: 'Advanced', duration: '20 hours', rating: 4.8, studentsCount: 3900, imageKeyword: 'database-migration', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Expand-contract pattern, safe column migrations, backfilling live records, and rollback safety.' },

  // 10. UI/UX & Product Design (167-176)
  { id: 'course-167', title: 'Figma UI/UX Design & Component Systems', category: 'UI/UX & Product Design', level: 'Beginner', duration: '30 hours', rating: 4.9, studentsCount: 28400, imageKeyword: 'figma-design', imageUrl: 'https://images.unsplash.com/photo-1581291518655-9523c932edcf?auto=format&fit=crop&w=800&q=80', description: 'Auto-layout, responsive constraints, variants, interactive components, and token systems.' },
  { id: 'course-168', title: 'UX Research, User Interviews & Usability Testing', category: 'UI/UX & Product Design', level: 'Beginner', duration: '22 hours', rating: 4.8, studentsCount: 11200, imageKeyword: 'ux-research', imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80', description: 'Qualitative testing, journey mapping, empathy maps, card sorting, and insight synthesis.' },
  { id: 'course-169', title: 'Enterprise Design Systems & Design Tokens', category: 'UI/UX & Product Design', level: 'Intermediate', duration: '26 hours', rating: 4.9, studentsCount: 9600, imageKeyword: 'design-systems', imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80', description: 'Design tokens with Style Dictionary, Figma-to-code sync, governance, and accessibility parity.' },
  { id: 'course-170', title: 'Interaction Design & Micro-Animations in UI', category: 'UI/UX & Product Design', level: 'Intermediate', duration: '20 hours', rating: 4.8, studentsCount: 8200, imageKeyword: 'interaction-design', imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80', description: 'Timing curves, spatial choreography, delightful feedback, and smart animate prototypes.' },
  { id: 'course-171', title: 'Product Management Fundamentals & Discovery', category: 'UI/UX & Product Design', level: 'Beginner', duration: '24 hours', rating: 4.8, studentsCount: 14700, imageKeyword: 'product-management', imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80', description: 'PRD writing, user story mapping, prioritization frameworks (RICE), and sprint roadmaps.' },
  { id: 'course-172', title: 'Mobile App UX: Ergonomics & Responsive Touch', category: 'UI/UX & Product Design', level: 'Intermediate', duration: '18 hours', rating: 4.7, studentsCount: 6800, imageKeyword: 'mobile-ux', imageUrl: 'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&w=800&q=80', description: 'Human interface guidelines, Material Design 3, thumb zones, gesture navigation, and haptics.' },
  { id: 'course-173', title: 'Information Architecture & Card Sorting', category: 'UI/UX & Product Design', level: 'Beginner', duration: '16 hours', rating: 4.7, studentsCount: 5400, imageKeyword: 'information-architecture', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Taxonomies, navigation tree structures, sitemaps, search behavior, and cognitive load reduction.' },
  { id: 'course-174', title: 'Web Typography, Spatial Grid Systems & Visual Hierarchy', category: 'UI/UX & Product Design', level: 'Beginner', duration: '18 hours', rating: 4.9, studentsCount: 8900, imageKeyword: 'typography-design', imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80', description: 'Modular scales, vertical rhythm, font pairing, contrast ratios, and optical margin alignment.' },
  { id: 'course-175', title: 'Designing for AI: UX Patterns for Generative Tools', category: 'UI/UX & Product Design', level: 'Intermediate', duration: '20 hours', rating: 4.9, studentsCount: 11400, imageKeyword: 'ai-ux-design', imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&w=800&q=80', description: 'Streaming tokens, confidence indicators, hallucination affordances, and human-in-the-loop interfaces.' },
  { id: 'course-176', title: 'Conversion Rate Optimization (CRO) & UX Auditing', category: 'UI/UX & Product Design', level: 'Intermediate', duration: '18 hours', rating: 4.8, studentsCount: 6100, imageKeyword: 'cro-audit', imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', description: 'Heuristic evaluation, friction analysis, checkout funnel optimizations, and microcopy testing.' },

  // 11. Emerging Technologies (177-182)
  { id: 'course-177', title: 'Blockchain Fundamentals, Cryptography & Smart Contracts', category: 'Emerging Technologies', level: 'Beginner', duration: '30 hours', rating: 4.8, studentsCount: 12100, imageKeyword: 'blockchain-tech', imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80', description: 'Consensus mechanisms (PoW, PoS), Merkle trees, wallet architectures, and Solidity development.' },
  { id: 'course-178', title: 'Internet of Things (IoT) & Smart Home Architecture', category: 'Emerging Technologies', level: 'Intermediate', duration: '28 hours', rating: 4.8, studentsCount: 8400, imageKeyword: 'iot-smart-home', imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80', description: 'MQTT protocol, ESP32 microcontrollers, sensor telemetry, and cloud gateway integrations.' },
  { id: 'course-179', title: 'Quantum Computing Foundations & Qiskit', category: 'Emerging Technologies', level: 'Advanced', duration: '32 hours', rating: 4.9, studentsCount: 4900, imageKeyword: 'quantum-computing', imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=800&q=80', description: 'Qubits, superposition, entanglement, quantum logic gates, Deutsch-Jozsa, and Shor algorithms.' },
  { id: 'course-180', title: 'Spatial Computing & Virtual Reality with WebXR', category: 'Emerging Technologies', level: 'Intermediate', duration: '26 hours', rating: 4.8, studentsCount: 5200, imageKeyword: 'spatial-vr', imageUrl: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?auto=format&fit=crop&w=800&q=80', description: 'Immersive browser experiences, headset controller tracking, spatial audio, and Babylon.js.' },
  { id: 'course-181', title: 'Game Development with Unity & C# Foundations', category: 'Emerging Technologies', level: 'Beginner', duration: '36 hours', rating: 4.9, studentsCount: 15300, imageKeyword: 'unity-game-dev', imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80', description: 'Physics engines, sprite rendering, raycasting, character controllers, and sound design.' },
  { id: 'course-182', title: 'Robotics Operating System (ROS 2) & Autonomous Navigation', category: 'Emerging Technologies', level: 'Advanced', duration: '34 hours', rating: 4.8, studentsCount: 4200, imageKeyword: 'robotics-ros2', imageUrl: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80', description: 'Nodes, topics, actions, SLAM lidar mapping, path planning, and Gazebo simulation.' }
];

// Helper to generate realistic modules and lessons for each course
function generateModulesForCourse(raw: RawCourseSpec) {
  return [
    {
      id: `${raw.id}-mod-1`,
      title: `Module 1: Foundations & Core Architecture of ${raw.title}`,
      description: `Comprehensive onboarding, conceptual framework, and foundational principles for ${raw.title}.`,
      lessons: [
        {
          id: `${raw.id}-l-1`,
          title: `1.1 Introduction to ${raw.title}`,
          duration: '35 mins',
          description: `Overview of key principles, real-world industry adoption, and prerequisites for ${raw.title}.`,
          notes: [
            'Understanding historical context and modern architectural evolution.',
            'Core terminology and setup requirements.',
            'Best practices for environment consistency.'
          ]
        },
        {
          id: `${raw.id}-l-2`,
          title: `1.2 Environment Setup & Tooling Configuration`,
          duration: '45 mins',
          description: `Configuring IDEs, command line tools, and testing environments for optimal productivity.`,
          notes: [
            'Setting up recommended linters, formatters, and compilers.',
            'Verifying system dependencies and package versions.',
            'Creating repeatable starter templates.'
          ]
        },
        {
          id: `${raw.id}-l-3`,
          title: `1.3 Core Concepts & Fundamental Mechanics`,
          duration: '50 mins',
          description: `Dissecting core abstractions, data flows, and essential logic required to build real solutions.`,
          notes: [
            'Analyzing structural building blocks.',
            'Handling errors and basic edge conditions.',
            'Writing first functional milestone code.'
          ]
        }
      ]
    },
    {
      id: `${raw.id}-mod-2`,
      title: `Module 2: Practical Implementation & Intermediate Workflows`,
      description: `Hands-on execution, structural patterns, and real application development.`,
      lessons: [
        {
          id: `${raw.id}-l-4`,
          title: `2.1 Architectural Patterns & Design Decisions`,
          duration: '55 mins',
          description: `Evaluating architectural trade-offs, modularity, and maintainable structuring.`,
          notes: [
            'Separation of concerns across modules.',
            'Managing state and asynchronous behaviors cleanly.',
            'Avoiding common anti-patterns in production.'
          ]
        },
        {
          id: `${raw.id}-l-5`,
          title: `2.2 Integration, Data Pipelines & External Services`,
          duration: '60 mins',
          description: `Connecting modules to databases, APIs, network services, and external libraries.`,
          notes: [
            'Handling network latency and resilience.',
            'Securing credentials and configuration variables.',
            'Schema validation and response parsing.'
          ]
        },
        {
          id: `${raw.id}-l-6`,
          title: `2.3 Debugging, Profiling & Unit Testing`,
          duration: '50 mins',
          description: `Writing comprehensive unit tests, using debuggers, and profiling bottlenecks.`,
          notes: [
            'Automated test runners and assertion libraries.',
            'Profiling memory usage and execution timing.',
            'Systematic root cause analysis.'
          ]
        }
      ]
    },
    {
      id: `${raw.id}-mod-3`,
      title: `Module 3: Advanced Optimization & Production Deployment`,
      description: `Hardening, security protocols, scaling strategies, and capstone deployment.`,
      lessons: [
        {
          id: `${raw.id}-l-7`,
          title: `3.1 Performance Tuning & Latency Optimization`,
          duration: '50 mins',
          description: `Benchmarking, cache strategies, concurrency, and minimizing operational overhead.`,
          notes: [
            'Measuring critical rendering and computational paths.',
            'Implementing caching and data indexing.',
            'Load testing under concurrent traffic.'
          ]
        },
        {
          id: `${raw.id}-l-8`,
          title: `3.2 Production Deployment, Monitoring & Capstone Review`,
          duration: '60 mins',
          description: `Deploying to cloud infrastructure, configuring telemetry, and final comprehensive synthesis.`,
          notes: [
            'Continuous integration and automated delivery.',
            'Log aggregation and real-time alert thresholds.',
            'Reviewing final exam expectations and certificate requirements.'
          ]
        }
      ]
    }
  ];
}

// Convert specs into fully typed courses
export const ALL_COURSES: Course[] = RAW_COURSES_METADATA.map((spec) => {
  const verified = VERIFIED_PLAYLISTS_REGISTRY[spec.id];
  const isVerified = Boolean(verified);

  return {
    id: spec.id,
    title: spec.title,
    slug: spec.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    category: spec.category,
    level: spec.level,
    duration: spec.duration,
    rating: spec.rating,
    reviewsCount: Math.floor(spec.studentsCount * 0.12),
    studentsCount: spec.studentsCount,
    enrolledCount: spec.studentsCount,
    estimatedHours: spec.duration,
    coverImage: spec.imageUrl,
    description: spec.description,
    learningOutcomes: [
      `Master core architectural foundations of ${spec.title}`,
      `Design and build production-ready projects following industry standard practices`,
      `Implement rigorous automated testing, security validation, and performance optimization`,
      `Earn an authenticated Learn With Flow certificate signed by CEO Muhammad Talha`
    ],
    prerequisites: [
      `Basic computer literacy and text editor experience`,
      `Curiosity and commitment to complete hands-on quizzes and assessments`
    ],
    playlist: isVerified
      ? {
          id: verified!.id,
          url: verified!.url,
          title: verified!.title,
          channel: verified!.channel,
          isVerified: true,
          verificationStatus: 'verified',
          topicMatchStatus: 'confirmed'
        }
      : {
          id: '',
          url: '',
          title: 'Playlist Pending Verification',
          channel: 'Under Educational Review',
          isVerified: false,
          verificationStatus: 'pending',
          topicMatchStatus: 'pending_review'
        },
    modules: generateModulesForCourse(spec)
  };
});

// Category list
export const ALL_CATEGORIES: Category[] = [
  'Web Development',
  'Mobile Development',
  'Data Science & Analytics',
  'Artificial Intelligence & ML',
  'Cloud & DevOps',
  'Cybersecurity',
  'Software Engineering',
  'Programming Languages',
  'Databases',
  'UI/UX & Product Design',
  'Emerging Technologies'
];
