import { LanguageCode } from '../types';

export interface TranslationDictionary {
  brandName: string;
  brandTagline: string;
  navHome: string;
  navCourses: string;
  navAboutUs: string;
  navMission: string;
  navAboutCEO: string;
  navVerify: string;
  navAdmin: string;
  navAssistant: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroExploreBtn: string;
  heroCatalogStats: string;
  searchPlaceholder: string;
  allCategories: string;
  allLevels: string;
  playlistVerified: string;
  playlistPending: string;
  filterByStatus: string;
  readAloud: string;
  stopReadAloud: string;
  lessons: string;
  modules: string;
  startCourse: string;
  resumeCourse: string;
  takeLessonQuiz: string;
  takeModuleAssessment: string;
  takeFinalExam: string;
  certificateEarned: string;
  verifiedBadge: string;
  pendingBadge: string;
  viewCertificate: string;
  verifyCertificateHeading: string;
  verifyInputPlaceholder: string;
  verifyBtn: string;
  ceoSignatureTitle: string;
  fatherTributeTitle: string;
  fatherTributeSubtitle: string;
  openOnYouTube: string;
  footerRights: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationDictionary> = {
  en: {
    brandName: 'Learn With Flow',
    brandTagline: 'World-Class Technical Education for Everyone, Everywhere',
    navHome: 'Home',
    navCourses: 'Courses',
    navAboutUs: 'About Us',
    navMission: 'Mission',
    navAboutCEO: 'About CEO',
    navVerify: 'Verify Certificate',
    navAdmin: 'Admin',
    navAssistant: 'AI Assistant',
    heroHeadline: 'Master Real Technology Skills. Built for Tomorrow.',
    heroSubheadline: 'Explore 182+ structured technology curriculums with verified YouTube playlists, modular assessments, and authentic credentials.',
    heroExploreBtn: 'Explore 182+ Courses',
    heroCatalogStats: '182 Curated Courses • 1,400+ Interactive Lessons • Free Certificates',
    searchPlaceholder: 'Search courses by title, topic, or technology...',
    allCategories: 'All Categories',
    allLevels: 'All Levels',
    playlistVerified: 'Verified Playlist',
    playlistPending: 'Playlist Pending Verification',
    filterByStatus: 'Playlist Status',
    readAloud: 'Read Aloud',
    stopReadAloud: 'Stop Voice',
    lessons: 'Lessons',
    modules: 'Modules',
    startCourse: 'Start Learning',
    resumeCourse: 'Resume Course',
    takeLessonQuiz: 'Take 8-Question Lesson Quiz',
    takeModuleAssessment: 'Take 15-Question Module Assessment',
    takeFinalExam: 'Take 25-Question Final Exam',
    certificateEarned: 'Certificate Earned!',
    verifiedBadge: 'Verified Educational Playlist',
    pendingBadge: 'Playlist Pending Verification',
    viewCertificate: 'View Official Certificate',
    verifyCertificateHeading: 'Verify Official Certificate',
    verifyInputPlaceholder: 'Enter Certificate ID (e.g. LWF-2026-XXXX-XXXX)',
    verifyBtn: 'Verify Authenticity',
    ceoSignatureTitle: 'Muhammad Talha, Founder & CEO',
    fatherTributeTitle: 'Credit to My Father — Muhammad Toseef',
    fatherTributeSubtitle: 'In Honor of His Hard Work, Sacrifices, Support and Unwavering Encouragement',
    openOnYouTube: 'Open Playlist on YouTube',
    footerRights: 'All rights reserved. Learn With Flow — Dedicated to accessible educational excellence.'
  },
  ur: {
    brandName: 'لرن ود فلو',
    brandTagline: 'ہر ایک کے لیے، ہر جگہ عالمی معیار کی تکنیکی تعلیم',
    navHome: 'ہوم',
    navCourses: 'کورسز',
    navAboutUs: 'ہمارے بارے میں',
    navMission: 'ہمارا مشن',
    navAboutCEO: 'سی ای او کے بارے میں',
    navVerify: 'سرٹیفکیٹ کی تصدیق',
    navAdmin: 'ایڈمن',
    navAssistant: 'اے آئی اسسٹنٹ',
    heroHeadline: 'حقیقی تکنیکی مہارتوں میں مہارت حاصل کریں۔',
    heroSubheadline: '182 سے زیادہ منظم کورسز، تصدیق شدہ یوٹیوب پلے لسٹس اور حقیقی اسناد کے ساتھ اپنے کیریئر کو آگے بڑھائیں۔',
    heroExploreBtn: '182+ کورسز تلاش کریں',
    heroCatalogStats: '182 منتخب کورسز • 1400+ اسباق • مفت سرٹیفکیٹس',
    searchPlaceholder: 'کورسز تلاش کریں...',
    allCategories: 'تمام کیٹیگریز',
    allLevels: 'تمام درجات',
    playlistVerified: 'تصدیق شدہ پلے لسٹ',
    playlistPending: 'پلے لسٹ زیرِ تصدیق',
    filterByStatus: 'پلے لسٹ کی حیثیت',
    readAloud: 'آواز سے سنیں',
    stopReadAloud: 'آواز بند کریں',
    lessons: 'اسباق',
    modules: 'ماڈیولز',
    startCourse: 'کورس شروع کریں',
    resumeCourse: 'سیکھنا جاری رکھیں',
    takeLessonQuiz: '8 سوالات کا کوئز حل کریں',
    takeModuleAssessment: '15 سوالات کا ماڈیول ٹیسٹ دیں',
    takeFinalExam: '25 سوالات کا فائنل امتحان دیں',
    certificateEarned: 'سرٹیفکیٹ حاصل کر لیا!',
    verifiedBadge: 'تصدیق شدہ پلے لسٹ',
    pendingBadge: 'پلے لسٹ زیرِ تصدیق ہے',
    viewCertificate: 'سرٹیفکیٹ دیکھیں',
    verifyCertificateHeading: 'سرٹیفکیٹ کی تصدیق کریں',
    verifyInputPlaceholder: 'سرٹیفکیٹ آئی ڈی درج کریں...',
    verifyBtn: 'تصدیق کریں',
    ceoSignatureTitle: 'محمد طلحہ، بانی و سی ای او',
    fatherTributeTitle: 'میرے والد محترم محمد توصیف کے نام',
    fatherTributeSubtitle: 'ان کی انتھک محنت، قربانیوں اور غیر متزلزل حوصلہ افزائی کے اعتراف میں',
    openOnYouTube: 'یوٹیوب پر پلے لسٹ کھولیں',
    footerRights: 'جملہ حقوق محفوظ ہیں۔ لرن ود فلو — مفت اور معیاری تعلیم کا علمبردار۔'
  },
  hi: {
    brandName: 'लर्न विद फ्लो',
    brandTagline: 'सभी के लिए, हर जगह विश्व स्तरीय तकनीकी शिक्षा',
    navHome: 'होम',
    navCourses: 'कोर्सेस',
    navAboutUs: 'हमारे बारे में',
    navMission: 'हमारा मिशन',
    navAboutCEO: 'सीईओ के बारे में',
    navVerify: 'प्रमाणपत्र सत्यापन',
    navAdmin: 'एडमिन',
    navAssistant: 'एआई असिस्टेंट',
    heroHeadline: 'वास्तविक तकनीकी कौशल में महारत हासिल करें।',
    heroSubheadline: '182+ संरचित पाठ्यक्रमों, सत्यापित यूट्यूब प्लेलिस्ट और वास्तविक प्रमाणपत्रों के साथ सीखें।',
    heroExploreBtn: '182+ पाठ्यक्रम देखें',
    heroCatalogStats: '182 पाठ्यक्रम • 1400+ पाठ • निःशुल्क प्रमाणपत्र',
    searchPlaceholder: 'शीर्षक या तकनीक द्वारा पाठ्यक्रम खोजें...',
    allCategories: 'सभी श्रेणियां',
    allLevels: 'सभी स्तर',
    playlistVerified: 'सत्यापित प्लेलिस्ट',
    playlistPending: 'प्लेलिस्ट सत्यापन लंबित',
    filterByStatus: 'प्लेलिस्ट स्थिति',
    readAloud: 'बोलकर सुनें',
    stopReadAloud: 'आवाज़ बंद करें',
    lessons: 'पाठ',
    modules: 'मॉड्यूल',
    startCourse: 'प्रारंभ करें',
    resumeCourse: 'जारी रखें',
    takeLessonQuiz: '8 प्रश्नों की प्रश्नोत्तरी दें',
    takeModuleAssessment: '15 प्रश्नों का मॉड्यूल मूल्यांकन करें',
    takeFinalExam: '25 प्रश्नों की अंतिम परीक्षा दें',
    certificateEarned: 'प्रमाणपत्र अर्जित किया गया!',
    verifiedBadge: 'सत्यापित शैक्षणिक प्लेलिस्ट',
    pendingBadge: 'प्लेलिस्ट सत्यापन लंबित है',
    viewCertificate: 'प्रमाणपत्र देखें',
    verifyCertificateHeading: 'प्रमाणपत्र सत्यापित करें',
    verifyInputPlaceholder: 'प्रमाणपत्र आईडी दर्ज करें...',
    verifyBtn: 'सत्यापित करें',
    ceoSignatureTitle: 'मोहम्मद तल्हा, संस्थापक एवं सीईओ',
    fatherTributeTitle: 'मेरे पिता को श्रेय — मोहम्मद तौसीफ',
    fatherTributeSubtitle: 'उनकी कड़ी मेहनत, बलिदान, निरंतर समर्थन और प्रोत्साहन के सम्मान में',
    openOnYouTube: 'यूट्यूब पर प्लेलिस्ट खोलें',
    footerRights: 'सर्वाधिकार सुरक्षित। लर्न विद फ्लो — तकनीकी शिक्षा के लिए समर्पित।'
  },
  ar: {
    brandName: 'ليرن وذ فلو',
    brandTagline: 'تعليم تقني عالمي المستوى للجميع وفي كل مكان',
    navHome: 'الرئيسية',
    navCourses: 'الدورات',
    navAboutUs: 'من نحن',
    navMission: 'رسالتنا',
    navAboutCEO: 'عن المدير التنفيذي',
    navVerify: 'التحقق من الشهادة',
    navAdmin: 'لوحة المشرف',
    navAssistant: 'المساعد الذكي',
    heroHeadline: 'أتقن المهارات التقنية الحقيقية للمستقبل.',
    heroSubheadline: 'استكشف أكثر من 182 مسارًا تقنيًا منظمًا مع قوائم تشغيل يوتيوب موثوقة وشهادات حقيقية.',
    heroExploreBtn: 'استكشف 182+ دورة',
    heroCatalogStats: '182 مسار تعليمي • أكثر من 1400 درس • شهادات مجانية',
    searchPlaceholder: 'ابحث عن الدورات حسب العنوان أو التقنية...',
    allCategories: 'كل الفئات',
    allLevels: 'جميع المستويات',
    playlistVerified: 'قائمة تشغيل معتمدة',
    playlistPending: 'قائمة التشغيل قيد المراجعة',
    filterByStatus: 'حالة قائمة التشغيل',
    readAloud: 'قراءة صوتية',
    stopReadAloud: 'إيقاف الصوت',
    lessons: 'الدروس',
    modules: 'الوحدات',
    startCourse: 'ابدأ الدورة',
    resumeCourse: 'متابعة الدورة',
    takeLessonQuiz: 'اختبار الدرس (8 أسئلة)',
    takeModuleAssessment: 'تقييم الوحدة (15 سؤالاً)',
    takeFinalExam: 'الامتحان النهائي (25 سؤالاً)',
    certificateEarned: 'تم الحصول على الشهادة!',
    verifiedBadge: 'قائمة تشغيل تعليمية مؤكدة',
    pendingBadge: 'قيد المراجعة والتحقق',
    viewCertificate: 'عرض الشهادة المعتمدة',
    verifyCertificateHeading: 'التحقق من صحة الشهادة',
    verifyInputPlaceholder: 'أدخل معرّف الشهادة (LWF-XXXX)',
    verifyBtn: 'تحقق من السجل',
    ceoSignatureTitle: 'محمد طلحة، المؤسس والرئيس التنفيذي',
    fatherTributeTitle: 'إهداء وتقدير لوالدي — محمد توصيف',
    fatherTributeSubtitle: 'تكريمًا لجهوده الكبيرة وتضحياته ودعمه وتشجيعه المتواصل',
    openOnYouTube: 'فتح قائمة التشغيل على يوتيوب',
    footerRights: 'جميع الحقوق محفوظة. ليرن وذ فلو — ريادة التعليم التقني المتاح.'
  },
  es: {
    brandName: 'Learn With Flow',
    brandTagline: 'Educación tecnológica de nivel mundial para todos',
    navHome: 'Inicio',
    navCourses: 'Cursos',
    navAboutUs: 'Sobre Nosotros',
    navMission: 'Misión',
    navAboutCEO: 'Sobre el CEO',
    navVerify: 'Verificar Certificado',
    navAdmin: 'Administración',
    navAssistant: 'Asistente IA',
    heroHeadline: 'Domina habilidades tecnológicas reales.',
    heroSubheadline: 'Explora más de 182 planes de estudio estructurados con listas de YouTube verificadas y certificaciones oficiales.',
    heroExploreBtn: 'Explorar 182+ Cursos',
    heroCatalogStats: '182 Cursos • 1,400+ Lecciones • Certificados Gratuitos',
    searchPlaceholder: 'Buscar cursos por título o tecnología...',
    allCategories: 'Todas las Categorías',
    allLevels: 'Todos los Niveles',
    playlistVerified: 'Lista Verificada',
    playlistPending: 'Lista Pendiente de Verificación',
    filterByStatus: 'Estado de Lista',
    readAloud: 'Lectura en Voz Alta',
    stopReadAloud: 'Detener Voz',
    lessons: 'Lecciones',
    modules: 'Módulos',
    startCourse: 'Comenzar Curso',
    resumeCourse: 'Continuar Curso',
    takeLessonQuiz: 'Cuestionario de Lección (8 preguntas)',
    takeModuleAssessment: 'Evaluación de Módulo (15 preguntas)',
    takeFinalExam: 'Examen Final (25 preguntas)',
    certificateEarned: '¡Certificado Obtenido!',
    verifiedBadge: 'Lista Educativa Verificada',
    pendingBadge: 'Lista Pendiente de Verificación',
    viewCertificate: 'Ver Certificado Oficial',
    verifyCertificateHeading: 'Verificar Autenticidad de Certificado',
    verifyInputPlaceholder: 'Ingrese el ID del Certificado...',
    verifyBtn: 'Verificar en Registro',
    ceoSignatureTitle: 'Muhammad Talha, Fundador y CEO',
    fatherTributeTitle: 'Crédito a Mi Padre — Muhammad Toseef',
    fatherTributeSubtitle: 'En honor a su arduo trabajo, sacrificios, apoyo incondicional y aliento constante',
    openOnYouTube: 'Abrir Lista en YouTube',
    footerRights: 'Todos los derechos reservados. Learn With Flow — Educación tecnológica de calidad.'
  },
  fr: {
    brandName: 'Learn With Flow',
    brandTagline: 'Formation technique de classe mondiale pour tous',
    navHome: 'Accueil',
    navCourses: 'Cours',
    navAboutUs: 'À Propos',
    navMission: 'Mission',
    navAboutCEO: 'Le Fondateur & CEO',
    navVerify: 'Vérifier Certificat',
    navAdmin: 'Admin',
    navAssistant: 'Assistant IA',
    heroHeadline: 'Maîtrisez les compétences technologiques de demain.',
    heroSubheadline: 'Découvrez plus de 182 cours structurés avec des listes de lecture YouTube vérifiées et des évaluations complètes.',
    heroExploreBtn: 'Explorer 182+ Cours',
    heroCatalogStats: '182 Cours • Plus de 1400 Leçons • Certificats Gratuits',
    searchPlaceholder: 'Rechercher un cours par titre ou technologie...',
    allCategories: 'Toutes Catégories',
    allLevels: 'Tous Niveaux',
    playlistVerified: 'Liste Vérifiée',
    playlistPending: 'Liste en Attente de Vérification',
    filterByStatus: 'Statut de la Liste',
    readAloud: 'Lecture Vocale',
    stopReadAloud: 'Arrêter la Voix',
    lessons: 'Leçons',
    modules: 'Modules',
    startCourse: 'Commencer',
    resumeCourse: 'Reprendre',
    takeLessonQuiz: 'Quiz de Leçon (8 questions)',
    takeModuleAssessment: 'Évaluation de Module (15 questions)',
    takeFinalExam: 'Examen Final (25 questions)',
    certificateEarned: 'Certificat Obtenu !',
    verifiedBadge: 'Liste de Lecture Vérifiée',
    pendingBadge: 'Liste en Attente de Vérification',
    viewCertificate: 'Voir Certificat Officiel',
    verifyCertificateHeading: 'Vérifier un Certificat',
    verifyInputPlaceholder: 'Entrez l\'identifiant du certificat...',
    verifyBtn: 'Vérifier l\'Authenticité',
    ceoSignatureTitle: 'Muhammad Talha, Fondateur & CEO',
    fatherTributeTitle: 'Hommage à Mon Père — Muhammad Toseef',
    fatherTributeSubtitle: 'En reconnaissance de son travail acharné, de ses sacrifices et de son soutien constant',
    openOnYouTube: 'Ouvrir la Liste sur YouTube',
    footerRights: 'Tous droits réservés. Learn With Flow — L\'excellence éducative accessible.'
  }
};
