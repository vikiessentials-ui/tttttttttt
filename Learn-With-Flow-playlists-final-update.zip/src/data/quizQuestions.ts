import { QuizQuestion, Course } from '../types';

// Category-specific question bank seeds to generate authentic, topic-accurate questions
const TOPIC_QUESTION_TEMPLATES: Record<string, { q: string; opts: string[]; a: number; exp: string }[]> = {
  'Web Development': [
    {
      q: 'Which of the following describes the purpose of the Document Object Model (DOM)?',
      opts: ['A protocol for secure web sockets', 'A programming interface for HTML and XML documents representing nodes and objects', 'A database engine inside the browser', 'A compiler for JavaScript code'],
      a: 1,
      exp: 'The DOM represents the document as nodes and objects so programs can change the document structure, style, and content.'
    },
    {
      q: 'What is the primary difference between CSS Grid and Flexbox?',
      opts: ['Grid is for 1D layouts while Flexbox is strictly 2D', 'Flexbox is two-dimensional while Grid is one-dimensional', 'Grid is two-dimensional (rows and columns) while Flexbox is primarily one-dimensional', 'Flexbox requires JavaScript while Grid does not'],
      a: 2,
      exp: 'CSS Grid is designed for two-dimensional layouts (both rows and columns simultaneously), whereas Flexbox excels at one-dimensional alignment.'
    },
    {
      q: 'What does the browser Event Loop prioritize first when call stack is empty?',
      opts: ['SetTimeout task queue', 'Microtask queue (Promises, MutationObserver)', 'Disk I/O operations', 'Rendering paint cycles'],
      a: 1,
      exp: 'Microtasks (like Promise callbacks and process.nextTick in Node) take precedence before regular macrotasks in the event loop cycle.'
    },
    {
      q: 'In React, why must Hook calls remain at the top level of components?',
      opts: ['To optimize network bandwidth', 'To allow React to preserve state identity based on call order across renders', 'Because JavaScript forbids inner functions', 'To bypass virtual DOM reconciliation'],
      a: 1,
      exp: 'React relies on the strict call order of Hooks across re-renders to pair internal state cells with the corresponding hook calls.'
    },
    {
      q: 'Which HTTP header provides security against Cross-Site Scripting (XSS)?',
      opts: ['Content-Security-Policy', 'Access-Control-Allow-Origin', 'Accept-Encoding', 'Cache-Control'],
      a: 0,
      exp: 'Content-Security-Policy (CSP) restricts the resources (scripts, styles, images) that the browser is allowed to load for a given page.'
    },
    {
      q: 'What is the function of the "use strict" directive in JavaScript?',
      opts: ['Forces code to execute in multi-threaded mode', 'Enforces stricter parsing and error handling, preventing silent errors and accidental globals', 'Enables TypeScript compilation', 'Allows immediate memory garbage collection'],
      a: 1,
      exp: '"use strict" catches common coding bloopers, throwing exceptions for assignments to undeclared variables.'
    },
    {
      q: 'What metric does Largest Contentful Paint (LCP) measure in Core Web Vitals?',
      opts: ['Input response latency', 'Visual stability during page layout shifts', 'Render time of the largest image or text block visible within the viewport', 'Time taken to establish a TCP handshake'],
      a: 2,
      exp: 'LCP marks the point in the page load timeline when the main content has likely loaded.'
    },
    {
      q: 'What is the primary benefit of Server-Side Rendering (SSR)?',
      opts: ['Eliminates the need for a web server', 'Faster First Contentful Paint and improved SEO indexability for web crawlers', 'Zero client JavaScript needed', 'Offline functionality without service workers'],
      a: 1,
      exp: 'SSR delivers pre-rendered HTML to the browser immediately, boosting initial load speed and allowing crawlers to read page content directly.'
    }
  ],
  'Cybersecurity': [
    {
      q: 'What is the core principle of Zero Trust Architecture?',
      opts: ['Trust internal perimeter networks unconditionally', 'Never trust, always verify regardless of whether access originates inside or outside network perimeters', 'Encrypt only passwords and leave database traffic open', 'Rely solely on firewalls for intrusion detection'],
      a: 1,
      exp: 'Zero Trust assumes no implicit trust granted to assets or user accounts based solely on physical or network location.'
    },
    {
      q: 'Which attack vector involves tricking a web application into executing unintended SQL commands?',
      opts: ['Cross-Site Request Forgery (CSRF)', 'SQL Injection (SQLi)', 'Buffer Overflow', 'Server-Side Template Injection (SSTI)'],
      a: 1,
      exp: 'SQL Injection occurs when untrusted user input is concatenated directly into database queries without proper parameterization.'
    },
    {
      q: 'What is the purpose of a Salt when hashing user passwords?',
      opts: ['To compress the password into fewer bytes', 'To append unique random data to the password before hashing, defeating precomputed Rainbow Table attacks', 'To make the hash reversible for administrator recovery', 'To verify the email address of the user'],
      a: 1,
      exp: 'Salting prevents attackers from using precomputed hash lookup tables (rainbow tables) across identical passwords.'
    },
    {
      q: 'What does the CIA Triad in Information Security represent?',
      opts: ['Cloud, Internet, Automation', 'Confidentiality, Integrity, Availability', 'Control, Inspection, Authorization', 'Cyber, Intelligence, Analytics'],
      a: 1,
      exp: 'The CIA Triad forms the bedrock of cybersecurity policies: Confidentiality, Integrity, and Availability.'
    },
    {
      q: 'In Public Key Cryptography (Asymmetric Encryption), which key is used to decrypt a message?',
      opts: ['The recipient private key', 'The sender public key', 'A shared symmetric AES key', 'The root certificate key'],
      a: 0,
      exp: 'Data encrypted with the recipient public key can only be decrypted by the corresponding private key held securely by that recipient.'
    },
    {
      q: 'What is the primary role of a SIEM system in a Security Operations Center (SOC)?',
      opts: ['Compiling C++ binaries', 'Aggregating, normalizing, and analyzing log data across enterprise infrastructure to detect security incidents', 'Cracking weak hashes', 'Managing Git version control'],
      a: 1,
      exp: 'SIEM tools collect event data from network devices, servers, and applications to provide real-time correlation and security monitoring.'
    },
    {
      q: 'What vulnerability occurs when an authenticated user is tricked into submitting an unauthorized request to a trusted site?',
      opts: ['Cross-Site Request Forgery (CSRF)', 'Denial of Service (DoS)', 'Privilege Escalation', 'Session Fixation'],
      a: 0,
      exp: 'CSRF forces an end user to execute unwanted actions on a web application in which they are currently authenticated.'
    },
    {
      q: 'Which tool is most commonly utilized for network packet capture and deep protocol inspection?',
      opts: ['Burp Suite', 'Wireshark', 'Metasploit', 'Nmap'],
      a: 1,
      exp: 'Wireshark is the industry standard packet sniffer for analyzing microsecond network traffic and packet streams.'
    }
  ],
  'Artificial Intelligence & ML': [
    {
      q: 'What does "overfitting" mean in machine learning model evaluation?',
      opts: ['The model performs poorly on training data but well on validation data', 'The model learns noise and idiosyncratic details of training data, degrading generalization to unseen data', 'The model trains too quickly', 'The model weights become zero'],
      a: 1,
      exp: 'Overfitting occurs when a model captures specific noise rather than the underlying pattern, resulting in high training accuracy but low test accuracy.'
    },
    {
      q: 'What is the role of the Activation Function in artificial neural networks?',
      opts: ['To normalize database columns', 'To introduce non-linearity, allowing networks to learn complex arbitrary function mappings', 'To calculate the gradient descent step', 'To save memory during checkpointing'],
      a: 1,
      exp: 'Without non-linear activation functions (e.g. ReLU, GELU, Sigmoid), stacked neural layers would collapse into a single linear transformation.'
    },
    {
      q: 'What mechanism in Transformer architectures allows tokens to weigh relationships with all other tokens in a sequence?',
      opts: ['Self-Attention Mechanism', 'Convolutional Striding', 'Recurrent Backpropagation Through Time', 'Max Pooling'],
      a: 0,
      exp: 'Self-Attention calculates query, key, and value dot-products to dynamically weight relevance between tokens across the entire context window.'
    },
    {
      q: 'What does RAG stand for in modern generative AI application engineering?',
      opts: ['Random Automated Generation', 'Retrieval-Augmented Generation', 'Recursive Architecture Graph', 'Reinforcement Action Gradient'],
      a: 1,
      exp: 'RAG retrieves factual grounding data from vector indexes or knowledge bases and injects it into the prompt context for the LLM.'
    },
    {
      q: 'What is the purpose of Temperature in LLM sampling?',
      opts: ['Controls hardware processor heat', 'Governs randomness and diversity in next-token probability distributions', 'Determines API pricing', 'Sets maximum output tokens'],
      a: 1,
      exp: 'Lower temperatures sharpen probability distributions toward the most likely token (deterministic), while higher values flatten it (creative/diverse).'
    },
    {
      q: 'Which loss function is standard for multi-class classification tasks in neural networks?',
      opts: ['Mean Squared Error (MSE)', 'Categorical Cross-Entropy', 'Huber Loss', 'Cosine Proximity'],
      a: 1,
      exp: 'Categorical Cross-Entropy measures the distance between the predicted softmax probability distribution and the true one-hot target distribution.'
    },
    {
      q: 'What is QLoRA in the context of Large Language Model fine-tuning?',
      opts: ['A quantizer for optical character recognition', 'Quantized Low-Rank Adaptation, fine-tuning 4-bit quantized base models with small trainable parameter adapters', 'A reinforcement learning agent', 'A database indexing method'],
      a: 1,
      exp: 'QLoRA enables fine-tuning massive models on consumer GPUs by freezing a 4-bit quantized base model and training small low-rank adapter matrices.'
    },
    {
      q: 'What problem does Gradient Clipping resolve during recurrent network and deep model training?',
      opts: ['Vanishing gradients', 'Exploding gradients causing NaN weights and numerical instability', 'Overfitting', 'Slow data loading'],
      a: 1,
      exp: 'Gradient clipping caps gradients at a predetermined threshold when their norm exceeds bounds, preventing numerical explosions.'
    }
  ],
  'Cloud & DevOps': [
    {
      q: 'What is the core distinction between a Container (Docker) and a Virtual Machine (VM)?',
      opts: ['Containers virtualize hardware and run distinct operating system kernels; VMs share the host kernel', 'Containers share the host OS kernel and isolate user space; VMs emulate virtual hardware and run full guest OSs', 'VMs cannot run Linux', 'Containers require hypervisors like VMware ESXi'],
      a: 1,
      exp: 'Containers share the host operating system kernel and isolate user processes via cgroups and namespaces, making them lightweight.'
    },
    {
      q: 'In Kubernetes, what is the smallest deployable computing unit that can be created and managed?',
      opts: ['Service', 'Pod', 'Deployment', 'Node'],
      a: 1,
      exp: 'A Pod encapsulates one or more co-located containers, storage resources, and unique network IP within the Kubernetes cluster.'
    },
    {
      q: 'What does "Idempotency" mean in Infrastructure as Code (e.g. Terraform, Ansible)?',
      opts: ['Executing a script multiple times produces the same desired infrastructure state without unwanted side effects', 'Running code destroys all resources', 'Deployments happen without internet access', 'Only one server can exist at a time'],
      a: 0,
      exp: 'An idempotent operation can be applied multiple times without altering the result beyond the initial application.'
    },
    {
      q: 'What does the term "Blue-Green Deployment" describe in continuous release engineering?',
      opts: ['Running tests during daytime (Blue) and nighttime (Green)', 'Maintaining two identical production environments, switching live user traffic cleanly from Blue to Green upon verification', 'Deploying on macOS and Linux simultaneously', 'Gradual rollout to 10% of users'],
      a: 1,
      exp: 'Blue-Green deployments minimize downtime and rollback risk by deploying new releases to an idle identical environment before redirecting traffic.'
    },
    {
      q: 'What is the primary function of an Ingress Controller in Kubernetes?',
      opts: ['Manages container log rotation', 'Routes external HTTP and HTTPS traffic to cluster Services with load balancing and SSL termination', 'Allocates CPU limits', 'Generates Docker images'],
      a: 1,
      exp: 'Ingress exposes HTTP and HTTPS routes from outside the cluster to services within the cluster.'
    },
    {
      q: 'Which AWS service provides serverless compute that executes code in response to events?',
      opts: ['Amazon EC2', 'AWS Lambda', 'Amazon RDS', 'Amazon S3'],
      a: 1,
      exp: 'AWS Lambda runs code automatically in response to triggers without provisioning or managing servers.'
    },
    {
      q: 'What metric in Site Reliability Engineering (SRE) measures the target reliability agreed upon with stakeholders?',
      opts: ['Service Level Indicator (SLI)', 'Service Level Objective (SLO)', 'Mean Time to Failure (MTTF)', 'Error Budget'],
      a: 1,
      exp: 'An SLO is a target value or range of values for a service level that is measured by an SLI.'
    },
    {
      q: 'What is the purpose of GitOps tools like ArgoCD and Flux?',
      opts: ['Writing Git commit messages with AI', 'Using Git repositories as the single source of truth for declarative infrastructure and automated continuous deployment', 'Merging pull requests automatically without reviews', 'Running database migrations only'],
      a: 1,
      exp: 'GitOps continuously reconciles the desired state declared in Git with the live runtime state of Kubernetes clusters.'
    }
  ]
};

// General fallback high-quality question bank across software engineering and tech topics
const GENERAL_QUESTION_BANK: { q: string; opts: string[]; a: number; exp: string }[] = [
  {
    q: 'What is the time complexity of searching an element in a balanced Binary Search Tree (AVL / Red-Black)?',
    opts: ['O(1)', 'O(n)', 'O(log n)', 'O(n log n)'],
    a: 2,
    exp: 'Because the tree is balanced, each comparison eliminates half the remaining subtrees, achieving O(log n) time.'
  },
  {
    q: 'Which database isolation level prevents Dirty Reads, Non-Repeatable Reads, and Phantom Reads completely?',
    opts: ['Read Uncommitted', 'Read Committed', 'Repeatable Read', 'Serializable'],
    a: 3,
    exp: 'Serializable is the highest isolation level, executing transactions with the exact safety as if they ran in serial sequence.'
  },
  {
    q: 'What is the purpose of the Single Responsibility Principle (SRP) in SOLID software design?',
    opts: ['Every developer must only work on one file', 'A class or module should have only one reason to change, encapsulating a single coherent capability', 'All functions must be single-line expressions', 'Only one instance of a class may exist'],
    a: 1,
    exp: 'SRP dictates that a module should be responsible to one, and only one, actor or business capability.'
  },
  {
    q: 'In REST API design, which HTTP method is expected to be idempotent?',
    opts: ['POST', 'PUT', 'PATCH (non-idempotent semantics)', 'CONNECT'],
    a: 1,
    exp: 'PUT replaces the target resource entirely; making multiple identical PUT requests leaves the server in the identical state.'
  },
  {
    q: 'What does ACID stand for in transaction processing systems?',
    opts: ['Atomicity, Consistency, Isolation, Durability', 'Asynchronous, Concurrent, Indexed, Distributed', 'Authentication, Confidentiality, Integrity, Defense', 'Application, Component, Interface, Data'],
    a: 0,
    exp: 'ACID guarantees that database transactions are processed reliably.'
  },
  {
    q: 'What is the function of a Reverse Proxy (such as NGINX or Envoy)?',
    opts: ['To execute database queries directly on disk', 'To sit in front of web servers and forward client requests, handling load balancing, SSL termination, and caching', 'To prevent browsers from executing JavaScript', 'To compile frontend source code'],
    a: 1,
    exp: 'A reverse proxy intercepts traffic before it reaches backend services, enhancing performance and security.'
  },
  {
    q: 'What is a Race Condition in concurrent software systems?',
    opts: ['When two CPU threads compete for clock speed', 'When software behavior depends on the uncontrollable timing or sequence of execution of threads', 'When an algorithm runs faster than O(n)', 'When network ping drops below 1ms'],
    a: 1,
    exp: 'Race conditions occur when shared mutable state is accessed without proper synchronization primitives.'
  },
  {
    q: 'What is the primary advantage of immutability in programming state management?',
    opts: ['It reduces total file size', 'It eliminates side-effects, simplifies concurrent execution, and makes state changes predictable and trackable', 'It removes the need for garbage collection', 'It enables inline assembly code'],
    a: 1,
    exp: 'Immutable data structures cannot be altered after creation, preventing concurrency bugs and simplifying change detection.'
  },
  {
    q: 'In Git, what does "git rebase" do compared to "git merge"?',
    opts: ['Deletes the branch permanently', 'Replays commits from one branch onto the tip of another, producing a linear project history without merge commits', 'Pushes code directly to production', 'Reverts the previous three commits'],
    a: 1,
    exp: 'Rebase moves or combines a sequence of commits to a new base commit, maintaining a clean, linear commit history.'
  },
  {
    q: 'What is the purpose of a Circuit Breaker pattern in distributed microservices?',
    opts: ['To cut physical server power', 'To detect service failures and prevent cascading collapse by failing fast instead of exhausting thread pools waiting on unresponsive dependencies', 'To encrypt TCP packets', 'To format JSON responses'],
    a: 1,
    exp: 'A circuit breaker trips when failure thresholds are exceeded, returning immediate errors and allowing the downstream service to recover.'
  },
  {
    q: 'Which data structure underlies typical in-memory caching systems for key-value lookups with O(1) average time?',
    opts: ['Hash Table / Hash Map', 'Linked List', 'B-Tree', 'Min Heap'],
    a: 0,
    exp: 'Hash tables compute bucket indices using hash functions, providing average O(1) time complexity for reads and writes.'
  },
  {
    q: 'What is the CAP Theorem trade-off in distributed storage systems?',
    opts: ['Cost, Availability, Performance', 'Consistency, Availability, Partition Tolerance — a system can only guarantee at most two simultaneously in the presence of a network partition', 'Cloud, Architecture, Platform', 'Capacity, Authorization, Privacy'],
    a: 1,
    exp: 'In the presence of network partitions (P), a distributed system must choose between Consistency (C) and Availability (A).'
  },
  {
    q: 'What is the function of the Write-Ahead Log (WAL) in database storage engines?',
    opts: ['To display database server logs on the dashboard', 'To ensure Durability and crash recovery by appending transactional mutations to non-volatile disk before updating in-memory pages', 'To index search queries', 'To minify SQL strings'],
    a: 1,
    exp: 'WAL guarantees that changes can be replayed after a crash, ensuring transactions adhere to the Durability contract.'
  },
  {
    q: 'What is the difference between Authentication (AuthN) and Authorization (AuthZ)?',
    opts: ['They are identical synonyms', 'AuthN verifies who a user is; AuthZ determines what resources or actions that verified user is permitted to access', 'AuthN is client-side only; AuthZ is database-only', 'AuthZ handles password reset; AuthN handles username changes'],
    a: 1,
    exp: 'Authentication verifies identity (e.g. logging in), while authorization enforces permissions and access control rules.'
  },
  {
    q: 'What is the purpose of Sharding in database scalability?',
    opts: ['Compressing table columns', 'Horizontally partitioning database records across independent database instances or nodes', 'Converting relational tables into JSON', 'Enforcing foreign key constraints'],
    a: 1,
    exp: 'Sharding distributes data rows across distinct database nodes to scale writes and storage beyond the capacity of a single machine.'
  }
];

/**
 * Generates an 8-question Lesson Quiz for a specific lesson
 */
export function generateLessonQuiz(course: Course, lessonId: string): QuizQuestion[] {
  const categoryPool = TOPIC_QUESTION_TEMPLATES[course.category] || GENERAL_QUESTION_BANK;
  const pool = [...categoryPool, ...GENERAL_QUESTION_BANK];

  // Deterministically pick 8 questions based on course id and lesson id
  const questions: QuizQuestion[] = [];
  const seed = (course.id + lessonId).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  for (let i = 0; i < 8; i++) {
    const item = pool[(seed + i * 3) % pool.length];
    questions.push({
      id: `${lessonId}-q-${i + 1}`,
      question: `${item.q} (Relates to: ${course.title})`,
      options: item.opts,
      correctIndex: item.a,
      explanation: item.exp
    });
  }

  return questions;
}

/**
 * Generates a 15-question Module Assessment for a specific module
 */
export function generateModuleAssessment(course: Course, moduleId: string): QuizQuestion[] {
  const categoryPool = TOPIC_QUESTION_TEMPLATES[course.category] || GENERAL_QUESTION_BANK;
  const pool = [...categoryPool, ...GENERAL_QUESTION_BANK];

  const questions: QuizQuestion[] = [];
  const seed = (course.id + moduleId).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  for (let i = 0; i < 15; i++) {
    const item = pool[(seed + i * 5) % pool.length];
    questions.push({
      id: `${moduleId}-assess-q-${i + 1}`,
      question: `[Module ${i + 1}/15] ${item.q}`,
      options: item.opts,
      correctIndex: item.a,
      explanation: item.exp
    });
  }

  return questions;
}

/**
 * Generates a 25-question Final Comprehensive Exam for the Course
 */
export function generateFinalExam(course: Course): QuizQuestion[] {
  const categoryPool = TOPIC_QUESTION_TEMPLATES[course.category] || GENERAL_QUESTION_BANK;
  const pool = [...categoryPool, ...GENERAL_QUESTION_BANK];

  const questions: QuizQuestion[] = [];
  const seed = course.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  for (let i = 0; i < 25; i++) {
    const item = pool[(seed + i * 7) % pool.length];
    questions.push({
      id: `${course.id}-final-q-${i + 1}`,
      question: `[Final Certification Question ${i + 1}/25] ${item.q}`,
      options: item.opts,
      correctIndex: item.a,
      explanation: item.exp
    });
  }

  return questions;
}
