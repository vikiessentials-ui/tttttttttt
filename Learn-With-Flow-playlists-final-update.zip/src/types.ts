export type Category = 
  | 'Web Development'
  | 'Mobile Development'
  | 'Data Science & Analytics'
  | 'Artificial Intelligence & ML'
  | 'Cloud & DevOps'
  | 'Cybersecurity'
  | 'Software Engineering'
  | 'Programming Languages'
  | 'Databases'
  | 'UI/UX & Product Design'
  | 'Emerging Technologies';

export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  description: string;
  notes: string[];
}

export interface CourseModule {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
}

export interface PlaylistInfo {
  id: string;
  url: string;
  title: string;
  channel: string;
  isVerified: boolean;
  verificationStatus: 'verified' | 'pending';
  topicMatchStatus: 'confirmed' | 'pending_review';
}

export interface Course {
  id: string;
  title: string;
  slug: string;
  category: Category;
  level: SkillLevel;
  duration: string;
  rating: number;
  reviewsCount: number;
  studentsCount: number;
  enrolledCount?: number;
  estimatedHours?: string;
  coverImage: string;
  description: string;
  learningOutcomes: string[];
  prerequisites: string[];
  playlist: PlaylistInfo;
  modules: CourseModule[];
}

export type Module = CourseModule;
export type CourseCategory = Category;

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface CertificateRecord {
  id: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  category: string;
  completedDate: string;
  scorePercentage: number;
  grade: 'A+' | 'A' | 'B' | 'Pass';
  issuer: string;
  ceoName: string;
  status: 'valid' | 'revoked';
  qrVerificationUrl: string;
}

export interface UserProgress {
  courseId: string;
  completedLessons: string[];
  completedAssessments: string[];
  quizScores: Record<string, number>; // lessonId -> percentage
  assessmentScores: Record<string, number>; // moduleId -> percentage
  finalExamScore?: number;
  finalExamPassed: boolean;
  certificate?: CertificateRecord;
  certificateId?: string;
  lastUpdated: string;
}

export type LanguageCode = 'en' | 'ur' | 'hi' | 'ar' | 'es' | 'fr';

export type PageView = 
  | 'home'
  | 'courses'
  | 'course-detail'
  | 'learning'
  | 'learning-view'
  | 'certificate'
  | 'verification'
  | 'about-us'
  | 'mission'
  | 'privacy-policy'
  | 'security'
  | 'contact'
  | 'about-ceo'
  | 'admin-dashboard';
