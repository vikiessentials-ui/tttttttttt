import React, { useState, useEffect } from 'react';
import { PageView, LanguageCode, Course, UserProgress, CertificateRecord } from './types';
import { ALL_COURSES } from './data/coursesData';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { OwnerAuthModal } from './components/OwnerAuthModal';
import { AIAssistantModal } from './components/AIAssistantModal';
import { CertificateView } from './components/CertificateView';
import { HomePage } from './pages/HomePage';
import { CoursesPage } from './pages/CoursesPage';
import { CourseDetailPage } from './pages/CourseDetailPage';
import { LearningView } from './pages/LearningView';
import { VerificationPage } from './pages/VerificationPage';
import { AboutCEOPage } from './pages/AboutCEOPage';
import { AboutUsPage } from './pages/AboutUsPage';
import { MissionPage } from './pages/MissionPage';
import { PrivacyPolicyPage, SecurityPage, ContactPage } from './pages/InstitutionalPages';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { Sparkles } from 'lucide-react';

export function App() {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [currentLang, setCurrentLang] = useState<LanguageCode>('en');
  const [courses, setCourses] = useState<Course[]>(ALL_COURSES);
  
  // Active course / lesson selections
  const [selectedCourseId, setSelectedCourseId] = useState<string>('course-1');
  const [learningModuleId, setLearningModuleId] = useState<string>('c1-m1');
  const [learningLessonId, setLearningLessonId] = useState<string>('c1-l1');
  
  // Certificate view state
  const [activeCertificate, setActiveCertificate] = useState<CertificateRecord | null>(null);
  const [verificationLookupId, setVerificationLookupId] = useState<string>('');

  // Modals & Auth state
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminToken, setAdminToken] = useState<string>('');
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  // User learning progress map (courseId -> UserProgress)
  const [progressMap, setProgressMap] = useState<Record<string, UserProgress>>(() => {
    try {
      const saved = localStorage.getItem('lwf_progress_data');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return {};
  });

  // Check URL params on initial load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyId = params.get('verify');
    const courseParam = params.get('course');

    if (verifyId) {
      setVerificationLookupId(verifyId);
      setCurrentPage('verification');
    } else if (courseParam) {
      const found = courses.find((c) => c.id === courseParam);
      if (found) {
        setSelectedCourseId(found.id);
        setCurrentPage('course-detail');
      }
    }

    // Check server overrides for course playlists if any
    fetch('/api/courses/overrides')
      .then((res) => res.json())
      .then((data) => {
        if (data.overrides && Object.keys(data.overrides).length > 0) {
          setCourses((prev) =>
            prev.map((c) => {
              if (data.overrides[c.id]) {
                return { ...c, playlist: data.overrides[c.id] };
              }
              return c;
            })
          );
        }
      })
      .catch(() => {});
  }, []);

  // Update HTML document direction and language for RTL support
  useEffect(() => {
    document.documentElement.lang = currentLang;
    if (currentLang === 'ur' || currentLang === 'ar') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [currentLang]);

  // Scroll to top on navigation
  const navigateTo = (page: PageView) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Save progress changes
  const handleUpdateProgress = (updatedProgress: UserProgress) => {
    const newMap = {
      ...progressMap,
      [updatedProgress.courseId]: updatedProgress
    };
    setProgressMap(newMap);
    try {
      localStorage.setItem('lwf_progress_data', JSON.stringify(newMap));
    } catch (e) {
      // ignore
    }

    if (updatedProgress.certificate) {
      setActiveCertificate(updatedProgress.certificate);
    }
  };

  const handleSelectCourse = (courseId: string) => {
    setSelectedCourseId(courseId);
    navigateTo('course-detail');
  };

  const handleStartLearning = (courseId: string, moduleId: string, lessonId: string) => {
    setSelectedCourseId(courseId);
    setLearningModuleId(moduleId);
    setLearningLessonId(lessonId);
    navigateTo('learning');
  };

  const handleTakeFinalExam = (courseId: string) => {
    const c = courses.find((crs) => crs.id === courseId) || courses[0];
    setSelectedCourseId(c.id);
    setLearningModuleId(c.modules[0]?.id || 'm1');
    setLearningLessonId(c.modules[0]?.lessons[0]?.id || 'l1');
    navigateTo('learning');
  };

  const handleOwnerAuthenticated = (token: string) => {
    setIsAdminAuthenticated(true);
    setAdminToken(token);
    navigateTo('admin-dashboard');
  };

  const handleUpdateCoursePlaylist = (courseId: string, updatedPlaylist: any) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === courseId ? { ...c, playlist: updatedPlaylist } : c))
    );
  };

  // Active selected course
  const currentSelectedCourse = courses.find((c) => c.id === selectedCourseId) || courses[0];
  const currentCourseProgress: UserProgress = progressMap[selectedCourseId] || {
    courseId: selectedCourseId,
    completedLessons: [],
    completedAssessments: [],
    quizScores: {},
    assessmentScores: {},
    finalExamPassed: false,
    lastUpdated: new Date().toISOString()
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      
      {/* Main Header / Navigation */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={navigateTo}
        currentLang={currentLang}
        setCurrentLang={setCurrentLang}
        openAdminModal={() => {
          if (isAdminAuthenticated) {
            navigateTo('admin-dashboard');
          } else {
            setIsOwnerModalOpen(true);
          }
        }}
        openAIAssistant={() => setIsAIAssistantOpen(true)}
        isAdminAuthenticated={isAdminAuthenticated}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            courses={courses}
            onSelectCourse={handleSelectCourse}
            setCurrentPage={navigateTo}
            currentLang={currentLang}
            openAIAssistant={() => setIsAIAssistantOpen(true)}
          />
        )}

        {currentPage === 'courses' && (
          <CoursesPage
            courses={courses}
            onSelectCourse={handleSelectCourse}
            currentLang={currentLang}
          />
        )}

        {currentPage === 'course-detail' && (
          <CourseDetailPage
            course={currentSelectedCourse}
            progress={currentCourseProgress}
            onBack={() => navigateTo('courses')}
            onStartLearning={handleStartLearning}
            onTakeFinalExam={handleTakeFinalExam}
            onViewCertificate={
              currentCourseProgress.certificate
                ? () => {
                    setActiveCertificate(currentCourseProgress.certificate!);
                    navigateTo('certificate');
                  }
                : undefined
            }
          />
        )}

        {currentPage === 'learning' && (
          <LearningView
            course={currentSelectedCourse}
            initialModuleId={learningModuleId}
            initialLessonId={learningLessonId}
            progress={currentCourseProgress}
            onUpdateProgress={handleUpdateProgress}
            onBackToCourse={() => navigateTo('course-detail')}
            onShowCertificate={(certId) => {
              if (currentCourseProgress.certificate) {
                setActiveCertificate(currentCourseProgress.certificate);
              }
              navigateTo('certificate');
            }}
          />
        )}

        {currentPage === 'certificate' && activeCertificate && (
          <CertificateView
            certificate={activeCertificate}
            onBack={() => navigateTo('course-detail')}
            onVerifyInRegistry={(certId) => {
              setVerificationLookupId(certId);
              navigateTo('verification');
            }}
          />
        )}

        {currentPage === 'verification' && (
          <VerificationPage
            initialCertId={verificationLookupId}
            onViewCertificateDetails={(cert) => {
              setActiveCertificate(cert);
              navigateTo('certificate');
            }}
          />
        )}

        {currentPage === 'about-ceo' && (
          <AboutCEOPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'about-us' && (
          <AboutUsPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'mission' && (
          <MissionPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'privacy-policy' && (
          <PrivacyPolicyPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'security' && (
          <SecurityPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'contact' && (
          <ContactPage setCurrentPage={navigateTo} />
        )}

        {currentPage === 'admin-dashboard' && (
          <AdminDashboardPage
            courses={courses}
            onUpdateCoursePlaylist={handleUpdateCoursePlaylist}
            onLogout={() => {
              setIsAdminAuthenticated(false);
              setAdminToken('');
              navigateTo('home');
            }}
            adminToken={adminToken}
          />
        )}
      </main>

      {/* Floating AI Assistant Trigger Button (Bottom-Right) */}
      <div className="fixed bottom-6 right-6 z-40 no-print">
        <button
          onClick={() => setIsAIAssistantOpen(true)}
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-xl shadow-blue-700/30 hover:scale-105 active:scale-95 transition-all border border-blue-400/40"
          id="btn-floating-ai-assistant"
          title="Open AI Learning Advisor"
        >
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          <span className="hidden sm:inline">Ask FlowBot AI</span>
          <span className="sm:hidden">AI Bot</span>
        </button>
      </div>

      {/* Global Footer */}
      <Footer setCurrentPage={navigateTo} />

      {/* Owner Authentication Modal */}
      <OwnerAuthModal
        isOpen={isOwnerModalOpen}
        onClose={() => setIsOwnerModalOpen(false)}
        onAuthenticated={handleOwnerAuthenticated}
      />

      {/* AI Assistant Chatbot Modal */}
      <AIAssistantModal
        isOpen={isAIAssistantOpen}
        onClose={() => setIsAIAssistantOpen(false)}
        setCurrentPage={navigateTo}
        onSelectCourse={handleSelectCourse}
      />

    </div>
  );
}
export default App;
