import React, { useState } from 'react';
import { 
  ArrowLeft, 
  CheckCircle, 
  Play, 
  Award, 
  HelpCircle, 
  ChevronRight, 
  ChevronLeft, 
  Volume2, 
  VolumeX, 
  BookOpen, 
  Code2, 
  CheckCircle2, 
  Menu, 
  X,
  FileText,
  Clock
} from 'lucide-react';
import { Course, Module, Lesson, UserProgress } from '../types';
import { YouTubePlaylistPlayer } from '../components/YouTubePlaylistPlayer';
import { AssessmentRunner } from '../components/AssessmentRunner';
import { generateLessonQuiz, generateModuleAssessment, generateFinalExam } from '../data/quizQuestions';

interface LearningViewProps {
  course: Course;
  initialModuleId: string;
  initialLessonId: string;
  progress: UserProgress;
  onUpdateProgress: (updated: UserProgress) => void;
  onBackToCourse: () => void;
  onShowCertificate: (certId: string) => void;
}

export const LearningView: React.FC<LearningViewProps> = ({
  course,
  initialModuleId,
  initialLessonId,
  progress,
  onUpdateProgress,
  onBackToCourse,
  onShowCertificate
}) => {
  const [currentModuleId, setCurrentModuleId] = useState(initialModuleId);
  const [currentLessonId, setCurrentLessonId] = useState(initialLessonId);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Active Assessment State: null | 'lesson-quiz' | 'module-assessment' | 'final-exam'
  const [activeAssessment, setActiveAssessment] = useState<'lesson-quiz' | 'module-assessment' | 'final-exam' | null>(null);

  const currentModule = course.modules.find((m) => m.id === currentModuleId) || course.modules[0];
  const currentLesson = currentModule?.lessons.find((l) => l.id === currentLessonId) || currentModule?.lessons[0];

  // Speech synthesis
  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported in this browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const notesString = Array.isArray(currentLesson?.notes)
        ? currentLesson.notes.join('. ')
        : (currentLesson?.notes || 'Review the core concepts presented in this module.');
      const text = `${currentLesson?.title}. Overview: ${currentLesson?.description}. Key Notes: ${notesString}`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  // Switch lesson
  const handleSelectLesson = (modId: string, lesId: string) => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
    setCurrentModuleId(modId);
    setCurrentLessonId(lesId);
    setActiveAssessment(null);
    setSidebarOpen(false);
  };

  // Pass handlers
  const handlePassLessonQuiz = (score: number) => {
    if (!currentLesson) return;
    const completed = new Set(progress.completedLessons);
    completed.add(currentLesson.id);

    const scores = { ...progress.quizScores, [currentLesson.id]: score };
    const updated: UserProgress = {
      ...progress,
      completedLessons: Array.from(completed),
      quizScores: scores,
      lastUpdated: new Date().toISOString()
    };
    onUpdateProgress(updated);
    setActiveAssessment(null);
  };

  const handlePassModuleAssessment = (score: number) => {
    if (!currentModule) return;
    const assessments = new Set(progress.completedAssessments);
    assessments.add(currentModule.id);

    const scores = { ...progress.assessmentScores, [currentModule.id]: score };
    const updated: UserProgress = {
      ...progress,
      completedAssessments: Array.from(assessments),
      assessmentScores: scores,
      lastUpdated: new Date().toISOString()
    };
    onUpdateProgress(updated);
    setActiveAssessment(null);
  };

  const handlePassFinalExam = async (score: number, studentName?: string) => {
    const finalScore = score;
    const name = studentName || 'Learn With Flow Student';

    try {
      // Send to server to register official certificate
      const res = await fetch('/api/certificates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: name,
          courseId: course.id,
          courseTitle: course.title,
          category: course.category,
          scorePercentage: finalScore,
          grade: finalScore >= 95 ? 'A+' : finalScore >= 85 ? 'A' : 'B'
        })
      });

      const data = await res.json();
      if (data.success && data.certificate) {
        const updated: UserProgress = {
          ...progress,
          finalExamPassed: true,
          finalExamScore: finalScore,
          certificate: data.certificate,
          lastUpdated: new Date().toISOString()
        };
        onUpdateProgress(updated);
        setActiveAssessment(null);
        onShowCertificate(data.certificate.id);
      }
    } catch (err) {
      console.error('Failed to issue server certificate', err);
      // Fallback local certificate record
      const fallbackId = `LWF-2026-${course.id.toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const certRecord = {
        id: fallbackId,
        studentName: name,
        courseId: course.id,
        courseTitle: course.title,
        category: course.category,
        completedDate: new Date().toISOString().split('T')[0],
        scorePercentage: finalScore,
        grade: 'A' as const,
        issuer: 'Learn With Flow Academic Board',
        ceoName: 'Muhammad Talha',
        status: 'valid' as const,
        qrVerificationUrl: `/?verify=${fallbackId}`
      };
      const updated: UserProgress = {
        ...progress,
        finalExamPassed: true,
        finalExamScore: finalScore,
        certificate: certRecord,
        lastUpdated: new Date().toISOString()
      };
      onUpdateProgress(updated);
      setActiveAssessment(null);
      onShowCertificate(fallbackId);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col no-print">
      
      {/* Top Header Controls */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xs sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToCourse}
            className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors"
            title="Back to Course Overview"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
            aria-label="Toggle syllabus sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="text-[11px] text-blue-700 font-bold uppercase tracking-wider">
              {course.title}
            </div>
            <h1 className="text-xs sm:text-sm font-bold text-slate-900 truncate max-w-xs sm:max-w-md">
              {currentLesson?.title}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Read Aloud Button */}
          <button
            onClick={handleToggleSpeech}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isSpeaking
                ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-amber-800" /> : <Volume2 className="w-3.5 h-3.5 text-blue-600" />}
            <span>{isSpeaking ? 'Stop Voice' : 'Read Aloud'}</span>
          </button>

          {/* Final Exam Quick Trigger */}
          <button
            onClick={() => setActiveAssessment('final-exam')}
            className="px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors flex items-center gap-1 shadow-2xs"
          >
            <Award className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">25-Q Final Exam</span>
          </button>
        </div>
      </div>

      {/* Main Learning Body */}
      <div className="flex-1 flex max-w-7xl mx-auto w-full">
        
        {/* Left Syllabus Sidebar (Collapsible on mobile) */}
        <aside
          className={`w-80 bg-white border-r border-slate-200 shrink-0 overflow-y-auto max-h-[calc(100vh-57px)] fixed lg:sticky top-[57px] z-20 transition-transform lg:translate-x-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">Course Syllabus</h2>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-3 space-y-4">
            {course.modules.map((mod, mIdx) => {
              const isModCompleted = progress.completedAssessments.includes(mod.id);

              return (
                <div key={mod.id} className="space-y-1">
                  <div className="px-2 py-1 flex items-center justify-between text-xs font-bold text-slate-800">
                    <span>Module {mIdx + 1}: {mod.title}</span>
                    {isModCompleted && (
                      <span className="text-[10px] text-emerald-600 font-bold">✓ Done</span>
                    )}
                  </div>

                  <div className="space-y-0.5">
                    {mod.lessons.map((les, lIdx) => {
                      const isSelected = les.id === currentLessonId;
                      const isCompleted = progress.completedLessons.includes(les.id);

                      return (
                        <button
                          key={les.id}
                          onClick={() => handleSelectLesson(mod.id, les.id)}
                          className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                            isSelected
                              ? 'bg-blue-50 text-blue-800 font-bold'
                              : 'text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 text-[9px] ${
                              isCompleted ? 'bg-emerald-500 text-white' : 'border border-slate-300'
                            }`}>
                              {isCompleted ? '✓' : lIdx + 1}
                            </span>
                            <span className="truncate">{les.title}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 shrink-0 ml-2">{les.duration}</span>
                        </button>
                      );
                    })}

                    {/* Module Assessment Button */}
                    <button
                      onClick={() => {
                        setCurrentModuleId(mod.id);
                        setActiveAssessment('module-assessment');
                      }}
                      className="w-full text-left px-2.5 py-1.5 mt-1 rounded-lg text-[11px] font-semibold text-blue-700 bg-blue-50/70 hover:bg-blue-100 flex items-center justify-between"
                    >
                      <span>Module {mIdx + 1} Assessment (15-Q)</span>
                      <span>{isModCompleted ? 'Passed' : 'Pending'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </aside>

        {/* Center Content Stage */}
        <main className="flex-1 p-4 sm:p-8 overflow-y-auto max-w-4xl">
          
          {/* Assessment Mode Runner Overlay */}
          {activeAssessment ? (
            <AssessmentRunner
              type={activeAssessment}
              title={
                activeAssessment === 'lesson-quiz'
                  ? `8-Question Quiz: ${currentLesson?.title}`
                  : activeAssessment === 'module-assessment'
                  ? `15-Question Module Assessment: ${currentModule?.title}`
                  : `25-Question Final Certification Exam: ${course.title}`
              }
              subtitle={`Academic Course: ${course.title} (${course.category})`}
              questions={
                activeAssessment === 'lesson-quiz'
                  ? generateLessonQuiz(course, currentLesson?.id || 'l1')
                  : activeAssessment === 'module-assessment'
                  ? generateModuleAssessment(course, currentModule?.id || 'm1')
                  : generateFinalExam(course)
              }
              course={course}
              onPass={(score, studentName) => {
                if (activeAssessment === 'lesson-quiz') handlePassLessonQuiz(score);
                else if (activeAssessment === 'module-assessment') handlePassModuleAssessment(score);
                else if (activeAssessment === 'final-exam') handlePassFinalExam(score, studentName);
              }}
              onClose={() => setActiveAssessment(null)}
            />
          ) : (
            <div className="space-y-6">
              
              {/* Lesson Overview Card */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-blue-50 text-blue-800 border border-blue-200">
                      Module: {currentModule?.title}
                    </span>
                    <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {currentLesson?.duration}
                    </span>
                  </div>

                  {progress.completedLessons.includes(currentLesson?.id || '') && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Lesson Quiz Passed
                    </span>
                  )}
                </div>

                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-4">
                  {currentLesson?.title}
                </h2>

                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  {currentLesson?.description}
                </p>

                {/* Embedded YouTube Educational Playlist (Strict Verified Player or Pending) */}
                <div className="mt-6">
                  <YouTubePlaylistPlayer
                    courseTitle={course.title}
                    category={course.category}
                    playlist={course.playlist}
                  />
                </div>

                {/* Technical Study Notes */}
                <div className="mt-6 p-5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                    <FileText className="w-4 h-4 text-blue-600" />
                    <span>Key Lesson Concepts & Technical Notes</span>
                  </div>
                  {Array.isArray(currentLesson?.notes) ? (
                    <ul className="list-disc list-inside space-y-1 text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {currentLesson.notes.map((note, idx) => (
                        <li key={idx}>{note}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {currentLesson?.notes || 'Follow along with the educational playlist videos above. Pay close attention to standard industry best practices, structural syntax, performance optimizations, and debugging techniques.'}
                    </p>
                  )}
                </div>

                {/* Action Controls for this Lesson */}
                <div className="mt-8 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
                  <button
                    onClick={() => setActiveAssessment('lesson-quiz')}
                    className="px-6 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-2"
                    id="btn-take-lesson-quiz"
                  >
                    <HelpCircle className="w-4 h-4" />
                    <span>Take 8-Question Lesson Quiz</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveAssessment('module-assessment')}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                    >
                      Module Assessment (15-Q)
                    </button>
                    <button
                      onClick={() => setActiveAssessment('final-exam')}
                      className="px-4 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs transition-colors"
                    >
                      Final Exam (25-Q)
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

        </main>
      </div>

    </div>
  );
};
