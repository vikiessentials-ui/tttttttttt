import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Star, 
  ArrowRight, 
  BookOpen, 
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Volume2
} from 'lucide-react';
import { Course, CourseCategory, LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface CoursesPageProps {
  courses: Course[];
  onSelectCourse: (courseId: string) => void;
  currentLang: LanguageCode;
}

const ITEMS_PER_PAGE = 24;

export const CoursesPage: React.FC<CoursesPageProps> = ({
  courses,
  onSelectCourse,
  currentLang
}) => {
  const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'verified' | 'pending'>('all');
  const [currentPage, setCurrentPage] = useState(1);

  const categories: string[] = [
    'All',
    'Web Development',
    'Mobile Development',
    'Data Science',
    'Artificial Intelligence & ML',
    'Cloud & DevOps',
    'Cybersecurity',
    'Software Engineering',
    'Programming Languages',
    'Databases',
    'UI/UX Design',
    'Emerging Tech'
  ];

  // Filter logic
  const filteredCourses = useMemo(() => {
    return courses.filter((course) => {
      // Search
      const matchesSearch = 
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.category.toLowerCase().includes(searchQuery.toLowerCase());

      // Category
      const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;

      // Level
      const matchesLevel = selectedLevel === 'All' || course.level === selectedLevel;

      // Verification Status
      const matchesVerification = 
        verificationFilter === 'all' ||
        (verificationFilter === 'verified' && course.playlist.isVerified) ||
        (verificationFilter === 'pending' && !course.playlist.isVerified);

      return matchesSearch && matchesCategory && matchesLevel && matchesVerification;
    });
  }, [courses, searchQuery, selectedCategory, selectedLevel, verificationFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredCourses.length / ITEMS_PER_PAGE) || 1;
  const paginatedCourses = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredCourses.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredCourses, currentPage]);

  const handleCategoryChange = (cat: string) => {
    setSelectedCategory(cat);
    setCurrentPage(1);
  };

  const handleSpeech = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="bg-slate-50/50 min-h-screen py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Title */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-2xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-xs font-bold uppercase tracking-wider mb-2">
                <span>Comprehensive Open Catalog</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                All 182 Technology Tracks
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
                Every track includes curated syllabus modules, confirmed educational YouTube playlists, 8-question quizzes, 15-question module assessments, and an official final examination.
              </p>
            </div>

            {/* Quick Stats Counter */}
            <div className="flex items-center gap-4 bg-slate-50 px-4 py-3 rounded-xl border border-slate-200 shrink-0">
              <div>
                <div className="text-xl font-extrabold text-blue-700">{filteredCourses.length}</div>
                <div className="text-[11px] text-slate-500 font-medium">Matching Courses</div>
              </div>
              <div className="h-8 w-px bg-slate-200" />
              <div>
                <div className="text-xl font-extrabold text-slate-800">182</div>
                <div className="text-[11px] text-slate-500 font-medium">Total in Catalog</div>
              </div>
            </div>
          </div>

          {/* Search and Filters Bar */}
          <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Search Input */}
            <div className="md:col-span-6 relative">
              <label htmlFor="course-search-input" className="sr-only">Search courses</label>
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="course-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
              />
            </div>

            {/* Level Filter */}
            <div className="md:col-span-3">
              <label htmlFor="level-filter-select" className="sr-only">Filter by Level</label>
              <select
                id="level-filter-select"
                value={selectedLevel}
                onChange={(e) => {
                  setSelectedLevel(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full py-2.5 px-3 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-600 cursor-pointer"
              >
                <option value="All">All Difficulty Levels</option>
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>

            {/* Verification Status Filter */}
            <div className="md:col-span-3">
              <label htmlFor="verification-filter-select" className="sr-only">Filter by Playlist Verification</label>
              <select
                id="verification-filter-select"
                value={verificationFilter}
                onChange={(e) => {
                  setVerificationFilter(e.target.value as any);
                  setCurrentPage(1);
                }}
                className="w-full py-2.5 px-3 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-600 cursor-pointer font-medium"
              >
                <option value="all">All Playlist Statuses</option>
                <option value="verified">Verified Playlists Only</option>
                <option value="pending">Pending Verification Only</option>
              </select>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="mt-4 flex items-center gap-1.5 overflow-x-auto pb-2 pt-1 scrollbar-thin">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => handleCategoryChange(cat)}
                  className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80 hover:text-slate-900'
                  }`}
                  id={`cat-pill-${cat.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Courses Grid */}
        {filteredCourses.length > 0 ? (
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {paginatedCourses.map((course) => (
                <div
                  key={course.id}
                  onClick={() => onSelectCourse(course.id)}
                  className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col group cursor-pointer"
                  id={`course-card-${course.id}`}
                >
                  {/* Accurate Topic Cover Image */}
                  <div className="relative aspect-video w-full bg-slate-100 overflow-hidden">
                    <img
                      src={course.coverImage}
                      alt={course.title}
                      className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                      loading="lazy"
                    />
                    
                    {/* Category Label */}
                    <div className="absolute top-2 left-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/95 text-blue-900 shadow-2xs">
                        {course.category}
                      </span>
                    </div>

                    {/* Strict Playlist Status Badge */}
                    <div className="absolute top-2 right-2">
                      {course.playlist.isVerified ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white shadow-2xs flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Verified
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-600 text-white shadow-2xs flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          Pending Review
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Meta stats */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5 font-medium">
                        <span>{course.level}</span>
                        <span className="flex items-center gap-1 text-amber-600 font-bold">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          {course.rating}
                        </span>
                      </div>

                      {/* Course Title */}
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-2 leading-snug">
                        {course.title}
                      </h3>

                      {/* Description */}
                      <p className="text-xs text-slate-600 mt-1.5 line-clamp-2 leading-relaxed">
                        {course.description}
                      </p>
                    </div>

                    {/* Footer */}
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-500 font-medium">
                          {course.modules.length} Modules
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSpeech(`${course.title}. ${course.description}`);
                          }}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded"
                          title="Read Aloud"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="font-bold text-blue-700 flex items-center gap-1 text-xs">
                        <span>Curriculum</span>
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>

                  </div>
                </div>
              ))}
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-10 flex items-center justify-between border-t border-slate-200 pt-6">
                <div className="text-xs text-slate-500">
                  Showing <span className="font-bold">{(currentPage - 1) * ITEMS_PER_PAGE + 1}</span> to{' '}
                  <span className="font-bold">
                    {Math.min(currentPage * ITEMS_PER_PAGE, filteredCourses.length)}
                  </span>{' '}
                  of <span className="font-bold">{filteredCourses.length}</span> courses
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
                    aria-label="Previous page"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((num) => {
                      // Only show current and neighbor pages if many
                      if (
                        num === 1 ||
                        num === totalPages ||
                        (num >= currentPage - 2 && num <= currentPage + 2)
                      ) {
                        return (
                          <button
                            key={num}
                            onClick={() => setCurrentPage(num)}
                            className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors ${
                              currentPage === num
                                ? 'bg-blue-700 text-white shadow-2xs'
                                : 'text-slate-600 hover:bg-slate-200/70'
                            }`}
                          >
                            {num}
                          </button>
                        );
                      }
                      if (num === currentPage - 3 || num === currentPage + 3) {
                        return (
                          <span key={num} className="text-slate-400 text-xs px-1">
                            ...
                          </span>
                        );
                      }
                      return null;
                    })}
                  </div>

                  <button
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
                    aria-label="Next page"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center my-6">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">No courses match your filter criteria</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms, choosing "All Categories", or clearing the status filter.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setSelectedLevel('All');
                setVerificationFilter('all');
              }}
              className="mt-4 px-4 py-2 rounded-lg bg-blue-700 text-white text-xs font-bold"
            >
              Reset All Filters
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
