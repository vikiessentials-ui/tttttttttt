import React from 'react';
import { Target, Compass, Sparkles, CheckCircle2, Heart } from 'lucide-react';
import { PageView } from '../types';

interface MissionPageProps {
  setCurrentPage: (page: PageView) => void;
}

export const MissionPage: React.FC<MissionPageProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Institutional Purpose
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Our Mission & Educational Commitments
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Empowering curious minds everywhere with structured, practical, and certified computer science and software development education without financial burden.
          </p>
        </div>

        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-600" />
              <span>Universal Accessibility</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
              We reject the premise that quality technical education should be restricted by expensive subscription paywalls. By partnering verified, world-class YouTube educational courses with rigorous in-platform testing and evaluation, we ensure anyone with an internet connection can build elite career skills.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Compass className="w-5 h-5 text-blue-600" />
              <span>Uncompromising Academic Rigor</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
              A certificate is only as valuable as the discipline required to earn it. We enforce an 8-question quiz for every lesson, a 15-question assessment for every module, and a 25-question final examination before granting our digital diploma.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              <span>Data Truth & Real Verification</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
              We never fabricate playlist references or pretend unverified content is confirmed. When a course is pending verification, we label it with complete transparency.
            </p>
          </div>
        </div>

        {/* Dedication Banner */}
        <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-amber-600 fill-amber-400/40 shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-amber-950">
                Credit to My Father — Muhammad Toseef
              </h4>
              <p className="text-xs text-amber-900/80">
                Honoring his values of hard work, continuous learning, and selflessness.
              </p>
            </div>
          </div>
          <button
            onClick={() => setCurrentPage('about-ceo')}
            className="text-xs font-bold px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white transition-colors shrink-0"
          >
            Read Tribute
          </button>
        </div>

      </div>
    </div>
  );
};
