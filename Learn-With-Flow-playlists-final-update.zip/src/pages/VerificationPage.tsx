import React, { useState, useEffect } from 'react';
import { ShieldCheck, Search, CheckCircle2, XCircle, Award, Calendar, User, BookOpen, ArrowRight, Printer } from 'lucide-react';
import { CertificateRecord } from '../types';

interface VerificationPageProps {
  initialCertId?: string;
  onViewCertificateDetails?: (cert: CertificateRecord) => void;
}

export const VerificationPage: React.FC<VerificationPageProps> = ({
  initialCertId = '',
  onViewCertificateDetails
}) => {
  const [certIdInput, setCertIdInput] = useState(initialCertId);
  const [isLoading, setIsLoading] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{
    verified: boolean;
    certificate?: CertificateRecord;
    message?: string;
    error?: string;
  } | null>(null);

  const performVerification = async (idToVerify: string) => {
    if (!idToVerify.trim()) return;

    setIsLoading(true);
    setVerificationResult(null);

    try {
      const res = await fetch(`/api/certificates/${encodeURIComponent(idToVerify.trim())}`);
      const data = await res.json();

      if (res.ok && data.verified) {
        setVerificationResult({
          verified: true,
          certificate: data.certificate,
          message: data.verificationMessage || 'Certificate successfully authenticated in the Learn With Flow Registry.'
        });
      } else {
        setVerificationResult({
          verified: false,
          error: data.error || `Certificate ID "${idToVerify}" is not recognized in our official registry.`
        });
      }
    } catch (err) {
      setVerificationResult({
        verified: false,
        error: 'Unable to connect to the verification registry. Please check network connection.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialCertId) {
      performVerification(initialCertId);
    }
  }, [initialCertId]);

  return (
    <div className="bg-slate-50 min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto space-y-8">
        
        {/* Header Title */}
        <div className="text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-blue-700 text-white flex items-center justify-center mx-auto shadow-md shadow-blue-700/20">
            <ShieldCheck className="w-7 h-7" />
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Official Certificate Verification Registry
          </h1>
          
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            Verify the authenticity of digital diplomas and credentials issued by Learn With Flow. Every valid certificate is backed by real server verification.
          </p>
        </div>

        {/* Verification Input Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              performVerification(certIdInput);
            }}
            className="space-y-4"
          >
            <div>
              <label htmlFor="cert-id-input" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Certificate Record ID
              </label>
              <div className="relative">
                <input
                  id="cert-id-input"
                  type="text"
                  value={certIdInput}
                  onChange={(e) => setCertIdInput(e.target.value)}
                  placeholder="e.g. LWF-2026-CERT-001 or scan QR code"
                  required
                  className="w-full pl-4 pr-32 py-3 text-sm bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:bg-white font-mono"
                />
                <button
                  type="submit"
                  disabled={isLoading || !certIdInput.trim()}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors disabled:opacity-50 flex items-center gap-1.5"
                  id="btn-verify-cert"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{isLoading ? 'Checking...' : 'Verify ID'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
              <span>Format: <code className="font-mono text-slate-700">LWF-2026-XXXX-XXXX</code></span>
              <button
                type="button"
                onClick={() => {
                  setCertIdInput('LWF-2026-CERT-001');
                  performVerification('LWF-2026-CERT-001');
                }}
                className="text-blue-700 hover:underline font-semibold"
              >
                Try Sample Record (LWF-2026-CERT-001)
              </button>
            </div>
          </form>
        </div>

        {/* Verification Result Display */}
        {verificationResult && (
          <div className="animate-fade-in">
            {verificationResult.verified && verificationResult.certificate ? (
              <div className="bg-white rounded-2xl border-2 border-emerald-500/80 shadow-md p-6 sm:p-8 space-y-6">
                
                {/* Verified Header Badge */}
                <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  <div>
                    <h3 className="text-sm font-bold">Officially Verified & Authentic</h3>
                    <p className="text-xs text-emerald-800 mt-0.5">
                      {verificationResult.message}
                    </p>
                  </div>
                </div>

                {/* Metadata Fields Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Student Full Name
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      {verificationResult.certificate.studentName}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Certificate Record ID
                    </span>
                    <span className="text-xs font-mono font-bold text-blue-700">
                      {verificationResult.certificate.id}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Course Curriculum
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      {verificationResult.certificate.courseTitle}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Discipline & Score
                    </span>
                    <span className="text-xs font-bold text-slate-900">
                      {verificationResult.certificate.category} • Grade {verificationResult.certificate.grade} ({verificationResult.certificate.scorePercentage}%)
                    </span>
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Date of Issuance
                    </span>
                    <span className="text-xs font-bold text-slate-900">
                      {verificationResult.certificate.completedDate}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-1">
                      Issuing Authority
                    </span>
                    <span className="text-xs font-bold text-slate-900">
                      Muhammad Talha, CEO • Learn With Flow Academic Board
                    </span>
                  </div>
                </div>

                {/* View Certificate Action */}
                {onViewCertificateDetails && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => onViewCertificateDetails(verificationResult.certificate!)}
                      className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
                    >
                      <Award className="w-4 h-4" />
                      <span>View Full Certificate Diploma</span>
                    </button>
                  </div>
                )}

              </div>
            ) : (
              <div className="bg-white rounded-2xl border-2 border-rose-300 p-6 sm:p-8 space-y-4 text-center">
                <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                  <XCircle className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Certificate Not Found</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  {verificationResult.error}
                </p>
                <div className="text-[11px] text-slate-400 pt-2">
                  Please verify that you have typed the exact alphanumeric string from the diploma or scanned the genuine QR code.
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
