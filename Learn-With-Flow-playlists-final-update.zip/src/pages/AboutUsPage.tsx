import React from 'react';
import { BookOpen, Award, Users, Globe, ShieldCheck, Heart } from 'lucide-react';
import { PageView } from '../types';

interface AboutUsPageProps {
  setCurrentPage: (page: PageView) => void;
}

export const AboutUsPage: React.FC<AboutUsPageProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            About Our Institution
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Learn With Flow
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
            A pioneering digital engineering institute founded by Muhammad Talha, bringing Coursera-caliber technology education, verified educational YouTube tracks, and authentic credentials to learners worldwide.
          </p>
        </div>

        {/* 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">182 Curated Tracks</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Spanning 11 core disciplines including Web Development, Machine Learning, Cloud Architecture, Cybersecurity, and Software Engineering.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Real Verification</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              We never fabricate playlist references. Every verified track is genuinely public, and certificates are cryptographically checked against our live registry.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Free Credentials</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              High-value completion diplomas featuring QR-code verification and executive curvy signature styling by CEO Muhammad Talha.
            </p>
          </div>
        </div>

        {/* Dedication Banner */}
        <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-amber-600 fill-amber-400/40 shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-amber-950">
                Credit to My Father — Muhammad Toseef
              </h4>
              <p className="text-xs text-amber-900/80">
                Recognizing his lifelong hard work, sacrifices, and unconditional support that inspired this platform.
              </p>
            </div>
          </div>
          <button
            onClick={() => setCurrentPage('about-ceo')}
            className="text-xs font-bold px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white transition-colors shrink-0"
          >
            Read Tribute
          </button>
        </div>

      </div>
    </div>
  );
};
