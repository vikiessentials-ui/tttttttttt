import React from 'react';
import { Heart, Award, BookOpen, ShieldCheck, Mail, Globe, Sparkles, CheckCircle2, Quote } from 'lucide-react';
import { PageView } from '../types';

interface AboutCEOPageProps {
  setCurrentPage: (page: PageView) => void;
}

export const AboutCEOPage: React.FC<AboutCEOPageProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* CEO Profile Header */}
        <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 rounded-3xl text-white p-8 sm:p-12 shadow-xl border border-slate-800 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-8 text-center sm:text-left">
            {/* Monogram / Avatar */}
            <div className="w-28 h-28 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 p-1 shadow-2xl shrink-0">
              <div className="w-full h-full rounded-xl bg-slate-900 flex flex-col items-center justify-center text-white border border-blue-400/30">
                <span className="text-3xl font-extrabold tracking-tighter text-amber-300">MT</span>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Founder</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>Founder & Chief Executive Officer</span>
              </div>

              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                Muhammad Talha
              </h1>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
                Founder, systems engineer, and education accessibility advocate. Dedicated to eliminating financial and geographical hurdles in modern computer science, artificial intelligence, and software engineering training.
              </p>

              <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                  182 Open Curriculums
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Verifiable Credentials
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* HIGHEST PRIORITY REQUIRED SECTION:
            "Credit to My Father — Muhammad Toseef"
            Respectfully recognizing his hard work, sacrifices, support and encouragement.
        */}
        <div className="bg-amber-50/70 border-2 border-amber-300/80 rounded-3xl p-8 sm:p-10 shadow-sm relative overflow-hidden">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold uppercase tracking-wider">
              <Heart className="w-4 h-4 text-amber-600 fill-amber-500/40" />
              <span>Dedicated Tribute</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-950 tracking-tight">
              Credit to My Father — Muhammad Toseef
            </h2>

            <div className="w-16 h-0.5 bg-amber-400 mx-auto" />

            <p className="text-xs sm:text-sm text-amber-900/90 leading-relaxed font-medium">
              Every milestone achieved by Learn With Flow, and every student who discovers new opportunities through this platform, stands as a living testament to the sacrifices, resilience, and unconditional encouragement of my beloved father, <strong>Muhammad Toseef</strong>.
            </p>

            <div className="p-5 rounded-2xl bg-white/90 border border-amber-200 text-left text-xs sm:text-sm text-slate-700 leading-relaxed shadow-2xs space-y-3 relative">
              <Quote className="w-8 h-8 text-amber-300 absolute right-4 bottom-4 opacity-40 pointer-events-none" />
              <p>
                “Throughout my life, my father worked tirelessly to ensure I had every tool, book, and chance to study technology. When resources were limited and challenges appeared insurmountable, his quiet sacrifices and unwavering faith kept our ambition burning brightly. He taught me that genuine success is never measured by personal accumulation, but by how many lives you uplift and empower along the way.”
              </p>
              <p className="text-right font-bold text-slate-900 not-italic pt-1">
                — Muhammad Talha, <span className="font-normal text-slate-500 text-xs">Founder & CEO</span>
              </p>
            </div>

            <p className="text-xs text-amber-800 italic pt-2">
              With deepest respect, enduring gratitude, and everlasting prayers for his health, peace, and happiness.
            </p>

          </div>
        </div>

        {/* CEO Vision & Core Philosophy */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
          <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 space-y-3">
            <h3 className="text-lg font-bold text-slate-900">
              The Genesis of Learn With Flow
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              When observing the online education landscape, Muhammad Talha noticed a recurring issue: either students encountered exorbitant $2,000+ certification paywalls, or free playlists scattered with no syllabus structure, broken links, or missing assessment mechanisms.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Learn With Flow resolves this dilemma by delivering the rigorous course structure, modular evaluations, and authentic cryptographic credentialing of elite platforms like Coursera, while remaining 100% free and open to all.
            </p>
          </div>

          <div className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-200 space-y-3">
            <h3 className="text-lg font-bold text-slate-900">
              Authenticity & Real Data Policy
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Under Muhammad Talha's strict direction, Learn With Flow adheres to an uncompromising principle: <strong>Real Data &gt; Complete Data</strong>. No artificial or unrelated YouTube playlists are ever attached to fill a catalog slot.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Every verified track is individually audited, and unverified tracks are transparently marked as pending review until rigorous academic standards are met.
            </p>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center pt-4">
          <button
            onClick={() => setCurrentPage('courses')}
            className="px-6 py-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition-colors inline-flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Explore All 182 Technology Curriculums</span>
          </button>
        </div>

      </div>
    </div>
  );
};
