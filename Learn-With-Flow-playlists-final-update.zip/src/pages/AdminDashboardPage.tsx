import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  BookOpen, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Edit3, 
  Save, 
  X, 
  Download, 
  LogOut, 
  ExternalLink,
  Layers,
  Sparkles,
  Check,
  RefreshCw,
  Eye
} from 'lucide-react';
import { Course, CertificateRecord } from '../types';

interface AdminDashboardPageProps {
  courses: Course[];
  onUpdateCoursePlaylist: (courseId: string, updatedPlaylist: any) => void;
  onLogout: () => void;
  adminToken: string;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({
  courses,
  onUpdateCoursePlaylist,
  onLogout,
  adminToken
}) => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'audit' | 'certificates'>('audit');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'verified' | 'pending'>('all');
  
  // Edit modal state
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [editPlaylistId, setEditPlaylistId] = useState('');
  const [editPlaylistUrl, setEditPlaylistUrl] = useState('');
  const [editPlaylistTitle, setEditPlaylistTitle] = useState('');
  const [editChannel, setEditChannel] = useState('');
  const [editIsVerified, setEditIsVerified] = useState(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);

  // Certificates list
  const [certificates, setCertificates] = useState<CertificateRecord[]>([]);

  React.useEffect(() => {
    fetch('/api/certificates')
      .then((res) => res.json())
      .then((data) => {
        if (data.certificates) setCertificates(data.certificates);
      })
      .catch((err) => console.error('Error fetching certificates', err));
  }, []);

  // Stats calculation
  const verifiedCount = courses.filter((c) => c.playlist.isVerified).length;
  const pendingCount = courses.length - verifiedCount;

  // Filtered courses for Catalog and Audit table
  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      const matchesSearch = 
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.playlist.channel && c.playlist.channel.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStatus = 
        filterStatus === 'all' ||
        (filterStatus === 'verified' && c.playlist.isVerified) ||
        (filterStatus === 'pending' && !c.playlist.isVerified);

      return matchesSearch && matchesStatus;
    });
  }, [courses, searchQuery, filterStatus]);

  const handleOpenEdit = (course: Course) => {
    setEditingCourse(course);
    setEditPlaylistId(course.playlist.id || '');
    setEditPlaylistUrl(course.playlist.url || '');
    setEditPlaylistTitle(course.playlist.title || '');
    setEditChannel(course.playlist.channel || '');
    setEditIsVerified(course.playlist.isVerified);
    setSaveSuccessNotice(null);
  };

  const handleSavePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCourse) return;

    const updatedPlaylist = {
      id: editPlaylistId.trim(),
      url: editPlaylistUrl.trim() || (editPlaylistId.trim() ? `https://www.youtube.com/playlist?list=${editPlaylistId.trim()}` : ''),
      title: editPlaylistTitle.trim() || `${editingCourse.title} Educational Track`,
      channel: editChannel.trim() || 'Verified Educational Partner',
      isVerified: editIsVerified
    };

    try {
      const res = await fetch(`/api/courses/${editingCourse.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({ playlist: updatedPlaylist })
      });

      if (res.ok) {
        onUpdateCoursePlaylist(editingCourse.id, updatedPlaylist);
        setSaveSuccessNotice(`Successfully updated playlist settings for ${editingCourse.title}`);
        setTimeout(() => {
          setEditingCourse(null);
          setSaveSuccessNotice(null);
        }, 1200);
      }
    } catch (err) {
      console.error('Failed to update playlist', err);
    }
  };

  const handleExportCSV = () => {
    const headers = ['Course ID', 'Course Name', 'Category', 'Playlist URL', 'Playlist ID', 'Channel', 'Verification Status', 'Topic Match Status'];
    const rows = courses.map((c) => [
      `"${c.id}"`,
      `"${c.title.replace(/"/g, '""')}"`,
      `"${c.category}"`,
      `"${c.playlist.url || ''}"`,
      `"${c.playlist.id || ''}"`,
      `"${c.playlist.channel || ''}"`,
      `"${c.playlist.isVerified ? 'VERIFIED' : 'PENDING'}"`,
      `"${c.playlist.isVerified ? 'Exact Curriculum Match' : 'Pending Academic Review'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'LearnWithFlow_182_Courses_Audit_Report.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-100 min-h-screen py-8 px-4 sm:px-6 lg:px-8 no-print">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Top Header */}
        <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                  Owner Administrative Dashboard
                </h1>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Authenticated Session
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Founder: <strong>Muhammad Talha</strong> • Learn With Flow Central Governance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Export Audit CSV</span>
            </button>

            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600/90 hover:bg-rose-700 text-white text-xs font-bold transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* 4 Metric Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Courses</div>
            <div className="text-2xl font-extrabold text-slate-900 mt-1">{courses.length}</div>
            <div className="text-[11px] text-slate-400 mt-1">11 Core Engineering Disciplines</div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600">Verified Playlists</div>
            <div className="text-2xl font-extrabold text-emerald-700 mt-1">{verifiedCount}</div>
            <div className="text-[11px] text-emerald-600 mt-1">Confirmed Public Tracks</div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-600">Pending Review</div>
            <div className="text-2xl font-extrabold text-amber-700 mt-1">{pendingCount}</div>
            <div className="text-[11px] text-amber-600 mt-1">Under Real-Data Audit</div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-bold uppercase tracking-wider text-blue-600">Issued Certificates</div>
            <div className="text-2xl font-extrabold text-blue-700 mt-1">{certificates.length}</div>
            <div className="text-[11px] text-blue-600 mt-1">Verifiable in Registry</div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-xl border border-slate-200 p-2 flex items-center gap-2 shadow-2xs">
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'audit'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Course Audit Report (182 Tracks)
          </button>

          <button
            onClick={() => setActiveTab('catalog')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'catalog'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Playlist & Content Manager
          </button>

          <button
            onClick={() => setActiveTab('certificates')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'certificates'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Certificate Registry ({certificates.length})
          </button>
        </div>

        {/* TAB 1: AUDIT REPORT TABLE (Strictly addresses user audit report requirements) */}
        {activeTab === 'audit' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Comprehensive 182-Course Audit Report
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Real data verification log matching Course Name, Playlist URL, Playlist ID, Verification Status, and Topic Match Status.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search audit data..."
                    className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="py-1.5 px-3 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                >
                  <option value="all">All Verification Statuses</option>
                  <option value="verified">Verified Only ({verifiedCount})</option>
                  <option value="pending">Pending Only ({pendingCount})</option>
                </select>
              </div>
            </div>

            {/* Audit Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">#</th>
                    <th className="py-3 px-4">Course Name</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Playlist ID</th>
                    <th className="py-3 px-4">Playlist URL</th>
                    <th className="py-3 px-4">Verification Status</th>
                    <th className="py-3 px-4">Topic Match Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCourses.map((c, idx) => (
                    <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">{idx + 1}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900 max-w-xs">
                        <div>{c.title}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{c.id}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{c.category}</td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-700 max-w-[160px] truncate">
                        {c.playlist.id ? (
                          <span className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                            {c.playlist.id}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">None assigned</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-blue-700 max-w-[200px] truncate">
                        {c.playlist.url ? (
                          <a
                            href={c.playlist.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline inline-flex items-center gap-1"
                          >
                            <span className="truncate">{c.playlist.url}</span>
                            <ExternalLink className="w-3 h-3 shrink-0" />
                          </a>
                        ) : (
                          <span className="text-slate-400 italic">Pending assignment</span>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {c.playlist.isVerified ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-[10px]">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            VERIFIED
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300 font-bold text-[10px]">
                            <AlertCircle className="w-3 h-3 text-amber-600" />
                            PENDING
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {c.playlist.isVerified ? (
                          <span className="text-emerald-700 font-semibold">Exact Curriculum Match</span>
                        ) : (
                          <span className="text-amber-700 font-medium">Pending Academic Review</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => handleOpenEdit(c)}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 font-semibold text-[11px] transition-colors inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
              <span>Showing {filteredCourses.length} of 182 audited courses</span>
              <span className="font-semibold text-slate-700">Strict Real Data Policy: NEVER guess or fabricate playlist IDs</span>
            </div>
          </div>
        )}

        {/* TAB 2: PLAYLIST & CONTENT MANAGER */}
        {activeTab === 'catalog' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Course Playlist Manager</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCourses.slice(0, 30).map((c) => (
                <div key={c.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <div className="flex items-start justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                      {c.category}
                    </span>
                    <button
                      onClick={() => handleOpenEdit(c)}
                      className="text-xs text-blue-700 font-bold hover:underline flex items-center gap-1"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Edit Playlist</span>
                    </button>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{c.title}</h4>
                  <div className="text-[11px] text-slate-600">
                    <div>Playlist: {c.playlist.title || 'Unassigned'}</div>
                    <div>Status: {c.playlist.isVerified ? '✓ Verified' : '⏳ Pending'}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CERTIFICATES REGISTRY */}
        {activeTab === 'certificates' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Official Certificate Registry</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                    <th className="py-2.5 px-3">Certificate ID</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">Course Title</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Grade</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {certificates.map((cert) => (
                    <tr key={cert.id}>
                      <td className="py-2.5 px-3 font-mono font-bold text-blue-700">{cert.id}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{cert.studentName}</td>
                      <td className="py-2.5 px-3 text-slate-700">{cert.courseTitle}</td>
                      <td className="py-2.5 px-3 text-slate-500">{cert.completedDate}</td>
                      <td className="py-2.5 px-3 font-bold text-slate-800">{cert.grade} ({cert.scorePercentage}%)</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                          Valid in Registry
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Edit Playlist Dialog Modal */}
        {editingCourse && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-2xs p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden">
              <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold">Edit Course Playlist Settings</h3>
                  <p className="text-xs text-slate-400">{editingCourse.title}</p>
                </div>
                <button
                  onClick={() => setEditingCourse(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSavePlaylist} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    YouTube Playlist ID
                  </label>
                  <input
                    type="text"
                    value={editPlaylistId}
                    onChange={(e) => setEditPlaylistId(e.target.value)}
                    placeholder="e.g. PL... or leave blank if pending"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Strict Rule: Only input valid, confirmed public playlist IDs.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Playlist Direct URL
                  </label>
                  <input
                    type="url"
                    value={editPlaylistUrl}
                    onChange={(e) => setEditPlaylistUrl(e.target.value)}
                    placeholder="https://www.youtube.com/playlist?list=..."
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Educational Channel / Provider
                  </label>
                  <input
                    type="text"
                    value={editChannel}
                    onChange={(e) => setEditChannel(e.target.value)}
                    placeholder="e.g. freeCodeCamp.org, CS50, Net Ninja"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <input
                    id="verify-checkbox"
                    type="checkbox"
                    checked={editIsVerified}
                    onChange={(e) => setEditIsVerified(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <label htmlFor="verify-checkbox" className="text-xs font-bold text-slate-800">
                    Mark Playlist as Officially Verified
                  </label>
                </div>

                {saveSuccessNotice && (
                  <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                    {saveSuccessNotice}
                  </div>
                )}

                <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingCourse(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
