import React from 'react';
import { ShieldCheck, Lock, Eye, CheckCircle2, Server, Key, AlertTriangle } from 'lucide-react';
import { PageView } from '../types';

interface PolicyProps {
  setCurrentPage: (page: PageView) => void;
}

export const PrivacyPolicyPage: React.FC<PolicyProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8 text-slate-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Legal & Trust
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900 mt-2">Privacy Policy</h1>
          <p className="text-xs text-slate-500 mt-1">Last Updated: September 2026</p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">1. Information Collection</h2>
            <p>
              Learn With Flow prioritizes learner privacy. We do not sell, rent, or monetize personal student information. When you earn a certificate, we store your student name, course ID, grade, and timestamp strictly for validation in our public verification registry.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">2. YouTube Embeds & Cookie Policy</h2>
            <p>
              Educational course videos are rendered using YouTube's official privacy-enhanced mode (<code>youtube-nocookie.com</code>). When you interact with embedded YouTube video players, Google's standard YouTube terms and privacy practices apply. If you prefer not to use embedded players, a direct link to open the playlist on YouTube is always provided.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">3. Certificate Verification Public Data</h2>
            <p>
              Certificates generated upon passing the 25-question final exam are accessible via unique verification links and QR codes. Anyone possessing the Certificate ID may verify that the credential was legitimately issued by the Learn With Flow Academic Board.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export const SecurityPage: React.FC<PolicyProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8 text-slate-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Platform Integrity
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900 mt-2">Security & Verification Standards</h1>
          <p className="text-xs text-slate-500 mt-1">Institutional Verification Protocols</p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <div className="p-6 rounded-2xl bg-blue-50/70 border border-blue-200 flex items-start gap-4">
            <ShieldCheck className="w-8 h-8 text-blue-700 shrink-0 mt-1" />
            <div>
              <h3 className="text-base font-bold text-blue-950">Real Server-Side Authentication</h3>
              <p className="text-xs text-blue-900/90 mt-1">
                Owner administrative privileges and credential issuance endpoints are authenticated strictly on the server-side. Owner codes and administrative secrets are never stored in client-side HTML, localStorage, or public assets.
              </p>
            </div>
          </div>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">1. Cryptographic Record ID Architecture</h2>
            <p>
              Every certificate record ID (e.g. <code>LWF-2026-COURSE1-XXXX</code>) is indexed in our backend registry. Verification queries make live round-trips to authenticate authenticity, student full name, course curriculum, and issue dates.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">2. Playlist Integrity & Prevention of Deceptive Links</h2>
            <p>
              In accordance with our strict educational guidelines, no artificial, guessed, or dead YouTube links are tolerated. Playlists undergo audit reporting and verification validation before status badges are awarded.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC<PolicyProps> = ({ setCurrentPage }) => {
  const [submitted, setSubmitted] = React.useState(false);

  return (
    <div className="bg-white min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto space-y-8 text-slate-800">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Get in Touch
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900">Contact Academic Support</h1>
          <p className="text-xs sm:text-sm text-slate-600">
            Have questions about course curriculums, playlists, or certificate verification? Our team is here to support your learning journey.
          </p>
        </div>

        {submitted ? (
          <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
            <h3 className="text-base font-bold text-emerald-950">Inquiry Received</h3>
            <p className="text-xs text-emerald-800">
              Thank you for reaching out. An academic advisor will review your message promptly.
            </p>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(true);
            }}
            className="p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-2xs bg-slate-50 space-y-4"
          >
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Your Full Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Tariq Ahmad"
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                placeholder="name@domain.com"
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Subject
              </label>
              <select className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-600">
                <option>General Curriculum Inquiry</option>
                <option>Certificate Verification Assistance</option>
                <option>YouTube Playlist Suggestion / Verification</option>
                <option>Founder / Partnership Inquiry</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Message
              </label>
              <textarea
                rows={4}
                required
                placeholder="Write your message here..."
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-sm transition-colors"
            >
              Submit Inquiry
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
