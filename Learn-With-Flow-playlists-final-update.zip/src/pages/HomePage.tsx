import React from 'react';
import { 
  BookOpen, 
  Award, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Youtube, 
  Layers, 
  GraduationCap, 
  Users, 
  Star, 
  TrendingUp,
  Heart,
  ChevronRight,
  Code,
  Terminal,
  Cpu,
  Shield,
  Cloud,
  Database
} from 'lucide-react';
import { Course, PageView, LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface HomePageProps {
  courses: Course[];
  onSelectCourse: (courseId: string) => void;
  setCurrentPage: (page: PageView) => void;
  currentLang: LanguageCode;
  openAIAssistant: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  courses,
  onSelectCourse,
  setCurrentPage,
  currentLang,
  openAIAssistant
}) => {
  const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;

  // Selected spotlight courses across key domains
  const featuredCourses = courses.filter((c) => 
    ['course-1', 'course-41', 'course-59', 'course-79', 'course-99', 'course-135'].includes(c.id)
  );

  const categoriesOverview = [
    { title: 'Web Development', count: 24, icon: <Code className="w-5 h-5 text-blue-600" />, desc: 'Modern HTML5, React 19, TypeScript, Next.js, Node.js & Full-Stack' },
    { title: 'Artificial Intelligence & ML', count: 20, icon: <Cpu className="w-5 h-5 text-purple-600" />, desc: 'Deep Learning, PyTorch, Transformers, LLMs, Gemini AI & RAG' },
    { title: 'Cybersecurity', count: 20, icon: <Shield className="w-5 h-5 text-emerald-600" />, desc: 'CompTIA Security+, Ethical Hacking, SOC Analytics & OWASP Top 10' },
    { title: 'Cloud & DevOps', count: 20, icon: <Cloud className="w-5 h-5 text-sky-600" />, desc: 'Google Cloud, AWS Solutions Architect, Docker, Kubernetes & Terraform' },
    { title: 'Data Science & Analytics', count: 18, icon: <Database className="w-5 h-5 text-amber-600" />, desc: 'Python Pandas, Data Visualization, SQL, Power BI & Statistical Models' },
    { title: 'Software Engineering', count: 16, icon: <Terminal className="w-5 h-5 text-indigo-600" />, desc: 'System Design, Microservices, Data Structures, Algorithms & Clean Code' }
  ];

  return (
    <div className="bg-white text-slate-900">
      
      {/* 1. HERO SECTION: Clean Coursera-style White & Royal Blue */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 border-b border-slate-200/80 overflow-hidden">
        {/* Subtle decorative background gradients */}
        <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-blue-50/60 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 rounded-full bg-amber-50/50 blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Trust Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 border border-blue-200/80 text-blue-900 text-xs font-bold shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                <span>Coursera-Standard Open Platform</span>
                <span className="text-slate-300">|</span>
                <span className="text-amber-700 font-semibold">182 Active Curriculums</span>
              </div>

              {/* Main Headline */}
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12]">
                Master Real Tech Skills. <br />
                <span className="text-blue-700">Built for Tomorrow.</span>
              </h1>

              {/* Subheadline */}
              <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
                Learn With Flow provides 182 structured technology tracks pairing confirmed educational YouTube playlists with rigorous 8-question lesson quizzes, 15-question module assessments, and verifiable digital certificates.
              </p>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  onClick={() => setCurrentPage('courses')}
                  className="px-7 py-3.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow-md shadow-blue-700/20 hover:shadow-lg transition-all flex items-center gap-2 active:scale-98"
                  id="hero-btn-explore"
                >
                  <span>{t.heroExploreBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={openAIAssistant}
                  className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm border border-slate-300 hover:border-slate-400 transition-all flex items-center gap-2 shadow-2xs active:scale-98"
                  id="hero-btn-ai-advisor"
                >
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>AI Learning Advisor</span>
                </button>
              </div>

              {/* Guarantee points */}
              <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-200/80 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Real Educational Playlists</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Modular Assessments</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Verified QR Certificates</span>
                </div>
              </div>

            </div>

            {/* Right Hero Graphic: Live Course Preview & Verification Badge */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 relative overflow-hidden">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                    <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                    <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                    <span className="text-xs font-bold text-slate-700 ml-2">Learn With Flow Interactive LMS</span>
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                    Live Portal
                  </span>
                </div>

                {/* Simulated Certificate Teaser */}
                <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-amber-700">Official Award</span>
                      <h4 className="text-sm font-extrabold text-slate-900 mt-0.5">Verified Digital Certificate</h4>
                      <p className="text-xs text-slate-500 mt-1">
                        Issued by CEO Muhammad Talha upon passing the 25-question final exam.
                      </p>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-blue-700 text-amber-300 flex items-center justify-center shrink-0 border-2 border-amber-400">
                      <Award className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">Validation Status:</span>
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Cryptographically Validated
                    </span>
                  </div>
                </div>

                {/* Quick Stats Metric Cards */}
                <div className="mt-4 grid grid-cols-2 gap-3 text-center">
                  <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-100">
                    <div className="text-xl font-extrabold text-blue-900">182</div>
                    <div className="text-[11px] text-blue-700 font-semibold">Structured Tracks</div>
                  </div>
                  <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-100">
                    <div className="text-xl font-extrabold text-amber-900">1,400+</div>
                    <div className="text-[11px] text-amber-700 font-semibold">Modular Lessons</div>
                  </div>
                </div>

                {/* Quick Link to Verification */}
                <div className="mt-4 pt-3 border-t border-slate-100 text-center">
                  <button
                    onClick={() => setCurrentPage('verification')}
                    className="text-xs font-bold text-blue-700 hover:text-blue-800 inline-flex items-center gap-1"
                  >
                    <span>Have a Certificate ID? Check Registry Authenticity</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. COURSERA-STYLE 4-TIER LEARNING PROGRESSION BANNER */}
      <section className="py-14 bg-slate-50 border-b border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
              Rigorous Academic Pipeline
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
              How You Master Each Technology
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Every course enforces a complete, verifiable competency progression.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            
            {/* Step 1 */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs relative">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center mb-4 text-base">
                1
              </div>
              <h3 className="text-base font-bold text-slate-900">Course & Modules</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Structured curriculums broken down into focused modules with verified YouTube educational playlists from world-class instructors.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs relative">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center mb-4 text-base">
                2
              </div>
              <h3 className="text-base font-bold text-slate-900">8-Question Quizzes</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Each individual lesson features an 8-question quiz with instant answer verification and explanatory rationales.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs relative">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center mb-4 text-base">
                3
              </div>
              <h3 className="text-base font-bold text-slate-900">15-Question Assessments</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Comprehensive module assessments test synthesized domain knowledge before unlocking subsequent advanced modules.
              </p>
            </div>

            {/* Step 4 */}
            <div className="bg-white p-6 rounded-xl border border-amber-300 shadow-2xs relative ring-1 ring-amber-300/40">
              <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 font-bold flex items-center justify-center mb-4 text-base">
                4
              </div>
              <h3 className="text-base font-bold text-slate-900">25-Question Final Exam</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Score 80%+ to generate an official digital certificate with a QR code and curvy signature by CEO Muhammad Talha.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* 3. FEATURED COURSES SPOTLIGHT */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
              Curated Curriculum Highlights
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Featured Technology Tracks
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Explore high-demand career tracks with verified educational playlists.
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('courses')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-blue-800"
          >
            <span>View All 182 Courses</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredCourses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col group cursor-pointer"
              onClick={() => onSelectCourse(course.id)}
            >
              {/* Cover Image */}
              <div className="relative aspect-video w-full bg-slate-100 overflow-hidden">
                <img
                  src={course.coverImage}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                  loading="lazy"
                />
                <div className="absolute top-2.5 left-2.5">
                  <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-white/95 text-blue-800 shadow-2xs">
                    {course.category}
                  </span>
                </div>
                {course.playlist.isVerified ? (
                  <div className="absolute top-2.5 right-2.5">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-600 text-white shadow-2xs flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Verified Playlist
                    </span>
                  </div>
                ) : (
                  <div className="absolute top-2.5 right-2.5">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-600 text-white shadow-2xs">
                      Pending Verification
                    </span>
                  </div>
                )}
              </div>

              {/* Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                    <span>{course.level}</span>
                    <span className="flex items-center gap-1 text-amber-600 font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {course.rating}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-2">
                    {course.title}
                  </h3>

                  <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                    {course.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-medium">
                    {course.modules.length} Modules • {course.estimatedHours || course.duration || '20 Hours'}
                  </span>
                  <span className="font-bold text-blue-700 flex items-center gap-1">
                    <span>Start Track</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. DISCIPLINE DOMAINS GRID */}
      <section className="py-14 bg-slate-50 border-t border-b border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Explore 11 Academic Disciplines
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Select any discipline to browse corresponding verified courses.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {categoriesOverview.map((cat, idx) => (
              <div
                key={idx}
                onClick={() => setCurrentPage('courses')}
                className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 group-hover:bg-blue-50 flex items-center justify-center transition-colors">
                    {cat.icon}
                  </div>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 group-hover:bg-blue-100 group-hover:text-blue-800 transition-colors">
                    {cat.count} Tracks
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors mt-3">
                  {cat.title}
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {cat.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. TRIBUTE TO FATHER MUHAMMAD TOSEEF & ABOUT CEO BANNER */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900 to-blue-950 rounded-2xl text-white p-8 sm:p-12 shadow-xl border border-slate-800 relative overflow-hidden">
          
          <div className="max-w-3xl space-y-4 relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
              <Heart className="w-3.5 h-3.5 text-amber-400 fill-amber-400/30" />
              <span>Founder’s Dedication</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
              Credit to My Father — Muhammad Toseef
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Learn With Flow was founded by Muhammad Talha with the conviction that no ambitious student should ever be denied world-class technical education due to financial barriers. The creation of this platform is dedicated in everlasting gratitude to his father, <strong>Muhammad Toseef</strong>, recognizing his decades of hard work, sacrifices, unwavering moral support, and constant encouragement.
            </p>

            <div className="pt-3 flex flex-wrap items-center gap-4">
              <button
                onClick={() => setCurrentPage('about-ceo')}
                className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition-colors shadow-sm flex items-center gap-1.5"
                id="btn-read-ceo-tribute"
              >
                <span>Read the Founder’s Story & Tribute</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setCurrentPage('mission')}
                className="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 transition-colors"
              >
                <span>Our Educational Mission</span>
              </button>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
