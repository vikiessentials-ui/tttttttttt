import React, { useState } from 'react';
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle2, 
  AlertCircle, 
  Star, 
  Clock, 
  Award, 
  Play, 
  Layers, 
  CheckCircle, 
  HelpCircle, 
  GraduationCap, 
  ChevronDown, 
  ChevronUp,
  Volume2
} from 'lucide-react';
import { Course, UserProgress } from '../types';
import { YouTubePlaylistPlayer } from '../components/YouTubePlaylistPlayer';

interface CourseDetailPageProps {
  course: Course;
  progress?: UserProgress;
  onBack: () => void;
  onStartLearning: (courseId: string, moduleId: string, lessonId: string) => void;
  onTakeFinalExam: (courseId: string) => void;
  onViewCertificate?: () => void;
}

export const CourseDetailPage: React.FC<CourseDetailPageProps> = ({
  course,
  progress,
  onBack,
  onStartLearning,
  onTakeFinalExam,
  onViewCertificate
}) => {
  if (!course) {
    return (
      <div className="bg-slate-50 min-h-screen py-16 px-4 text-center">
        <div className="max-w-md mx-auto bg-white p-8 rounded-2xl border border-slate-200 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 mb-2">Course Information Unavailable</h2>
          <p className="text-slate-600 text-xs mb-4">The requested course could not be loaded. Please return to the course catalog.</p>
          <button
            onClick={onBack}
            className="px-4 py-2 bg-blue-700 text-white text-xs font-bold rounded-lg hover:bg-blue-800 transition-colors"
          >
            Back to All Courses
          </button>
        </div>
      </div>
    );
  }

  const modules = course.modules || [];
  const [openModules, setOpenModules] = useState<Record<string, boolean>>({
    [modules[0]?.id || 'mod-1']: true
  });

  const toggleModule = (modId: string) => {
    setOpenModules((prev) => ({
      ...prev,
      [modId]: !prev[modId]
    }));
  };

  const totalLessons = modules.reduce((acc, m) => acc + (m.lessons?.length || 0), 0);
  const completedLessonsCount = progress?.completedLessons?.length || 0;
  const isFinalExamUnlocked = (progress?.completedAssessments?.length || 0) === modules.length;
  const hasCertificate = !!progress?.certificate;

  const handleSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const text = `${course.title}. Category: ${course.category}. Description: ${course.description}`;
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All 182 Courses</span>
          </button>

          <button
            onClick={handleSpeech}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-semibold text-slate-600 hover:text-blue-700 hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Volume2 className="w-4 h-4 text-blue-600" />
            <span>Read Course Info</span>
          </button>
        </div>

        {/* Course Header Banner */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            
            {/* Left Info Column */}
            <div className="lg:col-span-8 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                    {course.category}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-700">
                    Level: {course.level}
                  </span>
                  <span className="flex items-center gap-1 text-xs font-bold text-amber-600 bg-amber-50 px-2.5 py-0.5 rounded-md border border-amber-200">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    {course.rating} ({(course.enrolledCount ?? course.studentsCount ?? 0).toLocaleString()} learners)
                  </span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  {course.title}
                </h1>

                <p className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                  {course.description}
                </p>

                {/* Prerequisites & Outcomes */}
                <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="font-bold text-slate-800 block mb-1">Prerequisites:</span>
                    <ul className="list-disc list-inside text-slate-500 space-y-0.5">
                      {course.prerequisites.map((p, idx) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block mb-1">Learning Outcomes:</span>
                    <ul className="list-disc list-inside text-slate-500 space-y-0.5">
                      {course.learningOutcomes.map((o, idx) => (
                        <li key={idx}>{o}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="mt-8 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-3">
                {course.modules[0]?.lessons[0] && (
                  <button
                    onClick={() => onStartLearning(course.id, course.modules[0].id, course.modules[0].lessons[0].id)}
                    className="px-6 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-sm transition-all flex items-center gap-2"
                    id="btn-start-course-syllabus"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>
                      {completedLessonsCount > 0 ? 'Continue Curriculum' : 'Start Course (Lesson 1)'}
                    </span>
                  </button>
                )}

                {hasCertificate && onViewCertificate && (
                  <button
                    onClick={onViewCertificate}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    <Award className="w-4 h-4" />
                    <span>View Official Certificate</span>
                  </button>
                )}

                <button
                  onClick={() => onTakeFinalExam(course.id)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  <span>25-Question Final Exam</span>
                </button>
              </div>

            </div>

            {/* Right Media Column: Exact Matching Cover Image */}
            <div className="lg:col-span-4 bg-slate-100 relative min-h-[220px]">
              <img
                src={course.coverImage}
                alt={course.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex flex-col justify-end p-5 text-white">
                <div className="text-xs font-bold text-amber-300">Learn With Flow Standard</div>
                <div className="text-sm font-extrabold">{totalLessons} Comprehensive Lessons</div>
                <div className="text-[11px] text-slate-300">
                  {(course.modules?.length || 0)} Modules • {course.estimatedHours || course.duration || '20 Hours'}
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Embedded YouTube Playlist Component (Strict Verified Player or Transparent Pending Review) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              <span>Official YouTube Educational Playlist</span>
            </h2>
            <span className="text-xs text-slate-500">Real verified curriculum video track</span>
          </div>

          <YouTubePlaylistPlayer
            courseTitle={course.title}
            category={course.category}
            playlist={course.playlist}
          />
        </div>

        {/* Detailed Curriculum Syllabus Accordion */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-2xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-2">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Course Syllabus & Structured Learning Path
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Each module ends with a 15-question assessment. Pass all modules to unlock the 25-question final exam.
              </p>
            </div>

            <div className="text-xs font-semibold text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              Progress: <strong className="text-blue-700">{completedLessonsCount}</strong> of {totalLessons} Lessons Completed
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {course.modules.map((module, mIdx) => {
              const isOpen = !!openModules[module.id];
              const isModulePassed = progress?.completedAssessments.includes(module.id);

              return (
                <div
                  key={module.id}
                  className="rounded-xl border border-slate-200 overflow-hidden shadow-2xs"
                >
                  {/* Module Header */}
                  <div
                    onClick={() => toggleModule(module.id)}
                    className="p-4 sm:p-5 bg-slate-50/70 hover:bg-slate-100/80 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                        isModulePassed ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {mIdx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-slate-900">{module.title}</h3>
                          {isModulePassed && (
                            <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                              Assessment Passed
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">{module.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-500 hidden sm:inline">
                        {module.lessons.length} Lessons • 1 Assessment
                      </span>
                      {isOpen ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                    </div>
                  </div>

                  {/* Lessons List */}
                  {isOpen && (
                    <div className="p-4 sm:p-5 bg-white border-t border-slate-100 space-y-3">
                      {module.lessons.map((lesson, lIdx) => {
                        const isLessonCompleted = progress?.completedLessons.includes(lesson.id);

                        return (
                          <div
                            key={lesson.id}
                            className="p-3.5 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-blue-50/20 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                          >
                            <div className="flex items-start gap-3">
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center mt-0.5 shrink-0 ${
                                isLessonCompleted ? 'text-emerald-600' : 'text-slate-300'
                              }`}>
                                <CheckCircle className="w-4 h-4" />
                              </div>
                              <div>
                                <div className="text-xs font-bold text-slate-900">
                                  Lesson {lIdx + 1}: {lesson.title}
                                </div>
                                <div className="text-[11px] text-slate-500 mt-0.5">
                                  {lesson.duration} • Includes 8-Question Lesson Quiz
                                </div>
                              </div>
                            </div>

                            <button
                              onClick={() => onStartLearning(course.id, module.id, lesson.id)}
                              className="px-3 py-1.5 text-xs font-bold rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition-colors shrink-0"
                            >
                              {isLessonCompleted ? 'Review Lesson' : 'Launch Lesson'}
                            </button>
                          </div>
                        );
                      })}

                      {/* Module Assessment CTA */}
                      <div className="mt-4 p-3.5 rounded-lg bg-blue-50/60 border border-blue-200 flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-blue-900">
                            Module {mIdx + 1} Assessment (15 Questions)
                          </div>
                          <div className="text-[11px] text-blue-700">
                            Passing standard: 75%. Required to certify domain knowledge.
                          </div>
                        </div>

                        <button
                          onClick={() => onStartLearning(course.id, module.id, module.lessons[0].id)}
                          className="px-3.5 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold"
                        >
                          {isModulePassed ? 'Retake Assessment' : 'Take Assessment'}
                        </button>
                      </div>

                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Final Exam Section */}
          <div className="mt-8 p-6 rounded-xl bg-gradient-to-r from-blue-900 to-indigo-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-bold bg-amber-400 text-slate-950 uppercase tracking-wider mb-2">
                Final Step
              </div>
              <h3 className="text-base font-extrabold text-white">
                25-Question Final Certification Examination
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                Score 80% or higher to earn an official verified certificate with a cryptographic QR code, signed by CEO Muhammad Talha.
              </p>
            </div>

            <button
              onClick={() => onTakeFinalExam(course.id)}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md transition-all shrink-0"
              id="btn-take-final-exam-cta"
            >
              Start 25-Question Exam
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
