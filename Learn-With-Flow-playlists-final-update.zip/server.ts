import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory certificate registry (pre-seeded with a few sample verifiable awards)
interface CertificateEntry {
  id: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  category: string;
  completedDate: string;
  scorePercentage: number;
  grade: 'A+' | 'A' | 'B' | 'Pass';
  issuer: string;
  ceoName: string;
  status: 'valid' | 'revoked';
  qrVerificationUrl: string;
}

const certificateRegistry: Map<string, CertificateEntry> = new Map([
  [
    'LWF-2026-CERT-001',
    {
      id: 'LWF-2026-CERT-001',
      studentName: 'Amina Rehman',
      courseId: 'course-1',
      courseTitle: 'Full Stack Web Development Mastery',
      category: 'Web Development',
      completedDate: '2026-08-14',
      scorePercentage: 96,
      grade: 'A+',
      issuer: 'Learn With Flow Certification Board',
      ceoName: 'Muhammad Talha',
      status: 'valid',
      qrVerificationUrl: '/?verify=LWF-2026-CERT-001'
    }
  ],
  [
    'LWF-2026-CERT-002',
    {
      id: 'LWF-2026-CERT-002',
      studentName: 'Zubair Al-Mansoor',
      courseId: 'course-99',
      courseTitle: 'CompTIA Security+ (SY0-701) Complete Prep',
      category: 'Cybersecurity',
      completedDate: '2026-09-02',
      scorePercentage: 92,
      grade: 'A',
      issuer: 'Learn With Flow Certification Board',
      ceoName: 'Muhammad Talha',
      status: 'valid',
      qrVerificationUrl: '/?verify=LWF-2026-CERT-002'
    }
  ]
]);

// In-memory course playlist override map (allows admin to update or verify playlists on the fly)
const coursePlaylistOverrides: Map<string, any> = new Map();

// Lazy Gemini API client
let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return geminiClient;
}

// 1. Health endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 2. Secure Owner/Admin Authentication
// Validates code against server environment secret OWNER_CODE (defaults to talha1988)
app.post('/api/auth/owner', (req: Request, res: Response) => {
  const { code } = req.body;
  const expectedCode = process.env.OWNER_CODE || 'talha1988';

  if (typeof code === 'string' && code.trim() === expectedCode.trim()) {
    // Generate an admin session token
    const token = 'lwf_admin_tok_' + Buffer.from(`auth_${Date.now()}_talha`).toString('base64');
    return res.json({
      success: true,
      message: 'Authentication successful. Welcome, Muhammad Talha.',
      token
    });
  }

  return res.status(401).json({
    success: false,
    error: 'Access denied: Invalid Owner Code.'
  });
});

// 3. Certificates API
app.get('/api/certificates', (req: Request, res: Response) => {
  const allCerts = Array.from(certificateRegistry.values());
  res.json({ certificates: allCerts });
});

app.get('/api/certificates/:id', (req: Request, res: Response) => {
  const certId = req.params.id.trim();
  const cert = certificateRegistry.get(certId);

  if (cert) {
    return res.json({
      verified: true,
      certificate: cert,
      verificationMessage: 'Authenticated: This certificate is officially recorded and valid in the Learn With Flow Registry.'
    });
  }

  return res.status(404).json({
    verified: false,
    error: `Certificate ID "${certId}" was not found in the official registry. Please check the spelling or contact academic support.`
  });
});

app.post('/api/certificates', (req: Request, res: Response) => {
  const { studentName, courseId, courseTitle, category, scorePercentage, grade } = req.body;

  if (!studentName || !courseId || !courseTitle) {
    return res.status(400).json({ error: 'Missing required certificate details.' });
  }

  const randomHex = Math.random().toString(36).substring(2, 6).toUpperCase();
  const dateStr = new Date().toISOString().split('T')[0];
  const newId = `LWF-2026-${courseId.toUpperCase().replace('-', '')}-${randomHex}`;

  const newEntry: CertificateEntry = {
    id: newId,
    studentName: studentName.trim(),
    courseId,
    courseTitle,
    category: category || 'Technology',
    completedDate: dateStr,
    scorePercentage: scorePercentage || 90,
    grade: grade || 'A',
    issuer: 'Learn With Flow Academic & Certification Board',
    ceoName: 'Muhammad Talha',
    status: 'valid',
    qrVerificationUrl: `/?verify=${newId}`
  };

  certificateRegistry.set(newId, newEntry);

  res.status(201).json({
    success: true,
    certificate: newEntry
  });
});

// 4. Update Course Playlists (Admin only)
app.put('/api/courses/:id', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.includes('lwf_admin_tok_')) {
    return res.status(403).json({ error: 'Unauthorized. Admin session required.' });
  }

  const { id } = req.params;
  const { playlist } = req.body;

  coursePlaylistOverrides.set(id, playlist);
  res.json({ success: true, courseId: id, updatedPlaylist: playlist });
});

app.get('/api/courses/overrides', (req: Request, res: Response) => {
  const overrides: Record<string, any> = {};
  coursePlaylistOverrides.forEach((value, key) => {
    overrides[key] = value;
  });
  res.json({ overrides });
});

// 5. AI Assistant Chatbot API
app.post('/api/chat', async (req: Request, res: Response) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const systemPrompt = `You are FlowBot, the official intelligent AI learning advisor for "Learn With Flow" founded by Muhammad Talha.
Platform Overview:
- Learn With Flow provides 182+ comprehensive, free technology courses across 11 disciplines: Web Development, Mobile Development, Data Science, AI & Machine Learning, Cloud & DevOps, Cybersecurity, Software Engineering, Programming Languages, Databases, UI/UX Design, and Emerging Tech.
- Learning Model: Course -> Module -> Lesson -> 8-question Lesson Quiz -> 15-question Module Assessment -> 25-question Final Exam -> Verified Official Certificate.
- Certificates are signed by CEO Muhammad Talha with QR-code cryptographic verification.
- Every verified course embeds real confirmed educational playlists (e.g., from freeCodeCamp, CS50, Net Ninja, Corey Schafer, Professor Messer). Courses pending review are clearly labeled "Playlist Pending Verification".
- Respectful tribute: The platform honors the founder's father, Muhammad Toseef, for his sacrifices and support.
Tone: Warm, highly encouraging, knowledgeable, structured, concise, and helpful. Always guide learners toward suitable courses or roadmaps.`;

  try {
    const ai = getGemini();
    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemPrompt}\n\nUser Question: ${message}` }] }
        ]
      });

      return res.json({ reply: response.text });
    }
  } catch (err) {
    console.warn('Gemini API call failed, falling back to local advisor engine:', err);
  }

  // Smart fallback when Gemini API key is missing or offline
  const lower = message.toLowerCase();
  let fallbackReply = "Hello! I am your Learn With Flow Academic Advisor. I'm here to guide you through our 182 technology courses, quiz structure, and certificate verification.";

  if (lower.includes('python') || lower.includes('data science') || lower.includes('ai') || lower.includes('machine learning')) {
    fallbackReply = "For Python, AI, and Data Science, I strongly recommend starting with Course 135 (Python 3 Programming: From Beginner to Pro) or Course 41 (Python for Data Science). For AI practitioners, check out Course 59 (Machine Learning Foundations) and Course 78 (Gemini AI API & Multimodal Development). Each course includes structured 8-question lesson quizzes and a 25-question final exam leading to your verified certificate!";
  } else if (lower.includes('web') || lower.includes('react') || lower.includes('javascript') || lower.includes('frontend')) {
    fallbackReply = "For modern Web Development, our top recommended track starts with Course 1 (Full Stack Web Development Mastery), followed by Course 2 (Modern JavaScript ES6+), Course 3 (React 19 & Enterprise Architecture), and Course 6 (Next.js 15 Full-Stack). These tracks include verified educational playlists from leading educators!";
  } else if (lower.includes('cyber') || lower.includes('security') || lower.includes('hack')) {
    fallbackReply = "Our Cybersecurity curriculum is comprehensive! We recommend starting with Course 99 (CompTIA Security+ SY0-701 Complete Prep) with confirmed training by Professor Messer, followed by Course 100 (Ethical Hacking & Penetration Testing) and Course 101 (Web App Pentesting OWASP Top 10).";
  } else if (lower.includes('cloud') || lower.includes('aws') || lower.includes('devops') || lower.includes('docker')) {
    fallbackReply = "For Cloud & Infrastructure, begin with Course 79 (Google Cloud Platform Fundamentals) or Course 80 (AWS Certified Solutions Architect), then master containerization with Course 81 (Docker Containers) and Course 82 (Kubernetes Cluster Orchestration).";
  } else if (lower.includes('certificate') || lower.includes('verify') || lower.includes('exam')) {
    fallbackReply = "To earn an official Learn With Flow certificate: 1) Complete all lessons in a course, 2) Pass the 8-question quizzes and 15-question module assessments, and 3) Score 80%+ on the 25-question Final Comprehensive Exam. Your certificate includes a unique ID and QR code verifiable on our Verification page, signed by CEO Muhammad Talha.";
  } else if (lower.includes('ceo') || lower.includes('talha') || lower.includes('father') || lower.includes('founder') || lower.includes('toseef')) {
    fallbackReply = "Learn With Flow was founded by Muhammad Talha with the vision of making top-tier technical education freely accessible worldwide. Our platform also pays a heartfelt tribute to his father, Muhammad Toseef, recognizing his dedication, sacrifices, and unwavering support. Visit the 'About CEO' page in the top menu to read the full story!";
  }

  return res.json({ reply: fallbackReply });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Learn With Flow server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
